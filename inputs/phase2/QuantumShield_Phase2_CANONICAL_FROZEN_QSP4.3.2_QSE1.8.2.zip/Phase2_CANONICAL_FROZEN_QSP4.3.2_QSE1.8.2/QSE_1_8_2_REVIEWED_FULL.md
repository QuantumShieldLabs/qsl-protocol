# QuantumShield Envelope Specification
**Document:** QuantumShield Envelope (QSE)  
**Status:** Normative  
**Version:** 1.8.2 (DRAFT)  
**Date:** 2025-12-18  
**Supersedes:** QSE v1.8.1 (clarifications only)  
**Governing crypto spec:** QSP v4.3.2 (canonical)  

---

## 0. Scope and goals
QSE defines a minimal transport envelope for carrying **exactly one complete QSP message** (HandshakeInit, HandshakeResp, or ProtocolMessage) with deployment-controlled padding for metadata minimization.

This patch is deliberately conservative: it adds **DoS bounds**, clarifies **timestamp authority**, and tightens **canonical parsing**. It does **not** change the serialized envelope layout or `env_version`; QSE 1.8.2 remains wire-compatible with QSE 1.8.1.

---

## 1. Wire format (unchanged)

`Envelope = env_version(u16) || flags(u16) || route_token(varbytes<u16>) || timestamp_bucket(u32) || pad_len(u16) || payload_len(u32) || payload(payload_len) || pad(pad_len)`

- `env_version`: MUST be `0x0100` for QSE v1.x (including 1.8.x).
- `flags`: reserved; in QSE 1.8.x, flags MUST be `0x0000`.
- `route_token`: opaque routing token; semantics are deployment-specific.
- `timestamp_bucket`: coarse time bucket for replay damping and rate limiting (see §4).
- `payload`: the **raw bytes of one complete QSP message**. The envelope does not fragment or concatenate QSP messages.
- `pad`: padding bytes.

**Parsing note:** `payload_len` and `pad_len` are explicit; no heuristic parsing is permitted.

---

## 2. Canonical parsing rules (MUST)

An implementation MUST reject:
- unknown `env_version`,
- unknown/non-zero `flags` in QSE 1.8.x,
- truncated fields,
- any length that exceeds remaining bytes,
- trailing bytes beyond the last padding byte.

Receivers MUST parse `payload_len` and `pad_len` exactly as specified; no heuristic parsing is permitted.

---

## 3. DoS bounds (normative)

### 3.1 Envelope conformance tests (normative requirement)

A conformance checklist SHALL include, at minimum:
- wire parsing rejection cases (unknown version, non-zero flags, length overruns),
- bound enforcement cases (`MAX_*`),
- payload parsing failure behavior (payload discarded, no heuristic recovery),
- timestamp policy enforcement (`ALLOW_ZERO_TIMESTAMP_BUCKET`, acceptance window).

Receivers SHOULD attempt to parse the `payload` as a QSP message after envelope validation; if QSP parsing fails, the payload MUST be discarded. Deployments MUST NOT attempt heuristic recovery or concatenation of multiple QSP messages in one envelope.

To prevent memory and CPU exhaustion, implementations MUST enforce the following maximums:

- `MAX_ROUTE_TOKEN_LEN = 512` bytes
- `MAX_PAYLOAD_LEN = 1_048_576` bytes (1 MiB)
- `MAX_PAD_LEN = 1_048_576` bytes (1 MiB)
- `MAX_ENVELOPE_LEN = 2_097_152` bytes (2 MiB)

Rules:
- `route_token.len` MUST be <= `MAX_ROUTE_TOKEN_LEN`.
- `payload_len` MUST be <= `MAX_PAYLOAD_LEN`.
- `pad_len` MUST be <= `MAX_PAD_LEN`.
- Total encoded envelope length MUST be <= `MAX_ENVELOPE_LEN`.

Deployments MAY choose smaller maxima, but MUST NOT exceed these limits without a version bump.

**Interface requirement:** Deployments MUST ensure the largest possible encoded QSP message (for the enabled suite(s)) fits within `MAX_PAYLOAD_LEN`.

---

## 4. Timestamp bucket authority and semantics (clarified)

### 4.1 Authority model
- If a trusted service edge is present, **the service edge is authoritative** for `timestamp_bucket`.
- If no trusted service edge exists (direct transport), **the sender is authoritative**.

### 4.2 Sender behavior
- In service-edge deployments, clients SHOULD set `timestamp_bucket = 0` and rely on the service edge to populate it.
- In direct deployments, senders MUST set `timestamp_bucket` according to the deployment’s bucket policy.

### 4.3 Receiver behavior
Receivers MUST apply a deployment policy `ALLOW_ZERO_TIMESTAMP_BUCKET`:
- If `ALLOW_ZERO_TIMESTAMP_BUCKET = true`, receivers MUST accept `timestamp_bucket = 0` (meaning “unspecified”).
- If `ALLOW_ZERO_TIMESTAMP_BUCKET = false`, receivers MUST reject `timestamp_bucket = 0`.

For non-zero values, receivers MUST accept a value within an implementation-defined acceptance window around local time.

Receivers SHOULD use `timestamp_bucket` only for:
- coarse replay damping (rate limiting), and/or
- coarse ordering hints.

Receivers MUST NOT treat `timestamp_bucket` as a security-critical freshness proof.

### 4.4 Bucket policy (deployment parameter)
A deployment MUST define:
- `BUCKET_WIDTH_SECONDS` (RECOMMENDED: 900 seconds / 15 minutes), and
- `BUCKET_SKEW_TOLERANCE` (RECOMMENDED: ±2 buckets).

When authoritative, compute:
`timestamp_bucket = floor(unix_time_seconds / BUCKET_WIDTH_SECONDS)`.

---

## 5. Padding rules (clarified)

### 5.1 Minimum-size padding
A deployment profile specifies a minimum serialized envelope size `MIN_ENVELOPE_BYTES`.

Encoders MUST choose `pad_len` such that:
`len(Envelope) >= MIN_ENVELOPE_BYTES`.

`len(Envelope)` counts **all bytes**, including the padding itself.

### 5.2 Padding contents
- Padding bytes SHOULD be sampled from a cryptographic RNG.
- For published test vectors only, padding MAY be all-zero.

---

## 6. Security considerations
- Padding policy is the primary tool for resisting size-based traffic analysis.
- Tight bounds are mandatory to prevent envelope-based DoS.
- `route_token` is opaque to the client; deployments MUST ensure it does not embed stable plaintext identifiers.
