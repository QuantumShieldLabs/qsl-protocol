# QuantumShield Protocol Specification
**Document:** QuantumShield Protocol (QSP)  
**Status:** Normative  
**Version:** 4.3.2 (DRAFT)  
**Date:** 2025-12-18  
**Wire `protocol_version`:** 0x0403  
**suite_id:** 0x0001 (QSP-SUITE-1), 0x0002 (QSP-SUITE-1B)  
**Supersedes:** QSP v3.x, QSP v4.0–v4.2.x (archived)

---

## 0. Scope, goals, non-goals, authority and relationship to ADRs

This document is a **Suite-1 hardening patch** (QSP v4.3.1 → v4.3.2). It is intentionally conservative and focuses on:
- eliminating ambiguity,
- tightening canonical parsing requirements,
- strengthening explicit DoS bounds,
- clarifying identity/KT verification requirements where possible **without** introducing Suite-2 mechanics.

Out of scope (tracked separately):
- **Suite-2 / QSP v5.0 “SPQR-like” PQ Braid design**, including chunking, erasure coding, PQ state machine, and per-message hybrid mixing (see ADR-0010, ADR-0011, ADR-0012).

ADR mapping:
- ADR-0013: **in scope** for Suite-1 clarification (identity binding and canonical KT proof encoding) if achievable without breaking Suite-1 compatibility.
- ADR-0010/0011/0012: **not in scope** for Suite-1; reserved for Suite-2 (QSP v5.0).

### 0.1 Scope
This specification defines an end-to-end encryption protocol for **pairwise (1:1)** messaging between devices.
It is intended to be sufficient for:
- independent interoperable implementations, and
- external cryptographic review and security testing.

### 0.2 Goals
- Hybrid quantum-safe confidentiality, integrity, and authentication for message contents.
- Forward secrecy (FS) and post-compromise security (PCS) using a DH Double Ratchet.
- Ongoing PQ contribution to session evolution (PQ mixing) at **DH ratchet boundaries**, and hybridization of the message key when `FLAG_PQ_CTXT` is present.
- Header confidentiality for message counters (N, PN) with bounded work for out-of-order delivery.
- Robust operation under lossy, asynchronous, and out-of-order transport.

### 0.3 Non-goals
- Group messaging, federation, and multi-device fanout semantics (out of scope).
- Global traffic-analysis resistance (handled by deployment profiles in QSE).
- Endpoint compromise resistance beyond PCS/FS guarantees (e.g., OS compromise, keyloggers).

### 0.4 Authority and precedence
This document is **normative**. In case of conflict:
1) This protocol specification (QSP) governs cryptographic and wire-format behavior.
2) The QuantumShield Envelope Specification (QSE) governs transport wrapping and metadata minimization.
3) Whitepapers and guidelines are informational.

### 0.5 Conformance language
The key words **MUST**, **MUST NOT**, **SHOULD**, **SHOULD NOT**, **MAY** are to be interpreted as in RFC 2119.

---

## 1. Cryptographic suite (QSP-SUITE-1)

### 1.1 Primitives
- Classical DH: X25519
- PQ KEM: ML-KEM-768
- Classical signatures: Ed25519
- PQ signatures: ML-DSA-65
- AEAD: AES-256-GCM with 16-byte tag
- Hash: SHA-512
- KDF/MAC: KMAC-256 with domain separation labels (see §3)

### 1.2 Fixed sizes (normative for parsing)
- X25519 public key: 32 bytes
- Ed25519 public key: 32 bytes; signature: 64 bytes
- ML-KEM-768 public key: 1184 bytes; ciphertext: 1088 bytes
- ML-DSA-65 public key: 1952 bytes; signature: 3309 bytes
- AES-GCM nonce: 12 bytes; tag: 16 bytes
- `session_id`: 16 bytes

Implementations MUST reject inputs that do not match the expected sizes.

---

## 2. Encoding, parsing, and extension rules

### 2.1 Integer encoding
All integers are unsigned and big-endian unless specified.

- `u16`: 2 bytes
- `u32`: 4 bytes

### 2.2 Length-delimited byte strings
- `varbytes<u16>`: `u16 len || len bytes`
- `varbytes<u32>`: `u32 len || len bytes`

### 2.3 Canonical parsing rules (MUST)
Implementations MUST reject:
- truncated fields,
- lengths that exceed remaining bytes,
- trailing bytes not described by the message format,
- duplicate fields (no TLV repetition exists in QSP v4.3).

All tag/signature comparisons MUST be constant time.

### 2.4 Extensions
QSP v4.3 uses conservative evolution:
- unknown `protocol_version` or `suite_id` MUST be rejected;
- unknown `flags` bits MUST be rejected;
- any future extensions MUST be explicitly length-delimited and versioned.

---

Defined suite IDs for `protocol_version` 0x0403:
- `suite_id = 0x0001`: Suite-1 (legacy AD rules; kept for backwards compatibility).
- `suite_id = 0x0002`: Suite-1B (binds PQ prefix fields into AEAD AD via `pq_bind`; see §6.1).

## 3. Cryptographic function definitions


### 3.1 Hash and KMAC
- `H(m) = SHA-512(m)`
- `KMAC(key, label, data, outlen)` is KMAC-256 where:
  - customization string = `label`
  - output length = `outlen` bytes

### 3.2 AEAD
- `AEAD_Enc(key, nonce, ad, pt) -> ct` uses AES-256-GCM and outputs `ct || tag`.
- `AEAD_Dec(key, nonce, ad, ct) -> pt or FAIL` verifies the tag.

### 3.3 Chain-key and root-key KDFs
All KDFs are domain-separated. `outlen` is bytes.

- `KDF_CK(CK) -> (CK', MK)`:
  - `CK' = KMAC(CK, "QSP4.3/CK", 0x01, 32)`
  - `MK  = KMAC(CK, "QSP4.3/MK", 0x02, 32)`

- `KDF_RK_DH(RK, dh_out) -> (RK', CK)`:
  - `tmp = KMAC(RK, "QSP4.3/RKDH", dh_out, 64)`
  - `RK' = tmp[0:32]`
  - `CK  = tmp[32:64]`

- `KDF_RK_PQ(RK, pq_ss) -> RK'`:
  - `RK' = KMAC(RK, "QSP4.3/RKPQ", pq_ss, 32)`

### 3.4 Directional header keys from RK
Header keys are derived from the current RK and the fixed handshake roles (A=initiator, B=responder):

- `HK_A->B(RK)  = KMAC(RK, "QSP4.3/HK/A->B",  0x01, 32)`
- `HK_B->A(RK)  = KMAC(RK, "QSP4.3/HK/B->A",  0x01, 32)`
- `NHK_A->B(RK) = KMAC(RK, "QSP4.3/NHK/A->B", 0x01, 32)`
- `NHK_B->A(RK) = KMAC(RK, "QSP4.3/NHK/B->A", 0x01, 32)`

`NHK` is the “next header key” used to encrypt headers of **boundary messages** (see §8.4).

---

## 4. Identity, Key Transparency, and prekeys

### 4.1 Device identity keys
Each device has long-term signature identity keys:
- `IK_sig_ec` (Ed25519)
- `IK_sig_pq` (ML-DSA-65)

Identity keys MUST be distributed and pinned via a Key Transparency system (KT) as specified in §4.4.

### 4.2 Prekeys
Each device maintains and publishes:
- `SPK_DH`: X25519 signed prekey keypair
- `SPK_PQ`: ML-KEM signed prekey keypair
- Optional one-time prekeys:
  - `OPK_DH[i]`: X25519 one-time prekey
  - `OPK_PQ[i]`: ML-KEM one-time prekey
- `PQ_RCV`: ML-KEM **receive-ratchet** keypair for ongoing PQ mixing

### 4.3 Prekey bundle format (normative)
A prekey bundle is retrieved by initiators.

Initiators MUST validate:
- both bundle signatures (Ed25519 + ML-DSA-65),
- KT inclusion and consistency (Authenticated mode),
- validity window.

**PrekeyBundle (canonical order):**
- `user_id`                 (varbytes<u16>)
- `device_id`               (u32)
- `valid_from`              (u32)  (unix seconds)
- `valid_to`                (u32)  (unix seconds)
- `IK_sig_ec_pub`           (32)
- `IK_sig_pq_pub`           (1952)
- `SPK_DH_pub`              (32)
- `SPK_PQ_pub`              (1184)
- `PQ_RCV_id`               (u32)
- `PQ_RCV_pub`              (1184)
- `opk_dh_present`          (u16) (0/1)
- if present:
  - `OPK_DH_id`             (u32)
  - `OPK_DH_pub`            (32)
- `opk_pq_present`          (u16) (0/1)
- if present:
  - `OPK_PQ_id`             (u32)
  - `OPK_PQ_pub`            (1184)
- `sig_ec`                  (64)   (over BundleTBS, §4.3.1)
- `sig_pq`                  (3309) (over BundleTBS, §4.3.1)
- `kt_log_id`               (32)
- `kt_sth`                  (varbytes<u16>)
- `kt_inclusion_proof`      (varbytes<u16>)
- `kt_consistency_proof`    (varbytes<u16>) (empty if first contact)

#### 4.3.1 BundleTBS
`BundleTBS = H("QSP4.3/BUNDLE" || all bundle fields up to and including OPK fields, excluding signatures and KT data)`

The bundle signatures are:
- `sig_ec = Ed25519.Sign(IK_sig_ec_priv, BundleTBS)`
- `sig_pq = MLDSA.Sign(IK_sig_pq_priv, BundleTBS)`

### 4.4 Key Transparency profile (normative minimum)
Authenticated sessions REQUIRE KT verification.

#### 4.4.1 KT objects
- `STH` (Signed Tree Head): `log_id(32) || tree_size(u64) || root_hash(32) || timestamp(u64) || sig_ec(64) || sig_pq(3309)`
- `InclusionProof`: a list of sibling hashes + leaf index; encoded as `varbytes<u16>` with a canonical internal format.
- `ConsistencyProof`: list of hashes; encoded as `varbytes<u16>`.

KT signatures are over:
`STH_TBS = H("QSP4.3/KT/STH" || log_id || tree_size || root_hash || timestamp)`

The log’s signing keys MUST themselves be pinned by the client implementation (out of band) or by a higher-level trust root.

#### 4.4.2 Merkle hashing
- `LeafHash = H("QSP4.3/KT/LEAF" || leaf_data)`
- `NodeHash = H("QSP4.3/KT/NODE" || left || right)`

#### 4.4.3 Leaf binding
`leaf_data` MUST bind:
- `user_id` (canonical bytes from bundle)
- `device_id`
- `BundleTBS` (64 bytes)
- `valid_from`, `valid_to`

#### 4.4.4 Client policy (Authenticated mode)
Before using a bundle in Authenticated mode, the client MUST:
1) Verify both bundle signatures.
2) Verify validity window.
3) Verify `kt_sth` signatures (both) and pin `(log_id, root_hash, tree_size)`.
4) Verify inclusion proof for `LeafHash(leaf_data)` under `root_hash`.
5) Verify consistency proof versus last pinned STH (unless first contact).

If any step fails, the bundle MUST NOT be used for an authenticated session.

#### 4.4.5 Canonical encoding requirements (normative)
To ensure interoperable verification and avoid parser differentials, the following MUST hold:
- `kt_sth` (varbytes<u16>) MUST contain exactly one serialized `STH` as defined in §4.4.1.
- `kt_inclusion_proof` MUST encode a proof as: `u16 count || (count * node_hash(32)) || u64 leaf_index`.
- `kt_consistency_proof` MUST encode a proof as: `u16 count || (count * node_hash(32))`.
- All integers inside KT objects MUST be big-endian.
- `count` MUST be <= 64. Proofs with `count=0` are permitted only when the verifier’s policy allows it (e.g., first contact / empty tree edge cases).
- A verifier MUST reject any KT varbytes that contain trailing bytes beyond the canonical encoding.

#### 4.4.6 Rollback and freshness policy (normative minimum)
Clients implementing Authenticated mode MUST maintain the last pinned `(log_id, tree_size, root_hash, timestamp)` per log.
On each new `STH`, the client MUST reject:
- `tree_size` smaller than the pinned `tree_size`,
- `timestamp` earlier than the pinned `timestamp` by more than an implementation-defined tolerance,
- any `root_hash` that cannot be justified by a valid consistency proof from the pinned STH (unless first contact).

### 4.5 One-time prekey consumption semantics (service requirement)
If OPKs are used, the service MUST:
- hand out each OPK at most once per device,
- delete or mark OPK as consumed atomically,
- reject replay of consumed OPKs.

---

## 5. Handshake

### 5.1 Overview
Handshake establishes:
- mutual authentication (Key Transparency verification REQUIRED),
- initial root key `RK0`,
- initial DH ratchet keys and header keys,
- initial PQ peer receive key information.


### 5.1.1 Session identifier generation (normative)
Initiator A MUST choose `session_id` as 16 bytes sampled uniformly at random.
`session_id` MUST be unique with overwhelming probability for a given initiator device; implementations MUST NOT intentionally reuse a `session_id` value.
`session_id` is treated as public protocol metadata and is included in transcript hashes and AEAD associated data.

### 5.2 HandshakeInit wire format
`HandshakeInit` is the concatenation of the fields in the canonical order listed below.

**HandshakeInit (canonical order):**
- `protocol_version` (u16)
- `suite_id` (u16)
- `session_id` (16)
- `user_id_B` (varbytes<u16>)
- `device_id_B` (u32)
- `EK_DH_A_pub` (32)
- `ct1` (1088)  (encap to SPK_PQ_B)
- `opk_used` (u16) (0/1)
- if `opk_used`:
  - `ct2` (1088) (encap to OPK_PQ_B)
  - `OPK_DH_id` (u32) and `OPK_PQ_id` (u32)
- `PQ_RCV_A_id` (u32)
- `PQ_RCV_A_pub` (1184)
- `IK_sig_ec_A_pub` (32)
- `IK_sig_pq_A_pub` (1952)
- `sig_ec_A` (64)
- `sig_pq_A` (3309)

#### 5.2.1 HS1 transcript
`HS1 = H("QSP4.3/HS1" || HandshakeInit with sig fields set to zero bytes)`

Signatures:
- `sig_ec_A = Ed25519.Sign(IK_sig_ec_A_priv, HS1)`
- `sig_pq_A = MLDSA.Sign(IK_sig_pq_A_priv, HS1)`

### 5.3 HandshakeResp wire format
**HandshakeResp (canonical order):**
- `protocol_version` (u16)
- `suite_id` (u16)
- `session_id` (16)
- `DH0_B_pub` (32)  (B’s initial DH ratchet pubkey)
- `PQ_RCV_B_id` (u32)
- `PQ_RCV_B_pub` (1184)
- `ct3` (1088) (encap to PQ_RCV_A_pub)
- `conf_B` (32) (explicit confirmation tag)
- `IK_sig_ec_B_pub` (32)
- `IK_sig_pq_B_pub` (1952)
- `sig_ec_B` (64)
- `sig_pq_B` (3309)

#### 5.3.1 HS2 transcript and confirmation
Define `HandshakeResp_TBS` as **HandshakeResp with**:
- `conf_B` set to 32 zero bytes, and
- all signature fields (`sig_ec_B`, `sig_pq_B`) set to zero bytes.

`HS2 = H("QSP4.3/HS2" || HandshakeInit || HandshakeResp_TBS)`

**Responder-to-initiator PQ bootstrap (ct3):**
- `ct3` is an encapsulation to `PQ_RCV_A_pub`, producing shared secret `ss3`.
- Define `RK_init = KDF_RK_PQ(RK0, ss3)`.

`conf_B = KMAC(RK_init, "QSP4.3/CONF", HS2, 32)`

Signatures:
- `sig_ec_B = Ed25519.Sign(IK_sig_ec_B_priv, HS2)`
- `sig_pq_B = MLDSA.Sign(IK_sig_pq_B_priv, HS2)`

**Acceptance rule (normative):** A MUST verify (1) B's signatures over HS2 and (2) `conf_B` using `RK_init` before accepting the session.

### 5.4 Shared secrets and RK0 derivation (initiator A)
A performs:
1) Fetch and validate B’s PrekeyBundle (including KT as required).
2) Generate `EK_DH_A`.
3) `(ct1, ss1) = MLKEM_Encap(SPK_PQ_B_pub)`
4) If OPKs present and used: `(ct2, ss2) = MLKEM_Encap(OPK_PQ_B_pub)`
5) `dh1 = X25519(EK_DH_A_priv, SPK_DH_B_pub)`
6) If OPK_DH used: `dh2 = X25519(EK_DH_A_priv, OPK_DH_B_pub)`
7) `ms = H("QSP4.3/MS" || ss1 || [ss2] || dh1 || [dh2])`
8) `RK0 = KMAC(ms, "QSP4.3/RK0", session_id, 32)`

### 5.5 Shared secrets and RK0 derivation (responder B)
B performs:
1) Validate versions/lengths.
2) Verify A’s identity keys via KT (Key Transparency is REQUIRED in QSP v4.3.x).
3) Verify A’s signatures over HS1.
4) `ss1 = MLKEM_Decap(SPK_PQ_B_priv, ct1)`; if `opk_used`, `ss2 = Decap(OPK_PQ_B_priv, ct2)`.
5) `dh1 = X25519(SPK_DH_B_priv, EK_DH_A_pub)`; if `opk_used`, `dh2 = X25519(OPK_DH_B_priv, EK_DH_A_pub)`.
6) Compute `ms` and `RK0` as in §5.4.
7) Generate `DH0_B`, `PQ_RCV_B`, and `(ct3, ss3) = MLKEM_Encap(PQ_RCV_A_pub)`.
8) Compute `RK_init = KDF_RK_PQ(RK0, ss3)`.
9) Construct `HandshakeResp_TBS`, compute `HS2`, compute `conf_B` using `RK_init` (per §5.3.1), then fill `conf_B` and produce B’s signatures.

### 5.6 Session initialization
On completion (after HS2 verification), both sides perform the following **normative** initialization.

**Inputs available at this point**
- `RK0` from §5.4/§5.5.
- `ct3` from HS2.
- A has `PQ_RCV_A_priv` for the `PQ_RCV_A_pub` carried in HS1.
- A has `EK_DH_A_priv` (the same X25519 ephemeral used in HS1).
- Both know `DH0_B_pub` from HS2.

**Step 1: Derive RK_init (bind ct3)**
- A computes `ss3 = MLKEM_Decap(PQ_RCV_A_priv, ct3)`.
- B already computed `ss3` during encapsulation.
- Both set `RK = RK_init = KDF_RK_PQ(RK0, ss3)`.

**Step 2: Establish initial DH ratchet state**
- A sets `DH_self = EK_DH_A` and `DH_peer = DH0_B_pub`.
- B sets `DH_self = DH0_B` and `DH_peer = EK_DH_A_pub`.

Define the initial DH output:
- `dh_init = X25519(EK_DH_A_priv, DH0_B_pub)` (A)
- `dh_init = X25519(DH0_B_priv, EK_DH_A_pub)` (B)
These MUST be equal.

**Step 3: Derive the initial chain key**
- `(RK, CK0) = KDF_RK_DH(RK, dh_init)`.
- Role assignment:
  - Initiator A sets `CK_s = CK0` and `CK_r = None`.
  - Responder B sets `CK_r = CK0` and `CK_s = None`.

**Step 4: Derive header keys and initialize counters**
- Derive `HK_s/HK_r/NHK_s/NHK_r` from `RK` and role.
- Initialize counters `Ns=0, Nr=0, PN=0`.
- Initialize `MKSKIPPED` empty and `HKSKIPPED` empty.

**Step 5: Initialize PQ peer receive key info**
- A sets `PQ_peer_id/pub = (PQ_RCV_B_id, PQ_RCV_B_pub)` from HS2.
- B sets `PQ_peer_id/pub = (PQ_RCV_A_id, PQ_RCV_A_pub)` from HS1.

## 6. Messaging: associated data, nonces, and flags

### 6.1 Associated data (normative)

Associated data differs by `suite_id`.

**Suite-1 (suite_id = 0x0001)**:
- `AD_hdr  = session_id || protocol_version || suite_id || DH_pub || flags`
- `AD_body = session_id || protocol_version || suite_id`

**Suite-1B (suite_id = 0x0002)** (PQ control-plane binding; no wire-format changes):

Let `PQ_PREFIX` be the concatenation (in canonical on-wire order) of the optional PQ fields present in the `ProtocolMessage` prefix:
- If `FLAG_PQ_ADV` is set: `pq_adv_id || pq_adv_pub`
- If `FLAG_PQ_CTXT` is set: `pq_target_id || pq_ct`

Define:
- `pq_bind = H("QSP4.3/PQ-BIND" || u16(flags) || PQ_PREFIX)[0:32]`

Then:
- `AD_hdr  = session_id || protocol_version || suite_id || DH_pub || u16(flags) || pq_bind`
- `AD_body = session_id || protocol_version || suite_id || pq_bind`

Integrity requirement (Suite-1B):
- Implementations MUST compute `pq_bind` from the received on-wire `flags` and PQ prefix fields.
- Any modification of PQ prefix fields (ADV or CTXT) MUST cause header and/or body AEAD verification failure, and MUST NOT be committed to ratchet state.

Envelope metadata MUST NOT be included in QSP AEAD AD.

### 6.2 Nonces
- `nonce_hdr`: **deterministic and bound to the header plaintext**.
  - The sender MUST set:
    - `nonce_hdr = H("QSP4.3/HDR-NONCE" || session_id || DH_pub || u32(N))[0:12]`
      where `DH_pub` is the sender’s on-wire `DH_pub` for this message and `N` is the header plaintext message number.
  - The receiver MUST use the received `nonce_hdr` as the AEAD nonce for header decryption.
  - After successful header decryption (recovering `N`), the receiver MUST recompute the expected `nonce_hdr` using the formula above; if it does not match the received `nonce_hdr`, the message MUST be rejected and no state changes may be committed.
- `nonce_body`: deterministic:
  - `nonce_body = H("QSP4.3/BODY-NONCE" || session_id || DH_pub || u32(N))[0:12]`

### 6.3 Flags
- `0x0001` = `FLAG_PQ_ADV` (includes new PQ_RCV key advertisement)
- `0x0002` = `FLAG_PQ_CTXT` (includes PQ encapsulation ciphertext)
- `0x0004` = `FLAG_BOUNDARY` (message performs DH ratchet send step)

**Flag invariants (normative):**
- A message with `FLAG_PQ_ADV` MUST also set `FLAG_BOUNDARY`.
- A message with `FLAG_PQ_CTXT` MUST also set `FLAG_BOUNDARY`.
- A message with `FLAG_BOUNDARY` MUST be header-encrypted under the sender’s **boundary header key** (see §9.3) and MUST be accepted by the receiver only if the header decrypt source is `CURRENT_NHK` (see §9.5 step 4).
- Messages without `FLAG_BOUNDARY` MUST NOT include PQ prefix fields and MUST be header-encrypted under `HK_s`.

Unknown flags MUST be rejected.

**AD_hdr flags rule (normative):** The `flags` value included in `AD_hdr` MUST be the final on-wire flags (including PQ flags) determined before header encryption.

---

## 7. Wire format: ProtocolMessage

`ProtocolMessage = Prefix || HeaderCT || BodyCT`

### 7.1 Prefix (canonical order)
- `protocol_version` (u16)
- `suite_id` (u16)
- `session_id` (16)
- `DH_pub` (32)
- `flags` (u16)
- `nonce_hdr` (12)
- if `FLAG_PQ_ADV`: `pq_adv_id` (u32), `pq_adv_pub` (1184)
- if `FLAG_PQ_CTXT`: `pq_target_id` (u32), `pq_ct` (1088)
- `hdr_ct_len` (u16)
- `hdr_ct` (hdr_ct_len bytes)
- `body_ct_len` (u32)
- `body_ct` (body_ct_len bytes)

**Suite-1 length requirements (normative):**
- `hdr_ct_len` MUST equal **24**. Encoders MUST set it to 24; decoders MUST reject any other value.
- `body_ct_len` MUST be at least **16** (GCM tag) and MUST be <= `MAX_BODY_CT_LEN` (deployment-defined).

**Interoperability bound (QSP↔QSE):** If QSP messages are transported inside QSE 1.8.x envelopes, deployments MUST choose `MAX_BODY_CT_LEN` such that the **entire encoded QSP message** (Prefix + HeaderCT + BodyCT) fits within QSE `MAX_PAYLOAD_LEN` (1 MiB). A RECOMMENDED default is `MAX_BODY_CT_LEN = 1_000_000` bytes, leaving room for Prefix and HeaderCT within the 1 MiB envelope payload limit.


### 7.2 Header plaintext
`HeaderPlain = PN(u32) || N(u32)`

---

## 8. Messaging state and invariants

### 8.1 State variables (per session)
- `RK` (32)
- `DH_self` (X25519 keypair), `DH_peer` (32)
- `CK_s`, `CK_r` (32 or None)
- `HK_s`, `HK_r`, `NHK_s`, `NHK_r` (32)
- Counters: `Ns`, `Nr`, `PN` (u32)
- `MKSKIPPED`: map `(DH_pub, N) -> MK` with TTL and cap
- `HKSKIPPED`: map `old_DH_pub -> (HK_r_old, NHK_r_old)` with TTL and cap
- PQ peer: `PQ_peer_id`, `PQ_peer_pub`
- PQ self cache: a bounded set of `(pq_id -> keypair)` for `PQ_RCV`

### 8.2 Commit rule (normative)
No durable state is committed unless **both header and body decrypt succeed** and all required validations pass.

### 8.3 Bounds (normative)
- `MAX_SKIP = 1000` (max derived skipped message keys per epoch)
- `MAX_MKSKIPPED = 2000` entries, TTL 7 days
- `MAX_HEADER_ATTEMPTS = 100` per message
- `MAX_HKSKIPPED = 4` entries, TTL 7 days

### 8.3.1 Counter exhaustion and wraparound (normative)
All message counters in QSP are serialized as `u32` and MUST be treated as monotonically increasing non-negative integers **without wraparound** for protocol correctness.

Implementations MUST enforce the following:
- A sender MUST NOT transmit a message with `N` or `PN` that would require `Ns`, `Nr`, or `PN` to wrap modulo 2^32.
- If `Ns` would reach `2^32 - 1`, the sender MUST terminate the session and perform a fresh handshake before sending further messages on that session.
- If a receiver observes a header-decrypted `N` or `PN` that is not representable as a non-negative integer within the receiver's counter model for that epoch (including wraparound scenarios), it MUST reject the message and SHOULD discard the session.
- All arithmetic comparisons of `u32` counters (e.g., `N - Nr`) MUST be performed in a wider integer type (e.g., `u64`) with explicit checks to prevent underflow/overflow.

This rule prevents nonce reuse and ambiguity arising from counter wraparound.

### 8.4 Boundary messages and epoch transitions (normative)

A **boundary message** is any `ProtocolMessage` with `FLAG_BOUNDARY` set. Boundary messages are the only messages that advance the DH ratchet epoch and the only messages permitted to carry PQ mixing fields (`FLAG_PQ_ADV`, `FLAG_PQ_CTXT`).

**Sender requirements:**
- A sender MUST set `FLAG_BOUNDARY` on the first outbound message after `DHRatchetSend` is executed.
- The header of a boundary message MUST be encrypted under the sender’s *pre-ratchet* next-header key (`NHK_s` from the prior epoch), as captured by `boundary_HK` in §9.1.
- If `PQ_peer_pub` is known at the time of sending the boundary message, the sender MUST include `FLAG_PQ_CTXT` with a fresh encapsulation ciphertext to `PQ_peer_pub` and MUST apply the corresponding `KDF_RK_PQ` update to its state (see §9.3).
- The sender MUST include `FLAG_PQ_ADV` on every boundary message and MUST advertise a fresh `PQ_RCV` public key (`pq_adv_pub`) with a `pq_adv_id` not currently in use by that sender’s `PQ_self_keys` cache.

**Receiver requirements:**
- If `FLAG_BOUNDARY` is set and `msg.DH_pub != st.DH_peer`, the receiver MUST treat the message as a candidate new epoch and MUST require that header decryption succeeded using `CURRENT_NHK` (see §9.5 step 4). If not, the message MUST be rejected.
- If `msg.DH_pub != st.DH_peer` but `FLAG_BOUNDARY` is not set, the receiver MUST reject the message (protocol violation), except for delayed messages proven to be from an old epoch via `HKSKIPPED`/`hdr_source` (see §9.5 step 4).
- PQ fields (`FLAG_PQ_ADV`, `FLAG_PQ_CTXT`) MUST be processed only on messages that pass the boundary acceptance rules above.


---

## 9. Ratchet algorithms (normative)

### 9.1 DHRatchetSend
Input: mutable state `st`.

1) Save `boundary_HK = st.NHK_s` (derived from **pre-ratchet** RK).
2) Set `st.PN = st.Ns`; set `st.Ns = 0`.
3) Generate new `DH_self`.
4) Compute `dh_out = X25519(st.DH_self_priv, st.DH_peer)`.
5) `(st.RK, st.CK_s) = KDF_RK_DH(st.RK, dh_out)`.
6) Recompute `HK_s/HK_r/NHK_s/NHK_r` from the new `st.RK`.
7) Set `st.boundary_pending = 1` and `st.boundary_HK = boundary_HK`.

### 9.2 DHRatchetReceive
Input: mutable state `st`, `DH_new` (32), `PN` (u32).

1) If `st.CK_r` is not None: derive and store skipped keys up to `PN` using §9.6.
2) Store `(st.HK_r, st.NHK_r)` into `HKSKIPPED[st.DH_peer]` with TTL/cap.
3) Set `st.PN = st.Ns`; set `st.Ns = 0`.
4) Set `st.DH_peer = DH_new`.
5) Compute `dh_in = X25519(st.DH_self_priv, st.DH_peer)`.
6) `(st.RK, st.CK_r) = KDF_RK_DH(st.RK, dh_in)`.
7) Recompute header keys from the new `st.RK`.
8) Set `st.CK_s = None` to force a send ratchet on next outbound message.

### 9.3 RatchetEncrypt
Input: mutable state `st`, plaintext `m`.

This procedure constructs a `ProtocolMessage` and updates the sender state. Implementations MUST ensure that the **final serialized prefix fields** (flags and optional PQ fields) are determined **before** computing AEAD associated data and encrypting the header/body, because associated data depends on these fields (§6.1).

1) If `st.CK_s is None`: run `DHRatchetSend(st)`.

2) Let `N = st.Ns`.

3) `(st.CK_s, MK) = KDF_CK(st.CK_s)`; set `st.Ns += 1`.

4) Construct header plaintext `HP = u32(st.PN) || u32(N)`.

5) Determine whether this message is a boundary message:
   - `is_boundary = (st.boundary_pending != 0)`.
   - If `is_boundary`: set `flags = FLAG_BOUNDARY`; else `flags = 0`.

6) If `is_boundary`, prepare PQ fields (if applicable) **before** header encryption:
   - Initialize `pq_ss = None`.
   - If `PQ_peer_pub` is known:
       `(pq_ct, pq_ss) = MLKEM_Encap(PQ_peer_pub)`;
       set `flags |= FLAG_PQ_CTXT` and set `pq_target_id = PQ_peer_id`.
   - Generate a fresh local `PQ_RCV` keypair and choose a `pq_adv_id` not currently present in `PQ_self_keys`:
       set `flags |= FLAG_PQ_ADV` and set `(pq_adv_id, pq_adv_pub)` accordingly.
     Add the new keypair to `PQ_self_keys[pq_adv_id]` (bounded cache).

7) Choose the header encryption key:
   - If `is_boundary`: `HK_hdr = st.boundary_HK` (captured pre-ratchet in §9.1).
   - Else: `HK_hdr = st.HK_s`.

8) Construct `AD_hdr` and `AD_body` per §6.1 using the **final** `flags` and the actual serialized PQ prefix fields (for Suite-1B this includes `pq_bind`).

9) Compute `nonce_hdr` deterministically:
   - `DH_pub` is the 32-byte `st.DH_self_pub` value that will be serialized in the message prefix.
   - `nonce_hdr = H("QSP4.3/HDR-NONCE" || session_id || DH_pub || u32(N))[0:12]`.

10) Encrypt header:
   - `hdr_ct = AEAD_Enc(HK_hdr, nonce_hdr, AD_hdr, HP)`.

11) Compute `nonce_body` per §6.2 and encrypt body:
   - If `flags` includes `FLAG_PQ_CTXT`, set `MK_eff = KMAC(MK, "QSP4.3/MK-PQ", pq_ss, 32)`; else set `MK_eff = MK`.
   - `body_ct = AEAD_Enc(MK_eff, nonce_body, AD_body, m)`.

12) If `flags` includes `FLAG_PQ_CTXT`:
   - Update the root key: `st.RK = KDF_RK_PQ(st.RK, pq_ss)`.
   - Recompute `HK_s/HK_r/NHK_s/NHK_r` from the updated `st.RK`.

13) If `is_boundary`: clear `st.boundary_pending` (set to 0). Output the message.

**Send-side durability rule (normative):**
If the implementation persists session state, it MUST ensure that the state updates in steps (3), (12), and (13) are durably committed in a crash-consistent manner. In particular, it MUST NOT send a boundary message to the transport while persisting a pre-boundary state that would cause the sender to reuse `FLAG_BOUNDARY` semantics or lose the applied PQ mixing update on restart.


### 9.4 Header decrypt procedure (bounded, with source tagging)
Given `msg.Prefix`, the receiver attempts header decryption in this order, bounded by `MAX_HEADER_ATTEMPTS`:
For each attempt, the receiver MUST compute `AD_hdr` per §6.1 for `msg.suite_id` (including `pq_bind` for Suite-1B).
The receiver MUST use it as AEAD associated data when opening `hdr_ct`.

1) Try `HK_r` (current) to decrypt `hdr_ct`. If it succeeds, record `hdr_source = CURRENT_HK`.
2) Try `NHK_r` (current next-header key) to decrypt `hdr_ct`. If it succeeds, record `hdr_source = CURRENT_NHK`.
3) If `msg.DH_pub` exists in `HKSKIPPED`, try the cached pair:
   - `HK_r_old`, then `NHK_r_old`, and record `hdr_source = SKIPPED_HK` or `SKIPPED_NHK` on success.

If all attempts fail, header decrypt fails.

On success, parse `HeaderPlain` to obtain `(PN, N)`.

**Invariant:** An implementation MUST NOT perform a DH receive-ratchet solely because `msg.DH_pub != st.DH_peer`.
It MUST distinguish (a) a truly new DH public key (boundary message) from (b) a delayed message from an old epoch.

### 9.5 RatchetDecrypt (complete)
Input: durable state `st`, received `msg`.

1) Parse and validate the prefix, lengths, and flags. Reject unknown flags.
2) Work on a copy `tmp = st`.
3) Decrypt header using §9.4 to obtain `(PN, N, hdr_source)`. If FAIL: drop.

4) If `msg.DH_pub != tmp.DH_peer`:
   - If `msg.DH_pub` exists in `tmp.HKSKIPPED` OR `hdr_source` is `SKIPPED_HK`/`SKIPPED_NHK`:
     - This is a delayed message from an old epoch. The receiver MUST NOT DH-ratchet.
     - The receiver MUST reject the message if `FLAG_BOUNDARY` is set (boundary flag on an old-epoch message is a protocol violation).
     - Proceed directly to step 6 (MKSKIPPED lookup).
   - Else:
     - This is a candidate new DH epoch. The receiver MUST require `FLAG_BOUNDARY` to be set.
     - The receiver MUST require `hdr_source == CURRENT_NHK` (boundary anti-spoof rule).
     - If either condition fails, drop (protocol violation / spoofing attempt).
     - Run `DHRatchetReceive(tmp, msg.DH_pub, PN)`.

5) If `msg.DH_pub == tmp.DH_peer` and `FLAG_BOUNDARY` is set:
   - The receiver MUST require `hdr_source == CURRENT_NHK` (boundary header key usage).
   - If `hdr_source != CURRENT_NHK`, drop (protocol violation).

6) Attempt skipped-key decrypt:
   - If `(msg.DH_pub, N)` in `tmp.MKSKIPPED`: let `MK = stored MK`, delete entry.
   - If `FLAG_PQ_CTXT` is set:
       - Verify `pq_target_id` is present and refers to a retained PQ receive key.
       - `pq_ss = MLKEM_Decap(PQ_self_keys[pq_target_id].priv, pq_ct)
       - After successful decapsulation and once the message is accepted, the receiver MUST delete `PQ_self_keys[pq_target_id]` (wipe private key material) and MUST reject future uses of the same `pq_target_id`.`.
       - `MK_eff = KMAC(MK, "QSP4.3/MK-PQ", pq_ss, 32)`.
     Else: `MK_eff = MK`.
   - Decrypt body using `MK_eff`. If OK: apply step 11/12 then commit and return. If FAIL: drop (do not commit).

7) If this was an old-epoch delayed message (as determined in step 4) and no MKSKIPPED entry exists: drop.

8) For current-epoch messages:
   - If `N - tmp.Nr > MAX_SKIP`: drop.
   - While `tmp.Nr < N`:
       `(tmp.CK_r, MKi) = KDF_CK(tmp.CK_r)`; store `MKSKIPPED[(tmp.DH_peer, tmp.Nr)] = MKi`; `tmp.Nr += 1`.
   - Derive the message key:
       `(tmp.CK_r, MK) = KDF_CK(tmp.CK_r)`; `tmp.Nr += 1`.

9) If `FLAG_PQ_CTXT` is set:
   - Verify `pq_target_id` is present and refers to a retained PQ receive key.
   - Decapsulate: `pq_ss = MLKEM_Decap(PQ_self_keys[pq_target_id].priv, pq_ct)
       - After successful decapsulation and once the message is accepted, the receiver MUST delete `PQ_self_keys[pq_target_id]` (wipe private key material) and MUST reject future uses of the same `pq_target_id`.`.
   - Derive `MK_eff = KMAC(MK, "QSP4.3/MK-PQ", pq_ss, 32)`.
  Else: `MK_eff = MK`.

10) Decrypt body:
   - Compute `nonce_body` per §6.2 and decrypt `body_ct` with `MK_eff`. If FAIL: drop (do not commit).

11) If `FLAG_PQ_CTXT` is set:
    - Update `tmp.RK = KDF_RK_PQ(tmp.RK, pq_ss)` and recompute header keys.

12) If `FLAG_PQ_ADV` set: set `tmp.PQ_peer_id/pub` from `pq_adv_id/pub`.

13) Commit `st = tmp`. Return plaintext.

### 9.6 Skipped message-key storage (MKSKIPPED)

Input: durable state `st`, received `msg`.

1) Parse and validate the prefix, lengths, and flags. Reject unknown flags.
2) Work on a copy `tmp = st`.
3) Decrypt header using §9.4 to obtain `(PN, N)`. If FAIL: drop.
4) If `msg.DH_pub != tmp.DH_peer`: run `DHRatchetReceive(tmp, msg.DH_pub, PN)`.
5) Attempt skipped-key decrypt:
   - if `(msg.DH_pub, N)` in `tmp.MKSKIPPED`: let `MK = stored MK`, delete entry.
   - If `FLAG_PQ_CTXT` is set:
       `pq_ss = MLKEM_Decap(PQ_self_keys[pq_target_id].priv, pq_ct)
       - After successful decapsulation and once the message is accepted, the receiver MUST delete `PQ_self_keys[pq_target_id]` (wipe private key material) and MUST reject future uses of the same `pq_target_id`.`; `MK_eff = KMAC(MK, "QSP4.3/MK-PQ", pq_ss, 32)`.
     Else: `MK_eff = MK`.
   - Decrypt body using `MK_eff`. If OK: apply step 10/11 then commit and return. If FAIL: drop.
6) If `N - tmp.Nr > MAX_SKIP`: drop.
7) Derive and cache skipped message keys:
   - while `tmp.Nr < N`: `(tmp.CK_r, MKi) = KDF_CK(tmp.CK_r)`; store in `MKSKIPPED[(tmp.DH_peer, tmp.Nr)] = MKi`; `tmp.Nr += 1`.
8) Derive the message key:
   - `(tmp.CK_r, MK) = KDF_CK(tmp.CK_r)`; set `tmp.Nr += 1`.
9) If `FLAG_PQ_CTXT` is set:
   - `pq_ss = MLKEM_Decap(PQ_self_keys[pq_target_id].priv, pq_ct)
       - After successful decapsulation and once the message is accepted, the receiver MUST delete `PQ_self_keys[pq_target_id]` (wipe private key material) and MUST reject future uses of the same `pq_target_id`.`; `MK_eff = KMAC(MK, "QSP4.3/MK-PQ", pq_ss, 32)`.
  Else: `MK_eff = MK`.
10) Compute `nonce_body` per §6.2 and decrypt `body_ct` with `MK_eff`. If FAIL: drop (do not commit).
11) If `FLAG_PQ_CTXT` is set: update `tmp.RK = KDF_RK_PQ(tmp.RK, pq_ss)` and recompute header keys.
12) If `FLAG_PQ_ADV` set: set `tmp.PQ_peer_id/pub` from `pq_adv_id/pub`.
13) Commit `st = tmp`. Return.

### 9.7 MKSKIPPED storage requirements
Implementations MUST:
- enforce TTL and cap (`MAX_MKSKIPPED`),
- evict oldest entries first,
- treat MKSKIPPED keys as secrets (wipe on eviction),
- never scan more than `MAX_MKSKIPPED_SCAN = 50` entries per message (DoS bound).

---

## 10. Security considerations (normative requirements)

### 10.1 Downgrade resistance
Implementations MUST reject unknown `protocol_version`, unknown `suite_id`, and unknown `flags` bits.

Once a session is established, implementations MUST treat the tuple `(protocol_version, suite_id, session_id)` as immutable session parameters. Any received message whose `protocol_version` or `suite_id` does not match the locally stored session parameters MUST be rejected.

Implementations MUST NOT silently fall back from Suite-1B to Suite-1, or from Authenticated mode to any weaker mode, without an explicit user-/policy-level decision outside of the protocol.

### 10.2 RNG quality
- Ephemeral key generation (X25519 ephemeral keys, ML-KEM keypairs, and ML-DSA randomness) MUST use a cryptographically secure RNG.
- Implementations MUST fail closed if RNG failure is detected.
- `nonce_hdr` and `nonce_body` are deterministic per §6.2.

### 10.3 Side-channel considerations
- Signature/tag comparisons MUST be constant time.
- Secret key material MUST be wiped when discarded.
- Implementations SHOULD use constant-time primitives for DH/KEM operations when available.

---

### 10.4 Hybrid composition and security claims (normative clarity)

This specification uses **hybrid** constructions in two places:
- handshake master secret derivation (§5.4–§5.5), and
- boundary-message PQ mixing (§9.3, §9.5).

The protocol is intended to provide confidentiality and authentication under the standard hybrid goal:
- if at least one of the classical components (X25519) **or** the PQ components (ML-KEM / ML-DSA) remains secure, the resulting session keys remain indistinguishable from random to a network adversary.

Normative clarifications:
- Implementations MUST treat **all** handshake inputs (`ss1`, optional `ss2`, `dh1`, optional `dh2`) as secret and MUST wipe them after `RK0` derivation.
- Implementations MUST NOT omit the classical DH terms when PQ terms are present, and MUST NOT omit the PQ terms when PQ terms are present and decapsulation succeeds.
- Any failure to decapsulate (e.g., malformed ciphertext) MUST cause handshake rejection.

This document does not claim security if **both** the classical and PQ assumptions fail.

### 10.5 Suite negotiation, pinning, and anti-downgrade policy (normative)

- Suite selection occurs in HandshakeInit via `suite_id` and is authenticated by the handshake transcripts (HS1/HS2).
- Responder B MUST reject HandshakeInit if `suite_id` is not supported, and MUST NOT respond with a different `suite_id`.
- Initiator A MUST reject HandshakeResp if `suite_id` differs from its HandshakeInit.

For ongoing messaging:
- A session MUST be bound to exactly one suite. Implementations MUST NOT accept messages under a different suite for the same `session_id`.

### 10.6 Replay, rollback, and state persistence (normative)

Correctness and security require that durable session state does not roll back.

Implementations that persist session state MUST:
- commit state updates atomically (copy-then-commit, journaling, or transactional storage),
- ensure that `RK`, chain keys, counters, and caches cannot revert to earlier values after a crash or power loss,
- treat any detected rollback as a fatal error for that session (session MUST be discarded and re-established).

Implementations SHOULD include an anti-rollback mechanism appropriate to the platform, such as:
- monotonic counters,
- append-only journals with integrity protection, or
- hardware-backed secure storage.

### 10.7 Boundary-message anti-spoof and PQ mixing invariants (normative summary)

The following invariants are required for security and interoperability:

- A **new DH epoch** MUST be introduced only by a **boundary message**.
- Boundary messages MUST be encrypted using the **pre-ratchet next-header key** (`NHK_s` captured before the send ratchet), and receivers MUST require `hdr_source == CURRENT_NHK` when accepting a new epoch.
- PQ fields (`FLAG_PQ_ADV`, `FLAG_PQ_CTXT`) MUST be sent only on boundary messages.
- A `pq_target_id` used for decapsulation MUST refer to a currently retained PQ receive key; after a successful decapsulation that is committed, that receive key MUST be deleted (wiped) and MUST NOT be accepted again.

### 10.8 Counter exhaustion (normative)
To preserve nonce-uniqueness and avoid ambiguity, implementations MUST apply §8.3.1. In particular, implementations MUST terminate and re-establish a session before any `u32` counter would wrap.

## 11. Test vectors and conformance (normative hooks)

### 11.1 Test vector publication
The project MUST publish test vectors for:
- bundle signing and verification,
- KT STH verification and proof checking,
- handshake transcripts HS1/HS2 and RK0,
- first 10 messages including at least one boundary message,
- out-of-order delivery (skipped keys),
- header-key rotation and HKSKIPPED behavior,
- PQ boundary mixing.

### 11.2 Conformance checklist
A conformance checklist SHALL be maintained that maps every MUST/MUST NOT to an executable test.

---

### 11.3 Conformance checklist (normative requirement)

A **conformance checklist** SHALL be maintained and version-controlled alongside this specification.
It MUST map every **MUST / MUST NOT** requirement in QSP to one or more executable tests.

At minimum, the checklist MUST include:
- a stable requirement identifier (e.g., `QSP-4.3.2-REQ-####`),
- the spec section reference,
- a short statement of the requirement,
- test strategy (unit, property-based, interop, fuzz),
- expected pass/fail criteria,
- negative tests (malformed inputs / adversarial cases).

A checklist skeleton is provided in Appendix B and is normative for structure (fields), but not for coverage (coverage must be complete).

### 11.4 Test vectors: format and publication (normative)

To support independent implementations and cryptographic review, the project MUST publish **canonical test vectors** in a machine-readable format.

#### 11.4.1 Vector format
Test vectors MUST be published as:
- JSON (preferred) or CBOR,
- with all byte strings encoded as lowercase hex,
- with explicit endianness for all integers (big-endian unless otherwise stated),
- with domain-separation labels included verbatim.

Each vector MUST include:
- `protocol_version`, `suite_id`,
- all private inputs required to reproduce the computation (unless explicitly marked “public-only” vectors),
- all intermediate transcript hashes (HS1/HS2) and derived keys (RK0, HK/NHK, CK/MK as applicable),
- full on-wire serialized messages where relevant.

#### 11.4.2 Required vector sets (minimum)
The published suite MUST include at least the following vector sets:

1) **KT vectors**
   - STH signature verification (Ed25519 + ML-DSA-65)
   - inclusion proof verification
   - consistency proof verification
   - rollback rejection case

2) **Prekey bundle vectors**
   - BundleTBS construction
   - bundle signature verification
   - canonical proof parsing rejection cases (trailing bytes, overlong counts)

3) **Handshake vectors**
   - HS1/HS2 transcript hashes
   - signature verification for both parties
   - RK0 derivation inputs and output
   - `conf_B` computation and verification
   - downgrade/mismatch rejection cases (suite_id mismatch, session_id mismatch)

4) **Messaging vectors (baseline)**
   - first 10 messages, including at least:
     - one boundary message with `FLAG_PQ_ADV` only
     - one boundary message with both `FLAG_PQ_ADV` and `FLAG_PQ_CTXT`
     - at least one non-boundary message
   - deterministic `nonce_hdr` and `nonce_body` correctness

5) **Out-of-order vectors**
   - skipped message keys (MKSKIPPED) behavior
   - HKSKIPPED behavior across one epoch boundary
   - DoS bound enforcement cases (MAX_SKIP, MAX_HEADER_ATTEMPTS)

6) **PQ mixing vectors**
   - PQ encapsulation/decapsulation correctness at boundary
   - RK update ordering correctness (pre/post decapsulation)
   - one-time `pq_target_id` enforcement (reuse rejection)

#### 11.4.3 Implementation notes
Vectors MUST be generated from a reference generator that is itself tested.
Vectors MUST be stable once published; changes require a new vector version and changelog.

## Appendix B. Conformance checklist skeleton (normative structure)

The following table defines the **minimum required fields** for the conformance checklist.
Implementations and the reference test suite MUST maintain an entry for every MUST/MUST NOT requirement in this specification.

| Requirement ID | Level | Spec section | Requirement (normative text summary) | Test type | Positive test(s) | Negative/abuse test(s) | Notes |
|---|---|---|---|---|---|---|---|
| QSP-4.3.2-REQ-0001 | MUST | 2.3 | Reject truncated fields and trailing bytes | unit/fuzz | Valid parse accepted | Truncation rejected; trailing bytes rejected |  |
| QSP-4.3.2-REQ-0002 | MUST | 6.2 | `nonce_hdr` must match H(label || session_id || DH_pub || N) | unit/property | Correct nonce accepted | Nonce mismatch rejected |  |
| QSP-4.3.2-REQ-0003 | MUST | 8.4 | New DH epoch requires FLAG_BOUNDARY and CURRENT_NHK | interop | Boundary accepted | Spoofed epoch rejected |  |
| QSP-4.3.2-REQ-0004 | MUST | 10.1 | Reject messages with mismatched suite_id/protocol_version | unit | Match accepted | Mismatch rejected |  |
| QSP-4.3.2-REQ-0005 | MUST | 10.6 | Atomic commit and no rollback of RK/counters | integration | Crash-safe commit | Rollback detected → session discarded |  |

Checklist maintainers MUST expand this table to complete coverage.

## Appendix A. Domain separation labels
This document uses labels prefixed with `QSP4.3/` and MUST NOT reuse labels across different purposes.
