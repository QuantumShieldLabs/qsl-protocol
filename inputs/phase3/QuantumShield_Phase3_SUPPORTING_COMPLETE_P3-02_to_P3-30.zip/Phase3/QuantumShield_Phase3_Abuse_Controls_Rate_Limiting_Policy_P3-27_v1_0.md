# QuantumShield Phase 3 — Abuse Controls & Rate Limiting Policy
**Artifact ID:** P3-27  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (alignment only):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Related Phase 3 artifacts (alignment only):** P3-11 (Operational Security & Privacy Hardening Runbook), P3-14 (Schemas/Reason Codes), P3-16 (CI Harness), P3-20 (AuthN/AuthZ), P3-24 (Client Retry/Backoff), P3-26 (Observability/SLOs)  
**Version:** 1.0  
**Date:** 2025-12-19  
**Timezone:** America/Chicago  

## 0. Purpose and scope
This document specifies **abuse controls** and a **rate limiting policy** for QuantumShield Phase 3 services (RSF, PDS, KTL). It is designed to:

- prevent denial-of-service (DoS) and resource exhaustion,
- mitigate user/device enumeration and routing token probing,
- provide deterministic, testable behavior across independent implementations,
- preserve privacy and avoid telemetry leakage while enabling incident response.

This is a **supporting** artifact (atomic). It does not modify QSP/QSE wire formats.

## 1. Non-negotiable principles
1. **No security by obscurity:** rate limits are an operational control, not a security boundary; cryptographic and authorization checks remain mandatory.
2. **Fail closed on malformed input:** parsing/canonicalization failures MUST be rejected early and MUST NOT consume expensive resources.
3. **Bounded work per request:** endpoints MUST cap CPU, memory, DB reads/writes, and response size.
4. **Least privilege:** higher-cost endpoints require stronger authorization scopes and tighter budgets.
5. **Privacy by design:** rate limiting MUST NOT require logging raw stable identifiers (route_token, user_handle, device_id); use coarse buckets and rotating salted hashes when correlation is required.
6. **Deterministic errors:** services MUST return standardized reason codes (P3-14) and stable status classes for rate-limit outcomes to support client behavior (P3-24) and interop testing (P3-16).

## 2. Threat model (what this policy defends against)
This policy addresses, at minimum:
- bulk request floods (L7 DoS),
- expensive-proof amplification (KTL proofs),
- OPK depletion attacks (PDS get_bundles with required OPK),
- inbox scraping and delivery disruption (RSF fetch/ack),
- enumeration oracles (probing user_handle/device existence),
- token replay at service edges (rotate/register/publish),
- retry storms from clients and intermediaries.

It is not a substitute for:
- network-layer DDoS protection,
- WAF/bot mitigation for public endpoints,
- secure key management (P3-28),
- correct authorization (P3-20).

## 3. Control layers (defense in depth)
Abuse controls MUST be layered:

### 3.1 Layer 0 — Network edge controls (recommended)
At CDN / edge proxy / load balancer:
- connection caps per source,
- request size limits,
- TLS handshake rate limiting,
- IP reputation and geo controls (deployment policy),
- optional bot mitigation for public endpoints.

Edge controls may see IP addresses; application services SHOULD NOT store raw IPs.

### 3.2 Layer 1 — Request validation gates (MUST)
Before authZ and DB work:
- enforce `Content-Type`,
- enforce maximum body size per endpoint,
- strict base64url decoding (reject padding and invalid characters),
- strict canonical parsing for QSE at enqueue and for KT varbytes if served directly,
- reject unknown/unsupported fields.

### 3.3 Layer 2 — AuthN/AuthZ and principal quotas (MUST)
- validate tokens (P3-20),
- enforce scopes per endpoint,
- apply per-principal budgets (device principal preferred).

### 3.4 Layer 3 — Targeted resource quotas (MUST)
Apply quotas keyed to the **target resource** without revealing existence:
- RSF: inbox_id bucket (derived after authZ + binding),
- PDS: target user_handle bucket (for get_bundles) and device bucket (for publish/upload),
- KTL: log_id bucket (coarse), and proof size caps.

### 3.5 Layer 4 — Progressive controls (recommended)
If abuse is detected:
- temporary greylisting (increasing delays),
- stricter per-endpoint caps,
- require re-auth (short TTL tokens),
- operator intervention (blocklist or account/device lock).

Progressive controls MUST preserve privacy and avoid “exists” oracles.

## 4. Standard outcomes and reason codes
Services MUST use these outcome classes:

- **Allowed**: process normally.
- **Soft limited**: return 429 `rate_limited` with optional `Retry-After`.
- **Hard limited**: return 429 `rate_limited` and optionally enforce a longer cool-down (e.g., 5–30 minutes).
- **Suspicious**: return 429 `rate_limited` or 403 `forbidden` depending on auth context; record sanitized security event.

Required reason codes (P3-14):
- `rate_limited`
- `auth_failed`
- `forbidden`
- `invalid_request`
- `service_unavailable`
- `conflict`
- `not_found` (only when authorized to know existence)

## 5. Keys for limiting (privacy-safe)
Rate limiting keys MUST be derived as follows:

### 5.1 Principal key (preferred)
- `principal_key = H32("rl:principal" || salt_epoch || sub || env)`
Where `sub` is token subject. `salt_epoch` rotates at least daily.

### 5.2 Endpoint key
- `endpoint_key = (service, endpoint_group, method)`

### 5.3 Target key (resource bucket)
- RSF: after authZ resolves route_token → inbox_id, use
  - `target_key = H32("rl:inbox" || salt_epoch || inbox_id)`
- PDS get_bundles: use
  - `target_key = H32("rl:target_user" || salt_epoch || user_handle)` (user_handle treated as bytes)
- PDS device-bound endpoints:
  - `target_key = H32("rl:device" || salt_epoch || user_handle || u32(device_id))`
- KTL: use a **coarse log bucket**:
  - `target_key = H32("rl:logbucket" || salt_epoch || log_id_bucket)`

### 5.4 Anonymous key (public endpoints only)
If an endpoint is public:
- the edge applies IP-based controls,
- the app may apply a coarse “anonymous bucket” (no per-IP storage):
  - `anon_key = H32("rl:anon" || salt_epoch || coarse_edge_bucket_id)`
where `coarse_edge_bucket_id` is provided by the edge as a privacy-safe bucket token, not a raw IP.

### 5.5 Prohibited keys
The following MUST NOT be used as raw limiting keys in application storage:
- raw route_token,
- raw user_handle,
- raw device_id,
- raw IP address.

## 6. Rate limiting algorithms (normative)
Implementations MUST support one of these algorithms per key:
- **Token bucket** (recommended) for bursty traffic
- **Leaky bucket** for smoothing
- **Fixed window** only if combined with jitter and secondary smoothing (discouraged)

All implementations MUST:
- enforce a **burst** parameter,
- provide a deterministic `Retry-After` (seconds) when returning 429,
- keep state in a low-latency store (in-memory per instance is acceptable only if paired with edge + per-instance caps; centralized store is preferred for correctness).

## 7. Endpoint groups and default budgets (recommended baseline)
Budgets are defined in requests per minute (rpm) with burst capacity. Deployments MUST tune based on scale and risk, but SHOULD not exceed these defaults without review.

Notation:
- `rpm` = steady-state limit per principal_key per endpoint group
- `burst` = maximum tokens that can be spent immediately

### 7.1 RSF budgets
#### 7.1.1 `rsf_enqueue`
- Limit: 120 rpm, burst 60 (per principal)
- Additional: 20 rpm, burst 10 (per target inbox bucket) to prevent targeted flood
- Body size cap: `qse.max_envelope_len` (hard)

#### 7.1.2 `rsf_fetch`
- Limit: 60 rpm, burst 30 (per principal)
- Additional: 60 rpm, burst 30 (per target inbox bucket)
- Concurrency cap: 1 in-flight fetch per inbox (recommended)
- Long-poll cap: wait_seconds <= deployment cap; count wall time toward budget

#### 7.1.3 `rsf_ack`
- Limit: 120 rpm, burst 60 (per principal)
- Additional: 120 rpm, burst 60 (per target inbox bucket)
- Ack list size cap: deployment-defined (recommended <= 256 handles)

#### 7.1.4 `rsf_rotate` and `rsf_register`
- Limit: 6 rpm, burst 3 (per principal)
- Target cap: 6 rpm (per inbox bucket)
- Required: idempotency (P3-20/P3-24 alignment)
- Replay control: track jti for 10 minutes (recommended)

### 7.2 PDS budgets
#### 7.2.1 `pds_get_bundles`
- Limit: 30 rpm, burst 10 (per principal)
- Additional: 12 rpm, burst 6 (per target user bucket) to prevent enumeration
- Hard cap: max devices requested per call (recommended <= 16)
- If OPK policy is required: apply an additional cap of 10 rpm (per principal) to reduce OPK depletion pressure.

#### 7.2.2 `pds_publish_bundle`
- Limit: 12 rpm, burst 6 (per device principal)
- Target cap: 12 rpm (per device bucket)
- Required: idempotency; jti replay cache (10 minutes recommended)

#### 7.2.3 `pds_upload_opk_*` (DH and PQ)
- Limit: 6 rpm, burst 3 (per device principal)
- Target cap: 6 rpm (per device bucket)
- Hard cap: max OPKs per request (recommended <= 64)
- Hard cap: enforce pool cap per device (P3-17 alignment)

#### 7.2.4 `pds_revoke_device`
- Limit: 3 rpm, burst 2 (per device principal and/or operator)
- Treat as high-risk admin-like action.

#### 7.2.5 `pds_inventory`
- Limit: 30 rpm, burst 10 (per device principal)
- Inventory MUST be coarse buckets only (no exact counts).

### 7.3 KTL budgets
#### 7.3.1 `ktl_get_sth`
If public:
- edge controls dominate; app limit: 120 rpm burst 60 per anon_key.
If authenticated:
- 120 rpm burst 60 per principal.

#### 7.3.2 `ktl_get_inclusion_proof` / `ktl_get_consistency_proof`
- Limit: 30 rpm burst 10 per principal (or anon_key if public)
- Additional: 30 rpm burst 10 per log bucket
- Proof size caps: count <= 64; reject invalid/oversize requests early.

#### 7.3.3 `ktl_append` (operator-only)
- Limit: deployment-defined; MUST be isolated from public traffic.
- Require mTLS + operator scope; strict audit.

## 8. Enumeration defenses (PDS and RSF)
### 8.1 Error normalization (MUST)
To prevent “exists” oracles:
- Unauthorized callers MUST receive 401/403 without revealing existence.
- For sensitive endpoints, prefer a single normalized error path for:
  - non-existent target, and
  - unauthorized target.
This can be implemented as 403 `forbidden` in both cases.

### 8.2 Rate limits keyed to target bucket (MUST)
Even authorized initiators can enumerate by probing many targets. Therefore:
- `pds_get_bundles` MUST enforce both per-principal and per-target bucket limits.
- Exceeding per-target bucket limit MUST return 429 `rate_limited` without indicating whether the target exists.

### 8.3 Greylisting policy (recommended)
If a principal exceeds per-target bucket limits across many targets:
- apply a temporary “greylist” state for that principal (e.g., 15 minutes),
- while greylisted, reduce `pds_get_bundles` to 5 rpm burst 2.

## 9. Abuse signals and automated responses
### 9.1 Signals (minimum)
- spikes in 401/403/429
- repeated invalid_request / noncanonical rejects (possible fuzzing)
- repeated rotate/register attempts
- OPK depletion anomalies (consumption high + uploads absent)
- KTL proof request spikes with maximal proof sizes

### 9.2 Automated responses (recommended)
- increase backoff hints (`Retry-After`) and reduce burst
- enable temporary per-principal cool-down
- require re-auth (short TTL tokens)
- quarantine a device principal if it produces repeated malformed requests (with caution; avoid attacker-triggered account lockouts)

## 10. Logging and telemetry (alignment with P3-26)
Rate limiting telemetry MUST be privacy-safe:
- metrics: `qshield_rate_limited_total{service,endpoint}` only; no identifiers
- logs: record reason_code and endpoint, not keys
- security audit stream MAY record salted hashes of principal for correlation, never raw identifiers.

## 11. Test requirements (CI / interop)
A conformance harness (P3-16) MUST include:
1. **429 determinism:** rate-limited responses return 429 with reason_code `rate_limited`.
2. **Retry-After sanity:** when present, Retry-After is <= configured cap.
3. **No existence oracle:** probes of random targets yield indistinguishable responses under unauthorized context.
4. **Bounded work:** oversized proof requests are rejected prior to expensive computation.
5. **JTI replay control:** rotate/register/publish reject obvious replay within window.
6. **No identifier leakage:** marker-based tests confirm route_token/user_handle never appears in logs.

## 12. Parameter registry keys (recommended)
Deployments SHOULD surface the following keys (P3-12 style):
- `rl.salt_epoch_seconds` (default 86400)
- Per endpoint group: `rl.<group>.rpm`, `rl.<group>.burst`
- `rl.greylist_seconds` (default 900)
- `rl.jti_replay_window_seconds` (default 600)
- `rl.retry_after_cap_seconds` (default 120)

---
**End of document.**
