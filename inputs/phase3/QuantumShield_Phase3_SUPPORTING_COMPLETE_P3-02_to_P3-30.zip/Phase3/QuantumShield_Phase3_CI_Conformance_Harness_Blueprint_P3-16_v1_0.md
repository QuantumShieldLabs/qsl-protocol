# QuantumShield Phase 3 — CI/Conformance Harness Blueprint
**Artifact ID:** P3-16  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (alignment only):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Related Phase 3 artifacts:** P3-03 (Conformance Checklist), P3-04 (Interop Test Plan), P3-08 (Vector Format), P3-12 (Parameter Registry), P3-13 (OpenAPI), P3-14 (Shared Schemas)  
**Version:** 1.0  
**Date:** 2025-12-20  
**Timezone:** America/Chicago  

## 0. Purpose and scope
This blueprint defines how to implement an automated, repeatable **CI and conformance harness** for Phase 3 QuantumShield systems. The harness is designed to:
- gate releases of **clients/SDKs** and **services** (RSF/PDS/KTL),
- enforce the Phase 3 conformance surface (P3-03),
- ensure cross-language **interoperability** (P3-04),
- validate canonical parsing and bounds enforcement (QSP/QSE),
- validate Key Transparency (KT) proof verification behavior (where applicable),
- run negative tests and fuzzing to harden parsers and state machines, and
- provide unambiguous release acceptance criteria.

This document is **supporting** and **atomic**: it is directly implementable without requiring external documents for meaning.

## 1. Principles (non-negotiable)
1. **Fail closed:** Any parse/verify/decrypt failure is a hard failure; CI must ensure code paths do not degrade to insecure behavior.
2. **Determinism:** Vector-driven tests are deterministic and must match expected bytes bit-for-bit.
3. **Canonical parsing:** The harness must include tests for trailing bytes, length smuggling, and non-canonical varbytes.
4. **Bounded work:** Tests must enforce QSP/QSE bounds (DoS resistance) and ensure loops are bounded as specified.
5. **Crash-safety:** Persistence tests must validate copy-then-commit semantics and that no partial state advances on failure.
6. **No production secrets:** Harness secrets exist only in test fixtures; production code must not log or export secrets.

## 2. What CI must cover (minimum gates)
CI must include these mandatory gate categories for Phase 3:

### 2.1 Static gates
- Formatting/linting
- Dependency lock and policy checks (deny unpinned transitive upgrades)
- Secret scanning (prevent accidental key commits)
- License checks (deployment policy)

### 2.2 Functional gates (clients/SDKs)
- Unit tests for parsers and serialization
- Vector suite (P3-08) known-answer tests
- Negative vectors (malformed, trailing bytes, out-of-bounds)
- Interop matrix (P3-04) against at least one reference implementation
- Property tests for invariants (bounded caches, replay behavior)
- Crash-safety tests (P3-07 alignment) with fault injection

### 2.3 Functional gates (services)
- OpenAPI schema validation for request/response shapes (P3-13)
- Shared schema validation (P3-14) including strict base64url decoding rules
- Contract tests for RSF/PDS/KTL endpoints (golden request/response cases)
- Abuse controls sanity (rate limit paths respond correctly without leaking identifiers)
- OPK at-most-once tests (PDS) under concurrency and crash simulation (P3-06 alignment)
- RSF route_token rotation behavior tests (P3-09 alignment)

### 2.4 Robustness gates
- Fuzzing (parser fuzz targets for QSE envelope, QSP messages, KT objects, and service JSON)
- Coverage thresholds (deployment policy; recommended ≥ 80% on core modules)
- Performance budgets (optional but recommended; prevent quadratic regressions)

## 3. Repository layout (recommended)
This layout supports multi-language SDKs plus service components. Names are illustrative.

```
repo/
  specs/                      # frozen canonical specs (read-only references)
  phase3/
    artifacts/                # P3-* documents (supporting)
    schemas/                  # P3-14 JSON schemas
    openapi/                  # P3-13 OpenAPI
    vectors/                  # P3-08 vector sets (published)
  sdk/
    rust/
    swift/
    kotlin/
    typescript/
  services/
    rsf/
    pds/
    ktl/
  test-harness/
    runner/                   # vector + conformance runner
    interop/                  # interop orchestrator
    fuzz/                     # fuzz targets and corpora
    fixtures/                 # stable fixtures (keys/seeds) for vectors
    docker/                   # docker-compose, ephemeral env
  ci/
    workflows/                # CI definitions (GitHub Actions, GitLab, etc.)
    scripts/                  # helper scripts used by CI
```

## 4. Harness components and responsibilities
### 4.1 Vector Runner (VR)
**Purpose:** Consume P3-08 vector JSON, execute operations, and compare outputs byte-for-byte.

Minimum features:
- strict base64url decoding (reject padding and invalid chars),
- strict canonical decoding of QSP/QSE/KT bytes (reject trailing bytes),
- suite selection and feature gating (Suite-1 vs Suite-1B),
- deterministic state handling with explicit reset between cases,
- negative-case enforcement: on failure, state MUST NOT commit.

Outputs:
- JUnit/XML or similar machine-readable results,
- per-case result with reason codes (use P3-14 enum where applicable),
- optional artifact dump for failed cases (sanitized).

### 4.2 Conformance Evaluator (CE)
**Purpose:** Evaluate P3-03 checklist items automatically where feasible.

Mechanism:
- Map checklist items to one or more tests (vectors, property tests, contract tests).
- Produce a conformance report per build, including:
  - PASS/FAIL per item,
  - link to evidence (test IDs),
  - configuration snapshot (P3-12 profile + overrides hash).

CE MUST treat any “Required” checklist item failure as a release-blocker.

### 4.3 Interop Orchestrator (IO)
**Purpose:** Execute P3-04 interop scenarios across implementations.

Minimum interop matrix for Phase 3:
- at least one “reference” implementation (e.g., Rust refimpl),
- at least one other implementation under test (Swift/Kotlin/TS),
- both Suite-1 and Suite-1B where supported.

Scenarios:
- handshake: A->B and B->A,
- messaging: first 10 messages with boundary and out-of-order case,
- QSE transport: RSF enqueue/fetch/ack round trip using opaque payload,
- KT verification: inclusion/consistency proofs where authenticated mode enabled.

IO should run in a containerized ephemeral environment to standardize dependencies.

### 4.4 Service Contract Test Harness (SCH)
**Purpose:** Validate RSF/PDS/KTL endpoint behavior against P3-13 OpenAPI and P3-09/P3-06 semantic contracts.

Minimum tests:
- schema validation: request/response bodies conform to OpenAPI and shared schema constraints,
- authZ enforcement: endpoints reject unauthorized access without leaking existence,
- bounds enforcement: RSF rejects non-canonical QSE and oversize inputs,
- route_token rotation overlap behavior,
- OPK consume atomicity under concurrency for PDS,
- KTL STH/proof endpoints respond with canonical bytes and reject malformed requests.

### 4.5 Fuzz Harness (FH)
**Purpose:** Discover parser and state machine edge cases.

Required fuzz targets:
- QSE envelope parser (all fields, length smuggling, trailing bytes),
- QSP message parser (header/body lengths, flags, varbytes),
- KT object parser (STH, inclusion proof, consistency proof varbytes),
- service JSON parser (base64url decoding, enum validation).

Fuzz requirements:
- must be fail-closed (no panics that allow partial state commit),
- include corpus seeded from negative vectors and real-world edge cases,
- integrate with CI with a bounded time budget (e.g., 5–15 minutes per PR) and longer nightly runs.

## 5. Test inventory mapped to Phase 3 artifacts
This section provides a concrete mapping for gating.

### 5.1 P3-08 vectors (mandatory)
- Run VR for every PR on core crypto and parsing modules.
- Vector set versions are pinned; updates require explicit approval and changelog entry.
- Failures are release blockers.

### 5.2 P3-03 conformance checklist (mandatory)
CE MUST map at least these categories:
- Canonical parsing and bounds (QSE/QSP): enforced via negative vectors + fuzz corpus + unit tests.
- OPK at-most-once semantics: contract tests and concurrency tests for PDS.
- Transactional receive: crash-safety tests (fault injection) plus unit-level state commit checks.
- KT rollback resistance: pinned state tests; simulated rollback.
- Logging redlines: static checks (grep/AST rules) + runtime tests for log sanitization.

### 5.3 P3-04 interop test plan (mandatory)
IO runs:
- on every merge to main (or at least daily),
- on release candidate tags.

### 5.4 P3-12 configuration validation (mandatory)
Add a CI step:
- validate configuration documents against P3-12 rules:
  - canonical caps not exceeded,
  - interop sizing constraint holds (`qsp.max_body_ct_len` within `qse.max_payload_len`),
  - logging redlines not violated (raw identifiers disabled),
  - fail-closed flags remain enabled.

### 5.5 P3-13 / P3-14 schema validation (mandatory)
- Validate service implementations against OpenAPI and shared schema:
  - OpenAPI linting,
  - schema-based tests ensuring no undocumented fields are emitted,
  - strict base64url decoding and field length constraints in requests.

## 6. Release acceptance criteria (Phase 3)
A release candidate is acceptable only if:
1. All mandatory vector tests pass for all supported suites.
2. All Required checklist items (P3-03) are PASS with evidence.
3. Interop matrix passes for required pairs and scenarios (P3-04).
4. All fuzz targets run for the CI budget without new crashes; nightly fuzz has no unresolved findings.
5. No logging redline violations are detected (static and runtime).
6. Service contract tests pass, including OPK atomicity and RSF rotation semantics.
7. Configuration validation passes for the targeted deployment profile(s).
8. Security scanners produce no high-severity findings without explicit risk acceptance.

## 7. CI pipeline stages (recommended)
### 7.1 Pull request (fast path)
- Stage A: format/lint + secret scan + dependency lock check
- Stage B: unit tests + vector runner (subset or full, depending on runtime)
- Stage C: schema validation (OpenAPI + shared schema)
- Stage D: short fuzz (bounded time, seeded corpus)
- Stage E: interop smoke (single pair, limited cases) OR scheduled if too heavy

### 7.2 Main branch (full path)
- All PR stages
- Full interop matrix
- Extended fuzz (longer budget)
- Coverage report and performance regression checks

### 7.3 Nightly (deep path)
- Extended fuzz (hours if available)
- Soak tests for services (RSF/PDS/KTL) with rotation and concurrency
- Crash-safety fault injection loops
- Key rotation simulation (KTL and auth keys) in staging-like environment

## 8. Deterministic environments and reproducibility
### 8.1 Containerization
For interop and service contract tests:
- use docker-compose (or equivalent) to run RSF/PDS/KTL and at least one client harness container,
- pin base images by digest,
- record image digests and toolchain versions in build artifacts.

### 8.2 Reproducible vector runs
- Use deterministic seeds per P3-08 generation plan for any generated fixtures.
- Ensure test harness runs do not depend on wall-clock time:
  - inject a fake clock where timestamp_bucket behavior is tested,
  - fix randomness source using deterministic DRBG in tests.

## 9. Standardized outputs and reporting
The harness SHOULD emit:
- JUnit/XML for CI systems,
- JSON report for consumption by dashboards,
- a conformance report mapping to P3-03 item IDs, including evidence references.

Report fields (recommended):
- `build_id`, `git_commit`, `toolchain_versions`,
- `vector_set_version`,
- `profile` and `config_version` (P3-12),
- `interop_matrix` results,
- `fuzz` summary (executions, unique crashes, corpus size),
- `redline_checks` results.

## 10. Security hygiene for the harness itself
- Test fixtures containing secrets must live under a clearly test-only path and must be excluded from production build artifacts.
- CI logs must not print vector secrets; redact by default.
- Artifact uploads (failed-case dumps) must be access-controlled and short-retention.
- If the harness stores any derived keys for debugging, it must do so only in restricted CI contexts with explicit opt-in.

## Appendix A — Example “make” targets (illustrative)
These target names are suggestions; choose an equivalent approach.

- `make lint`
- `make unit`
- `make vectors` (runs VR)
- `make schema` (OpenAPI + JSON schema lint)
- `make interop-smoke`
- `make interop-full`
- `make fuzz-short`
- `make fuzz-nightly`
- `make conformance-report`

## Appendix B — Minimal fuzz corpus seeding checklist
Seed fuzz corpora with:
- all negative vector payloads (QSE/QSP/KT),
- boundary-length cases (0, 1, max-1, max, max+1),
- trailing bytes cases with 1..32 extra bytes,
- length smuggling patterns (declared shorter/longer),
- randomized but bounded valid messages to explore state-machine edges.

---
**End of document.**
