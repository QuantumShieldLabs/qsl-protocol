# QuantumShield Phase 3 — Client Error/Retry & Backoff Semantics
**Artifact ID:** P3-24  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (alignment only):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Related Phase 3 artifacts (alignment only):** P3-14 (Shared Schemas/Reason Codes), P3-16 (CI Harness), P3-18 (Packaging), P3-19 (Negative Tests), P3-20 (AuthN/AuthZ), P3-21 (KT Verification)  
**Version:** 1.0  
**Date:** 2025-12-19  
**Timezone:** America/Chicago  

## 0. Purpose and scope
This document defines **deterministic client behavior** for handling errors, retries, and backoff across Phase 3 components:

- **RSF** (Relay/Store-and-Forward) operations: enqueue, fetch, ack, rotate, register
- **PDS** (Prekey Directory Service) operations: bundle fetch, publish, revoke, OPK uploads, inventory
- **KTL** (Key Transparency Log) reads: STH and proof retrieval (where not bundled via PDS)
- **Local SDK** behaviors for QSP/QSE processing: fail-closed, state invariants, duplicate handling

It translates P3-14 reason codes and P3-20 authorization constraints into a single, predictable client policy that:
- prevents retry storms and correlated traffic,
- avoids state corruption by partial commits,
- avoids insecure downgrade on authentication/KT failures,
- minimizes metadata leakage through retries, and
- supports interop and testability (P3-16).

This is a **supporting** artifact and is fully self-contained.

## 1. Non-negotiable principles
1. **Fail closed:** Any cryptographic verification failure, canonical parsing failure, or bounds violation is not “recoverable by retry” without a change in input.
2. **No authorization by secrecy:** Knowledge of a route_token is not an auth factor; auth failures must not trigger “probing retries.”
3. **Bounded retries:** Retries are always bounded by attempt counts and total wall-clock budget.
4. **Jittered backoff:** All retries that could synchronize across clients MUST include randomized jitter.
5. **Idempotency on writes:** Any client write that may be retried MUST use an idempotency key (where the API supports it) and MUST treat “already accepted” as success.
6. **State safety:** For receive/decrypt paths, **state MUST NOT commit** unless the operation completes successfully (copy-then-commit).

## 2. Inputs and observable failures
Client logic consumes three primary sources of failure signals:

### 2.1 HTTP / transport failures (service calls)
- status code (e.g., 400/401/403/404/409/413/429/5xx)
- response reason code (P3-14 registry; string)
- transport error class (DNS failure, timeout, TLS error, connection reset)

### 2.2 Local parsing and verification failures
- QSE envelope parse/canonical failures
- QSP decrypt/verify failures (header AEAD/body AEAD)
- KT verification failures (STH signature/proof/consistency)

### 2.3 Local state and resource failures
- disk full, database locked, corrupted state blob
- memory cap reached (bounded caches)
- clock skew detected beyond tolerance (timestamp bucket policy)

## 3. Error taxonomy
Clients MUST classify failures into one of the following categories. This category determines retry and escalation behavior.

### 3.1 Category A: Permanent (do not retry without input change)
Examples:
- `invalid_request`, `noncanonical_qse`, `noncanonical_qsp`, `bounds_exceeded`
- `unsupported_version`, `unsupported_suite`
- `forbidden` (403) with valid token and correct audience
- `kt_invalid`, `kt_rollback_detected`, `invalid_signature`, `decrypt_failed` (local)
- `conflict` on invariant violation (e.g., route_token collision) where retry with same input will not succeed

Behavior:
- Do not automatically retry.
- Surface a structured error to caller.
- If user-visible, provide a generic message (no identifiers).
- Record sanitized telemetry (see §10).

### 3.2 Category B: Authentication recoverable (refresh then retry once)
Examples:
- `auth_failed` / 401 due to expired access token
- 403 caused by “insufficient scope” MAY be permanent; treat as permanent unless policy knows scope can change via re-auth

Behavior:
- Attempt token refresh once (if refresh is supported and available).
- Then retry the same request exactly once with a new access token.
- If still failing, treat as permanent and require user/administrator action.

### 3.3 Category C: Transient (retry with backoff)
Examples:
- `rate_limited` (429)
- `service_unavailable` (503)
- 5xx errors
- transport timeouts, connection failures
- `retry_later` (explicit reason code if used)

Behavior:
- Retry with bounded exponential backoff and jitter.
- Respect server-provided retry hints if present (e.g., Retry-After).

### 3.4 Category D: Ambiguous outcome (write may have succeeded)
Examples:
- network timeout or connection reset after request body sent on a **write** operation (enqueue/publish/upload/rotate/register)
- 502/504 from proxy after forwarding is uncertain

Behavior:
- If idempotency key is supported: retry safely using the same idempotency key.
- If idempotency is not supported: treat as “unknown committed,” and only retry if the application has an out-of-band confirm step (discouraged). Default is to retry at most once and then require manual recovery logic.

## 4. Retry policy: default parameters
These defaults are intended for mobile and desktop clients. Services or background daemons may use slightly different budgets, but MUST remain bounded.

### 4.1 Exponential backoff with jitter
For attempt `n` starting at 1:

- `base = 0.5s`
- `cap = 30s`
- `delay = min(cap, base * 2^(n-1))`
- apply jitter: `sleep = Uniform(0, delay)`

### 4.2 Attempt budgets
- **Transient read** (fetch bundles, fetch RSF messages): max attempts = 6, max total budget = 90s
- **Transient write** (enqueue, ack, publish, OPK upload): max attempts = 5, max total budget = 60s
- **KT reads** (STH/proofs): max attempts = 4, max total budget = 30s

### 4.3 Respect server hints
If a server provides:
- `Retry-After` (seconds) or a structured retry hint, the client SHOULD set:
  - `sleep = max(sleep, hint)` but MUST cap to `cap`.

### 4.4 Anti-storm rule
If the client receives `rate_limited` twice consecutively for the same endpoint and principal:
- increase `cap` temporarily to 120s for the remainder of the session, and
- reduce concurrent in-flight requests to 1 for that endpoint.

## 5. Operation-specific behavior
This section defines normative behavior per operation type.

### 5.1 RSF enqueue (write)
Purpose: upload canonical QSE envelope bytes for delivery.

Client MUST:
1. Validate QSE locally (canonical + bounds) before sending (fail closed).
2. Include an `idempotency_key` for the enqueue request (if API supports it).
3. On response:
   - success: store msg_handle if provided; proceed
   - `noncanonical_qse` / `bounds_exceeded`: permanent, do not retry
   - `auth_failed`: token refresh once then retry once
   - `rate_limited` / 5xx / transport: transient; retry with backoff, same idempotency key
   - ambiguous outcome (timeout): retry with same idempotency key; if still ambiguous, surface “unknown delivery status” to caller.

Client MUST NOT:
- modify the envelope bytes as a “repair” attempt
- retry indefinitely

### 5.2 RSF fetch (read, may be long-poll)
Client MUST:
- treat fetch as idempotent and safe to retry
- on `not_found`: if the client is authorized to know existence, treat as permanent; otherwise treat as permanent and do not probe repeatedly
- on `rate_limited`: transient with backoff; consider reducing wait_seconds or disabling long-poll temporarily

Long-poll guidance:
- If `wait_seconds` is used, the fetch budget should count wall-clock time spent waiting.
- If a fetch returns messages, the client SHOULD immediately process and ACK (or NACK) before issuing another fetch.

### 5.3 RSF ACK (write, idempotent)
ACK MUST be treated as idempotent by the client:
- if ACK returns partial success or “not found,” clients MAY treat “not found” as success for already-acked messages.
- retry on transient errors, using idempotency key if supported (optional).
- do not retry on `invalid_request` with same body.

### 5.4 RSF rotate/register (write, high-risk)
Rotate/register change server routing bindings and MUST be conservative:

Client MUST:
- include idempotency key
- on collision/conflict: permanent (requires new token)
- on transient/ambiguous: retry with same idempotency key
- never attempt to “guess” whether rotate succeeded by probing with unauthenticated fetch calls

If rotation is ambiguous after retries:
- the client SHOULD continue to accept messages on both old and new tokens (if it already has both) until it can confirm status via an authenticated status endpoint, or until overlap window elapses.

### 5.5 PDS get bundles (read)
Bundle fetch is read-like but may involve OPK consumption server-side, depending on PDS policy. Clients MUST treat it as:

- **Category D (ambiguous outcome)** if the request can cause OPK consumption and the network fails mid-flight.

Client behavior:
- include idempotency key if the API supports it for bundle fetch
- if OPK is required and unavailable (`opk_unavailable`): permanent, do not loop; schedule retry with a long delay (minutes) or upon explicit user action
- on `rate_limited`/5xx: transient with backoff
- on `auth_failed`: refresh then retry once

### 5.6 PDS publish/revoke and OPK uploads (write)
These MUST always include idempotency keys.

Client behavior:
- validate payload sizes and encoding locally (base64url strict) before sending
- on 409 conflict (e.g., duplicate opk_id): treat as permanent for that item; if batch, continue with remaining items if service supports per-item statuses
- on transient errors or ambiguous outcomes: retry with same idempotency key
- if device revoked: permanent; require re-enrollment

### 5.7 KTL reads (STH/proofs)
Clients in Authenticated mode MUST:
- treat KT verification failures as **permanent** for that bundle/response
- not “retry until it passes” with the same server endpoint, as that can amplify equivocation attacks

Recommended behavior on KT failure:
- retry once against a different replica or independent endpoint (if configured),
- otherwise stop and escalate to user/security telemetry (sanitized) and require manual recovery policy.

## 6. Local SDK error handling (QSP/QSE)
### 6.1 QSE decoding
- Any QSE non-canonical encoding or bounds violation MUST be permanent and must never be retried by “massaging bytes.”
- If envelope is obtained from RSF, the client MAY report a sanitized “server served noncanonical envelope” event, but MUST not ACK it as delivered unless application policy allows “drop and ack” for poison pills. Default is to NACK or let lease expire.

### 6.2 QSP receive/decrypt
Client MUST enforce:
- on header/body AEAD failure: **do not commit state**, treat as permanent for that ciphertext
- on replay/duplicate: treat as idempotent (no new plaintext), do not advance state
- on out-of-window skip: permanent (drop), do not advance state
- on resource cap exceeded (MKSKIPPED/HKSKIPPED): permanent for that message; do not relax caps at runtime

### 6.3 Crash-safety
Receive path MUST be copy-then-commit:
- parse → verify → decrypt → derive → commit (single atomic unit)
- failures at any stage must leave persistent state unchanged

If local state is corrupt/tampered:
- quarantine session and require re-handshake rather than attempting unsafe repair.

## 7. Clock skew and timestamp policy
Some deployments enforce `timestamp_bucket` constraints (QSE) and KT timestamp monotonicity.

Client behavior:
- If server rejects due to timestamp skew (`invalid_request` with a timestamp reason), treat as **permanent until clock is corrected**.
- Client SHOULD attempt a one-time clock sanity check (e.g., trusted time source provided by platform or authenticated server time endpoint if available).
- Client MUST NOT automatically weaken timestamp policy to “make it work.”

## 8. Concurrency limits and connection hygiene
To reduce metadata leakage and retry storms, clients SHOULD enforce:
- RSF: at most 1 concurrent fetch per inbox; enqueue may be concurrent but SHOULD be capped (e.g., 2–4).
- PDS: at most 2 concurrent requests per principal; bundle fetch serialized when OPKs are scarce.
- KTL: serialize proof fetches (1 at a time) and cache results per STH.

When rate-limited:
- reduce concurrency to 1 for the affected endpoint (anti-storm rule, §4.4).

## 9. Deterministic mapping: status/reason → category
If both are present, the **reason code** takes precedence over status code.

Recommended mapping table:

- `invalid_request`, `noncanonical_qse`, `bounds_exceeded`, `unsupported_*` → Category A
- `auth_failed` → Category B
- `forbidden` → Category A (unless policy says re-auth may grant scope)
- `rate_limited` → Category C
- `service_unavailable`, `retry_later` → Category C
- `conflict` → Category A (unless idempotency conflict indicates already accepted → treat as success)
- 5xx with no reason → Category C
- transport timeout on write → Category D

## 10. Telemetry and privacy (sanitized)
Clients MAY emit telemetry events for reliability and security, but MUST obey redlines:

MUST NOT emit:
- raw route_tokens
- raw QSE envelopes
- raw QSP ciphertexts or plaintext
- auth tokens or refresh tokens
- KT proofs or leaf_data in full

Allowed (recommended):
- coarse time bucket (hour)
- endpoint name (rsf_enqueue, pds_get_bundles, etc.)
- status code and reason code
- sizes in buckets (e.g., <1KB, <4KB, <16KB, <64KB, <256KB, >=256KB)
- salted hash of stable identifiers (if needed), computed locally with rotating salt:
  - `H32("telemetry" || salt || route_token)` (do not reuse salt across long periods)

On KT failures:
- log only reason category (invalid_signature, invalid_proof, rollback_detected), plus tree_size bucket, never raw hashes.

## 11. Reference pseudocode (normative behavior)
### 11.1 Generic retry wrapper
```
fn call_with_policy(op_kind, is_write, call_fn):
    attempts = 0
    start = now()
    while attempts < max_attempts(op_kind) and (now() - start) < budget(op_kind):
        attempts += 1
        res = call_fn()
        if res.ok:
            return res

        cat = classify(res)
        if cat == PERMANENT:
            return res

        if cat == AUTH_RECOVERABLE:
            if attempts_auth_refresh_used: return res
            if refresh_token(): attempts_auth_refresh_used = true; continue
            return res

        if cat == TRANSIENT:
            sleep(jittered_backoff(attempts))
            continue

        if cat == AMBIGUOUS_OUTCOME:
            if is_write and !res.idempotency_used:
                // bounded: retry at most once then surface ambiguity
                if attempts >= 2: return res
            sleep(jittered_backoff(attempts))
            continue

    return res // last failure
```

### 11.2 Idempotency key rule
- For any write op where API supports idempotency:
  - generate `idempotency_key = base64url(random 16..32 bytes)`
  - reuse the same key for all retries of the same logical operation

## 12. Conformance hooks (how to test P3-24)
A conformance harness (P3-16) SHOULD include:
- deterministic classification tests for each reason code
- backoff behavior tests (bounded attempts; jitter ranges)
- “auth refresh once” tests for 401
- ambiguous write tests verifying idempotency key reuse
- KT failure tests verifying client does not retry indefinitely and does not downgrade

---
**End of document.**
