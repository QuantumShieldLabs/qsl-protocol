# QuantumShield Phase 3 — Client Integration & SDK Architecture Guide
**Artifact ID:** P3-10  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (authority):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Version:** 1.0  
**Date:** 2025-12-20  
**Timezone:** America/Chicago

## 0. Purpose and scope
This document provides an implementable, platform-oriented integration guide for QuantumShield clients (iOS, Android, Desktop). It defines:
- a reference SDK/module decomposition,
- exact client-side service flows for **PDS (directory/prekeys)**, **KTL (key transparency)**, and **RSF (relay/store-and-forward)**,
- persistence and crash-safety boundaries,
- concurrency rules for session state,
- privacy/metadata minimization practices, and
- required fail-closed behaviors.

This is a **supporting** artifact and is written to be usable on its own (it does not require any other Phase 3 supporting artifact). Canonical cryptographic definitions and wire formats are defined by **QSP 4.3.2** and **QSE 1.8.2**.

---

## 1. Non-negotiable integration invariants (client-side)
Clients MUST implement the following invariants regardless of platform:

1. **Fail-closed crypto:** any AEAD/tag failure, signature failure, KEM/decap failure, RNG failure, or KT verification failure MUST cause the operation to fail and MUST NOT downgrade into weaker behavior.
2. **Canonical parsing:** QSP and QSE messages MUST be parsed canonically and rejected on:
   - truncation,
   - length overrun/underrun,
   - non-canonical varbytes,
   - trailing bytes.
3. **Transactional receive:** inbound message processing MUST be done on a copy of session state and committed atomically only on full success.
4. **Bounded work:** message header search, skipped-key caches, and any retry loops MUST be bounded exactly per canonical limits; no unbounded scans.
5. **Transport opacity:** RSF is transport only. Clients MUST treat RSF as untrusted and MUST tolerate duplication/reordering/delay.
6. **Metadata minimization:** do not embed stable identifiers in QSE route_token; minimize logs and telemetry; avoid precise counters/visible queue sizes.

---

## 2. Reference client module architecture
Implementations SHOULD structure code into the following modules. Names are illustrative; the boundaries are important.

### 2.1 Modules (recommended)
1. **qsp_core**
   - Implements QSP session, handshake, ratchet, encrypt/decrypt, and state machine.
   - Exposes a small API:
     - `CreateSessionInitiator(...)`
     - `CreateSessionResponder(...)`
     - `SendMessage(session, plaintext) -> qsp_bytes`
     - `ReceiveMessage(session, qsp_bytes) -> (plaintext, new_session_state)`
   - Provides canonical encode/decode helpers for QSP wire objects.

2. **qse_envelope**
   - Encodes/decodes QSE envelopes.
   - Enforces QSE bounds.
   - Supports padding policies and timestamp_bucket policy.

3. **kt_client**
   - Verifies Key Transparency artifacts required by the deployment (Authenticated mode).
   - Maintains pinned STH state per log_id with rollback resistance.
   - Provides:
     - `VerifyBundleKT(bundle_bytes, kt_material, pinned_state) -> (ok, new_pins)`

4. **pds_client**
   - Uploads device bundles and OPKs.
   - Fetches peer bundles to initiate sessions.
   - Returns canonical QSP PrekeyBundle bytes as opaque payload to qsp_core.

5. **rsf_client**
   - Enqueues and fetches QSE envelopes.
   - Handles ACK/NACK, long-poll, paging, and token rotation calls.
   - Does not parse QSP payloads beyond treating them as bytes inside QSE.

6. **secure_storage**
   - Atomic persistence layer for:
     - QSP session state,
     - bounded caches (MKSKIPPED/HKSKIPPED),
     - pinned KT state,
     - route_token and rotation state.
   - Must support “copy then commit” semantics and rollback resistance best-effort.

7. **app_bridge**
   - Application integration: notifications, UI delivery, message store.
   - MUST not influence cryptographic decisions or error handling.

### 2.2 Dependency rules (recommended)
- `qsp_core` must not depend on network or OS APIs.
- `qse_envelope` must not depend on RSF/PDS.
- `secure_storage` is used by all components but should not depend on them.
- Network clients (`pds_client`, `rsf_client`, `kt_client`) depend on HTTP stack only and consume/produce byte strings.

---

## 3. Platform key custody and storage
### 3.1 Required properties
Client key custody and storage MUST provide:
- confidentiality at rest for long-lived secrets,
- integrity for state (detect corruption),
- atomic commit for session state,
- best-effort rollback resistance for pinned KT state and ratchet state.

### 3.2 iOS (recommended)
- Store long-lived identity private keys in **Keychain**; where applicable use Secure Enclave-backed keys for signing keys.
- Store the encrypted session database key in Keychain; store session database (SQLite WAL or file-backed KV) with file protection.
- Store pinned KT state and state MAC keys in Keychain.

### 3.3 Android (recommended)
- Use **Android Keystore** to wrap an application encryption key.
- Store encrypted database (SQLCipher/Room + encryption, or encrypted file-backed KV).
- Store pinned KT state MAC key in Keystore-backed secret.

### 3.4 Desktop (recommended)
- Use OS credential vault/keyring to protect database encryption keys where possible.
- Use encrypted database for session state.
- Rely on full-disk encryption as baseline but still treat app DB as high sensitivity.

### 3.5 Secrets that MUST NOT be logged
Never log:
- private keys,
- root/chain/message/header keys,
- decrypted headers/bodies,
- raw QSP plaintext,
- raw QSE route_token,
- raw auth tokens.

---

## 4. Client-to-service flows (authoritative for integration)
This section defines exact client integration flows with PDS/KTL/RSF. Where deployment choices exist, the default is explicitly stated.

### 4.1 Onboarding: create device identity and publish bundle
**Goal:** publish device bundle and optional OPK pools.

Steps:
1. Generate identity material per QSP (device identity, signing keys, DH and PQ components as required by suite).
2. Create a device bundle representation (canonical QSP PrekeyBundle bytes or the canonical “bundle fields + signatures” representation used by your PDS).
3. Upload bundle to PDS:
   - MUST include both classical and PQ signatures when the suite requires them.
4. Upload OPK batches (recommended):
   - DH OPKs: batch of public keys with unique opk_id values.
   - PQ OPKs (Suite-1B): batch of PQ public keys with unique opk_id values.
5. Store local device identifiers and current route_token mapping.

Failure handling:
- If bundle signing fails or PDS rejects, do not proceed to messaging.
- If OPK upload fails, messaging may still function but may degrade handshake properties; surface to user/ops.

### 4.2 Fetch peer bundle and perform KT verification (Authenticated mode)
**Default (Phase 3):** use Authenticated mode where KT verification is enabled for bundle retrieval, unless explicitly operating in a non-KT profile.

Steps:
1. Fetch target user’s active device bundle(s) from PDS.
2. Verify bundle signatures (EC + PQ as applicable).
3. Verify KT:
   - Validate STH signature for the log_id.
   - Verify inclusion proof for the leaf binding.
   - Verify consistency with pinned STH (rollback resistance).
4. If all checks pass, update pinned KT state atomically.

Failure handling:
- Any failure MUST fail-closed. Do not initiate sessions with unverifiable bundles if Authenticated mode is required.

### 4.3 Establish QSP session (handshake)
From qsp_core perspective:
- Initiator uses the verified peer PrekeyBundle and local identity material to construct the handshake init.
- Responder processes handshake init and returns handshake response.
- Both sides derive RK0 and initialize the ratchet.

Transport options:
- Direct: send handshake messages peer-to-peer (optional, out of scope for Phase 3 minimum).
- RSF baseline: wrap handshake messages inside QSE envelopes and send via RSF (recommended).

### 4.4 Send message (message-plane via RSF)
Steps:
1. `qsp_bytes = qsp_core.SendMessage(session, plaintext)`
2. `qse_bytes = qse_envelope.Wrap(route_token, qsp_bytes, padding_policy, timestamp_bucket_policy)`
3. POST to RSF enqueue endpoint with qse_bytes.
4. On enqueue success, optionally record a local “pending send” marker for UI state (non-crypto).

Failure handling:
- If RSF enqueue fails, you MAY retry with idempotency key.
- Do not “re-encrypt” a different ciphertext unless the user re-sends; prefer retransmitting the same ciphertext envelope to avoid state divergence.

### 4.5 Receive messages (message-plane via RSF)
Steps:
1. Fetch batch from RSF using the current route_token:
   - long-poll permitted (wait_seconds up to deployment max).
2. For each returned `qse_envelope_b64`:
   - Canonically parse QSE, enforce bounds.
   - Apply timestamp_bucket policy (Phase 3 default accepts bucket=0).
   - Extract payload bytes as QSP message bytes.
3. For each payload:
   - Load session state for the peer/session mapping (your app must map message to the correct session context; see §6).
   - Run `ReceiveMessage` on a copy of state:
     - if success: atomically commit state and deliver plaintext to app.
     - if failure: do not commit state; record sanitized reason code.
4. After processing an item:
   - ACK to RSF if and only if:
     - QSE parsed successfully, and
     - payload was either successfully processed OR conclusively determined to be non-retriable for this client (e.g., malformed QSE, non-canonical QSP).
   - For transient failures (storage IO error, app out-of-memory), do not ACK; allow redelivery.

Rationale:
- ACK policy ensures RSF redelivery is used as a resilience mechanism while preserving fail-closed behavior.

### 4.6 route_token rotation (privacy requirement)
Clients SHOULD rotate route_token at least daily (deployment policy). Rotation is a privacy feature, not a cryptographic one.

Rotation steps:
1. Generate a new random route_token (opaque bytes).
2. Call RSF rotate API to bind new token to the same inbox with an overlap window (recommended 24 hours).
3. Publish the new route_token via the directory mechanism used by your application (commonly: update bundle metadata in PDS or separate application directory record).
4. Persist:
   - new token,
   - overlap expiry,
   - and a “current token effective” timestamp.

During overlap:
- fetch and ACK must work for both old and new tokens;
- senders may still use the old token until they learn the new one.

---

## 5. Configuration profile (Phase 3 defaults)
The SDK SHOULD expose a configuration object with safe defaults.

### 5.1 Recommended defaults
- `rsf_fetch_default_max_items = 20`
- `rsf_fetch_max_bytes = 262144` (256 KiB)
- `rsf_long_poll_wait_seconds_max = 60`
- `rsf_visibility_timeout_seconds = 0` (disabled by default)
- `route_token_rotation_period_hours = 24`
- `route_token_overlap_seconds = 86400`
- `qse_allow_zero_timestamp_bucket = true`
- `padding_policy = "min_1k_bucketed"` (pad to >=1024 bytes, optionally to {1024,2048,4096})

### 5.2 Bounds enforcement
Clients MUST enforce QSE bounds locally before sending to RSF and again when receiving. Never assume RSF validation is sufficient.

---

## 6. Session selection and “which session does this message belong to?”
Store-and-forward means you may receive messages from multiple peers and multiple sessions.

### 6.1 Required mapping
Clients MUST maintain a secure mapping from inbound message context to a QSP session instance. Acceptable approaches:
- **Session ID inside QSP header (canonical):** parse minimal header to identify session_id before full decrypt (only as allowed by QSP; do not guess).
- **Per-inbox segmentation:** separate route_tokens per “account/device” and then attempt bounded header searches across active sessions (bounded, may be expensive).
- **Application-level conversation binding:** include a conversation handle in application metadata inside the encrypted payload (preferred for UX; not visible to RSF).

Important:
- Any “try all sessions” approach MUST be bounded and must not introduce an oracle. If session selection is ambiguous, drop and require higher-level recovery.

### 6.2 Storage keying
Persist session state keyed by:
- `(peer_identity_fingerprint, session_id)` or equivalent stable peer reference.
Avoid using plaintext phone/email as storage keys.

---

## 7. Concurrency and crash safety (client)
### 7.1 Single-writer rule
For each session, enforce single-writer semantics:
- serialize send and receive commits,
- use an actor/queue model per session where possible.

### 7.2 Atomic commit rule
A successful `ReceiveMessage` MUST commit:
- updated ratchet state,
- bounded cache mutations,
- any delivered-id markers (if used),
in a single atomic unit.

### 7.3 Failure classification for ACK decisions
Classify failures into:

**Non-retriable (ACK and drop):**
- QSE parse non-canonical or bounds exceeded,
- QSP parse non-canonical/trailing bytes,
- cryptographic validation failure (AEAD/tag failure) where policy is to drop,
- KT verification failure for bundles (not relevant to message-plane ACK; relevant to session initiation).

**Retriable (do not ACK):**
- local storage failure (disk full, transient IO),
- app killed during processing before commit,
- temporary resource exhaustion.

Note: Some deployments choose to NOT ACK on AEAD failure to allow future state changes to make decrypt succeed. This is generally unsafe (it can create persistent DoS loops). Default recommendation is to ACK and drop for cryptographic failures.

---

## 8. Observability and telemetry (safe signals only)
### 8.1 Allowed signals
- envelope size buckets,
- RSF request outcome codes (200/4xx/5xx),
- counts of parse failures by reason code,
- counts of decrypt failures by reason code (no payload data),
- KT verification status counters (pass/fail) with log_id hashed.

### 8.2 Redlines
Never emit:
- raw ciphertexts,
- raw route_tokens,
- plaintext content,
- key material,
- precise per-peer interaction timestamps that enable graph reconstruction.

---

## 9. Minimal SDK APIs (recommended)
This section provides a minimal API surface that can be mapped to Swift/Kotlin/Rust/TS.

### 9.1 Key lifecycle
- `CreateOrLoadIdentity() -> IdentityHandle`
- `PublishBundle(identity, pds_client) -> void`
- `UploadOPKs(identity, pds_client, count_dh, count_pq) -> void`

### 9.2 Session lifecycle
- `InitiateSession(peer_handle) -> SessionHandle`
- `AcceptSession(handshake_init) -> (SessionHandle, handshake_resp_bytes)`
- `CompleteInitiation(handshake_resp) -> SessionHandle`

### 9.3 Messaging
- `EncryptForSend(session, plaintext) -> qsp_bytes`
- `WrapForTransport(route_token, qsp_bytes) -> qse_bytes`
- `UnwrapTransport(qse_bytes) -> qsp_bytes`
- `DecryptOnReceive(session, qsp_bytes) -> plaintext`

### 9.4 RSF integration
- `Enqueue(qse_bytes, idempotency_key?) -> msg_handle`
- `Fetch(route_token, max_items, max_bytes, wait_seconds) -> [(msg_handle, qse_bytes)]`
- `Ack(route_token, [msg_handle]) -> void`
- `RotateRouteToken(old, new, overlap_seconds) -> void`

---

## 10. Implementation checklists (per platform)
### 10.1 iOS checklist
- Use Keychain for secrets and DB key wrapping.
- Use SQLite WAL with atomic transactions for session state.
- Run network requests on background queues; serialize per-session crypto on a dedicated queue.
- Ensure background fetch/notifications do not run two receivers concurrently for the same session.

### 10.2 Android checklist
- Use Keystore-wrapped key + encrypted DB.
- Use WorkManager for background fetch; ensure single receiver worker per account/device.
- Use coroutines/actors to serialize session commits.

### 10.3 Desktop checklist
- Use file locking or process-wide mutex to enforce single writer.
- Ensure crash dumps are restricted; do not include memory with secrets.

---

## Appendix A — Reference pseudocode (illustrative)
### A.1 Send via RSF
```
qsp = QSP.SendMessage(session, plaintext)
qse = QSE.Wrap(route_token, qsp, pad_policy="min_1k_bucketed", timestamp_bucket=0)
rsf.Enqueue(qse, idempotency_key = H(qse || local_nonce))
PersistOptionalPendingMarker()
```

### A.2 Receive via RSF (commit-on-success)
```
items = rsf.Fetch(route_token, max_items=20, wait_seconds=60)

for (handle, qse) in items:
  env = QSE.ParseCanonical(qse)            // fail => ACK & drop
  if !Policy.AcceptTimestampBucket(env.timestamp_bucket):
      rsf.Ack(handle); continue

  qsp = env.payload
  sess = SessionLookup(qsp, env)          // bounded selection only
  if sess == None:
      rsf.Ack(handle); continue

  // speculative receive
  sess2 = sess.Clone()
  ok, pt = QSP.ReceiveMessage(sess2, qsp)
  if ok:
      Storage.AtomicCommit(sess_id, sess2)
      App.Deliver(pt)
      rsf.Ack(handle)
  else:
      // cryptographic failure is non-retriable by default
      rsf.Ack(handle)
```

---
**End of document.**
