# QuantumShield Phase 3 — Conformance Requirements Checklist
**Artifact ID:** P3-03  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs:** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Version:** 1.0  
**Date:** 2025-12-18  
**Timezone:** America/Chicago

## 0. Purpose
This checklist converts **normative requirements** in the canonical specifications into **testable, trackable conformance items** for:
- independent implementations,
- interop testing,
- CI gating, and
- external audit evidence.

**Important:** This document is **supporting** and **non-normative**. In case of any discrepancy, **QSP/QSE govern**.

## 1. Conformance checklist structure (normative for this checklist)
Each requirement entry MUST include:
- **Requirement ID**: stable identifier
- **Level**: MUST / MUST NOT / SHOULD / SHOULD NOT / MAY
- **Spec source**: QSP 4.3.2 or QSE 1.8.2
- **Spec section**: section number + heading
- **Requirement statement**: concise paraphrase of the normative requirement
- **Test type**: unit / property / interop / fuzz / soak / perf-DoS / crash-safety / security
- **Positive tests**: minimum one
- **Negative/abuse tests**: minimum one (where applicable)
- **Notes**: edge cases, parameters, deployment-profile dependencies

## 2. Coverage and maintenance
- This is a Phase 3 living artifact. As implementation proceeds, any newly-discovered normative requirements MUST be added here.
- Any ambiguity or conflict found during test design MUST be logged in **P3-02 Errata & Change Request Log**.

## 3. Global test conventions (recommended defaults)
- All byte strings in vectors are lowercase hex.
- All integers are big-endian unless explicitly stated otherwise.
- All cryptographic comparisons are constant-time where applicable.
- CI MUST include: deterministic unit tests, negative corpus, fuzz targets, and at least one interop run between two independent stacks (or refimpl + alt stack).

---

# 4. QSE 1.8.2 conformance requirements

## 4.1 Envelope wire format and parsing
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSE-1.8.2-REQ-0001 | MUST | QSE 1.8.2 | §1 | Encode Envelope exactly as `env_version||flags||route_token||timestamp_bucket||pad_len||payload_len||payload||pad` | unit | Encode known fields; decode and compare | Malformed ordering rejected |  |
| QSE-1.8.2-REQ-0002 | MUST | QSE 1.8.2 | §1 | `env_version` MUST be `0x0100` for QSE v1.x | unit | Accept 0x0100 | Reject other values |  |
| QSE-1.8.2-REQ-0003 | MUST | QSE 1.8.2 | §1 | In QSE 1.8.x, `flags` MUST be `0x0000` | unit | Accept 0x0000 | Reject any non-zero flags | Future flags require version bump |
| QSE-1.8.2-REQ-0004 | MUST | QSE 1.8.2 | §1 | `payload` MUST carry **exactly one complete QSP message**; no fragmentation/concatenation | interop | Single message round-trip | Multi-message envelope rejected | Requires message framing discipline |
| QSE-1.8.2-REQ-0005 | MUST | QSE 1.8.2 | §1, §2 | `payload_len` and `pad_len` are authoritative; no heuristic parsing permitted | unit/fuzz | Accept exact lengths | Heuristic recovery prohibited; reject over/under lengths | Parser differential hardening |
| QSE-1.8.2-REQ-0006 | MUST | QSE 1.8.2 | §2 | Reject unknown `env_version` | unit | 0x0100 accepted | 0x0101+ rejected |  |
| QSE-1.8.2-REQ-0007 | MUST | QSE 1.8.2 | §2 | Reject truncated fields | fuzz | Valid envelope parsed | Truncations at each field boundary rejected |  |
| QSE-1.8.2-REQ-0008 | MUST | QSE 1.8.2 | §2 | Reject any length that exceeds remaining bytes | fuzz | Proper bounds accepted | Overrun lengths rejected | Include route/payload/pad overruns |
| QSE-1.8.2-REQ-0009 | MUST | QSE 1.8.2 | §2 | Reject trailing bytes beyond the last padding byte | unit/fuzz | Exact-length accepted | Extra trailing bytes rejected | Prevent smuggling |
| QSE-1.8.2-REQ-0010 | SHOULD | QSE 1.8.2 | §3.1 | After envelope validation, receiver SHOULD parse payload as QSP | integration | Valid QSP payload parsed | Invalid QSP payload results in discard | “SHOULD” but strongly recommended |
| QSE-1.8.2-REQ-0011 | MUST | QSE 1.8.2 | §3.1 | If QSP parsing fails, payload MUST be discarded | unit/integration | Invalid payload discarded | Any heuristic recovery forbidden |  |
| QSE-1.8.2-REQ-0012 | MUST NOT | QSE 1.8.2 | §3.1 | Deployments MUST NOT attempt heuristic recovery or concatenation of multiple QSP messages | unit/integration | Single-message only | Multi-message concatenation rejected |  |

## 4.2 DoS bounds
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSE-1.8.2-REQ-0101 | MUST | QSE 1.8.2 | §3.1 | Enforce `MAX_ROUTE_TOKEN_LEN = 512` | unit/fuzz | 512 ok | 513 rejected |  |
| QSE-1.8.2-REQ-0102 | MUST | QSE 1.8.2 | §3.1 | Enforce `MAX_PAYLOAD_LEN = 1_048_576` | unit/fuzz | 1 MiB ok | 1 MiB + 1 rejected |  |
| QSE-1.8.2-REQ-0103 | MUST | QSE 1.8.2 | §3.1 | Enforce `MAX_PAD_LEN = 1_048_576` | unit/fuzz | 1 MiB ok | 1 MiB + 1 rejected |  |
| QSE-1.8.2-REQ-0104 | MUST | QSE 1.8.2 | §3.1 | Enforce `MAX_ENVELOPE_LEN = 2_097_152` | unit/fuzz | 2 MiB ok | 2 MiB + 1 rejected | Ensure counts include all fields |
| QSE-1.8.2-REQ-0105 | MUST | QSE 1.8.2 | §3.1 | Deployments MUST NOT exceed these limits without version bump | governance | Config within maxima | Config > maxima fails policy | Enforced by build-time checks |
| QSE-1.8.2-REQ-0106 | MUST | QSE 1.8.2 | §3.1 | Deployment MUST ensure max encoded QSP msg fits in `MAX_PAYLOAD_LEN` | integration | Largest QSP message fits | Oversized QSP message rejected before send | Cross-spec integration guardrail |
| QSE-1.8.2-REQ-0107 | SHALL | QSE 1.8.2 | §3.1 | Conformance checklist SHALL include parse rejection + bound enforcement + timestamp policy tests | governance | Checklist includes entries | Missing coverage flagged | “SHALL” treated as MUST for checklist completeness |

## 4.3 Timestamp bucket policy
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSE-1.8.2-REQ-0201 | MUST | QSE 1.8.2 | §4.3 | Receiver MUST apply `ALLOW_ZERO_TIMESTAMP_BUCKET` policy | unit | Policy true accepts 0 | Policy false rejects 0 |  |
| QSE-1.8.2-REQ-0202 | MUST | QSE 1.8.2 | §4.3 | For non-zero values, receiver MUST enforce acceptance window around local time | unit/soak | Accept within window | Reject outside window | Window is deployment-defined |
| QSE-1.8.2-REQ-0203 | MUST NOT | QSE 1.8.2 | §4.3 | MUST NOT treat `timestamp_bucket` as security-critical freshness proof | security | Used only for damping | Any “freshness auth” logic forbidden | Documented in threat model |
| QSE-1.8.2-REQ-0204 | MUST | QSE 1.8.2 | §4.4 | Deployment MUST define `BUCKET_WIDTH_SECONDS` and `BUCKET_SKEW_TOLERANCE` | governance | Parameters exist | Missing params fails startup |  |
| QSE-1.8.2-REQ-0205 | SHOULD | QSE 1.8.2 | §4.2 | In service-edge deployments, clients SHOULD set bucket=0 | integration | Edge fills bucket | Client-set bucket ignored per profile | Policy-dependent |
| QSE-1.8.2-REQ-0206 | MUST | QSE 1.8.2 | §4.2 | In direct deployments, senders MUST set bucket per policy | integration | Bucket computed | Zero/invalid bucket rejected if disallowed |  |

## 4.4 Padding rules
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSE-1.8.2-REQ-0301 | MUST | QSE 1.8.2 | §5.1 | Encoder MUST choose `pad_len` such that `len(Envelope) >= MIN_ENVELOPE_BYTES` | unit/property | Meets minimum | Below minimum rejected (or re-encoded) | MIN is deployment profile |
| QSE-1.8.2-REQ-0302 | MUST | QSE 1.8.2 | §5.1 | `len(Envelope)` counts all bytes including padding | unit | Count matches | Off-by-one rejected |  |
| QSE-1.8.2-REQ-0303 | SHOULD | QSE 1.8.2 | §5.2 | Padding bytes SHOULD be CSPRNG | security | RNG padding used | Deterministic padding only in test mode | Test mode gated |
| QSE-1.8.2-REQ-0304 | MAY | QSE 1.8.2 | §5.2 | Published test vectors MAY use all-zero padding | vectors | Zero padding in vectors | Non-vector builds disallow | Controlled by build flag |

---

# 5. QSP 4.3.2 conformance requirements

## 5.1 Primitive selection and fixed sizes (parser hardening)
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSP-4.3.2-REQ-0001 | MUST | QSP 4.3.2 | §1.2 | Reject inputs not matching expected fixed sizes | unit/fuzz | Accept exact sizes | Reject short/long keys, sigs, ct | Apply to all fixed-size fields |
| QSP-4.3.2-REQ-0002 | MUST | QSP 4.3.2 | §2.3 | Reject truncated fields | fuzz | Valid parse | Truncations rejected |  |
| QSP-4.3.2-REQ-0003 | MUST | QSP 4.3.2 | §2.3 | Reject lengths exceeding remaining bytes | fuzz | Valid varbytes | Overrun rejected |  |
| QSP-4.3.2-REQ-0004 | MUST | QSP 4.3.2 | §2.3 | Reject trailing bytes not described by format | unit/fuzz | Exact accepted | Trailing bytes rejected | Smuggling defense |
| QSP-4.3.2-REQ-0005 | MUST | QSP 4.3.2 | §2.3 | Reject duplicate fields (no TLV repetition in v4.3) | unit | Canonical accepted | Duplicate encodings rejected | Structural invariant |
| QSP-4.3.2-REQ-0006 | MUST | QSP 4.3.2 | §2.3 | Tag/signature comparisons MUST be constant time | security | Constant-time primitives used | Timing regression test | Tooling/perf harness |
| QSP-4.3.2-REQ-0007 | MUST | QSP 4.3.2 | §2.4 | Reject unknown `protocol_version` or `suite_id` | unit | Known accepted | Unknown rejected | Downgrade resistance |
| QSP-4.3.2-REQ-0008 | MUST | QSP 4.3.2 | §2.4 | Reject unknown `flags` bits | unit/fuzz | Known flags accepted | Unknown bits rejected | Per-message enforcement |

## 5.2 Prekey bundles and Key Transparency (KT)
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSP-4.3.2-REQ-0101 | MUST | QSP 4.3.2 | §4.3 | Initiator MUST validate both bundle signatures (EC+PQ) | unit | Valid signatures accepted | Any invalid signature rejected |  |
| QSP-4.3.2-REQ-0102 | MUST | QSP 4.3.2 | §4.3 | Initiator MUST validate KT inclusion/consistency in Authenticated mode | interop | Valid proofs accepted | Bad proof rejected | Policy-driven modes |
| QSP-4.3.2-REQ-0103 | MUST | QSP 4.3.2 | §4.3 | Initiator MUST validate bundle validity window | unit | Within window accepted | Expired/not-yet-valid rejected | Time source assumptions |
| QSP-4.3.2-REQ-0104 | MUST | QSP 4.3.2 | §4.3.1 | BundleTBS = H(label || fields up to OPK fields excluding sig+KT) | unit | Recomputed matches | Any field change breaks sig verify | Canonical order critical |
| QSP-4.3.2-REQ-0105 | MUST | QSP 4.3.2 | §4.4 | Authenticated sessions REQUIRE KT verification | integration | Authenticated handshake enforces KT | Attempt bypass fails | Mode gating |
| QSP-4.3.2-REQ-0106 | MUST | QSP 4.3.2 | §4.4.4 | Client MUST verify both bundle sigs, validity, STH sigs, inclusion proof, consistency proof | integration | All steps pass | Any step failure blocks auth session | Explicit step coverage |
| QSP-4.3.2-REQ-0107 | MUST | QSP 4.3.2 | §4.4.4 | If any KT step fails, bundle MUST NOT be used for authenticated session | integration | Failure blocks | “Fail open” forbidden |  |
| QSP-4.3.2-REQ-0108 | MUST | QSP 4.3.2 | §4.4.5 | `kt_sth` MUST contain exactly one serialized STH | unit/fuzz | One STH accepted | Multiple/partial/trailing rejected | Canonical encoding |
| QSP-4.3.2-REQ-0109 | MUST | QSP 4.3.2 | §4.4.5 | Inclusion proof encoding MUST be `u16 count || count*hash32 || u64 leaf_index` | unit | Correct accepted | Trailing bytes, wrong length rejected |  |
| QSP-4.3.2-REQ-0110 | MUST | QSP 4.3.2 | §4.4.5 | Consistency proof encoding MUST be `u16 count || count*hash32` | unit | Correct accepted | Trailing bytes, wrong length rejected |  |
| QSP-4.3.2-REQ-0111 | MUST | QSP 4.3.2 | §4.4.5 | All integers inside KT objects MUST be big-endian | unit | BE accepted | LE rejected | Cross-impl hardening |
| QSP-4.3.2-REQ-0112 | MUST | QSP 4.3.2 | §4.4.5 | `count` MUST be <= 64 | unit/fuzz | 64 ok | 65 rejected | DoS bound |
| QSP-4.3.2-REQ-0113 | MUST | QSP 4.3.2 | §4.4.5 | Verifier MUST reject KT varbytes with trailing bytes beyond canonical encoding | fuzz | Exact accepted | Trailing rejected | Smuggling defense |
| QSP-4.3.2-REQ-0114 | MUST | QSP 4.3.2 | §4.4.6 | Client MUST pin last STH per log and reject rollback on tree_size | integration | Monotonic size accepted | Smaller size rejected | Persistence needed |
| QSP-4.3.2-REQ-0115 | MUST | QSP 4.3.2 | §4.4.6 | Client MUST reject excessive timestamp rollback beyond tolerance | integration | Within tolerance accepted | Excess rollback rejected | Define tolerance |
| QSP-4.3.2-REQ-0116 | MUST | QSP 4.3.2 | §4.4.6 | Client MUST reject root_hash not justified by valid consistency proof (unless first contact) | integration | Valid proof accepted | Invalid proof rejected |  |

## 5.3 One-time prekeys (OPK) service semantics
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSP-4.3.2-REQ-0201 | MUST | QSP 4.3.2 | §4.5 | Service MUST hand out each OPK at most once per device | integration | OPK served once | Second serve rejected | Requires atomic consume |
| QSP-4.3.2-REQ-0202 | MUST | QSP 4.3.2 | §4.5 | Service MUST delete/mark OPK as consumed atomically | integration/crash-safety | Crash during consume does not re-serve | Race conditions prevented | Transactional store |
| QSP-4.3.2-REQ-0203 | MUST | QSP 4.3.2 | §4.5 | Service MUST reject replay of consumed OPKs | integration | Replay rejected | Parallel fetch attempts converge | Audit logging recommended |

## 5.4 Handshake correctness and acceptance
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSP-4.3.2-REQ-0301 | MUST | QSP 4.3.2 | §5.1.1 | Initiator MUST choose 16-byte uniform-random `session_id` and MUST NOT reuse | unit/security | Random uniqueness property | Forced reuse rejected by policy | Track per device |
| QSP-4.3.2-REQ-0302 | MUST | QSP 4.3.2 | §5.2, §5.3 | HandshakeInit/Resp fields are serialized in canonical order | unit | Encode/decode stable | Reordered encodings rejected | Canonical parsing |
| QSP-4.3.2-REQ-0303 | MUST | QSP 4.3.2 | §5.2.1 | HS1 = H(label || HandshakeInit with sig fields zeroed) | unit | HS1 matches vector | Any change breaks sig verify | Deterministic transcript |
| QSP-4.3.2-REQ-0304 | MUST | QSP 4.3.2 | §5.3.1 | HS2 = H(label || HandshakeInit || HandshakeResp_TBS) | unit | HS2 matches vector | Conf/sig mismatch rejected |  |
| QSP-4.3.2-REQ-0305 | MUST | QSP 4.3.2 | §5.3.1 | A MUST verify B signatures over HS2 AND `conf_B` before accepting | integration | Valid accepted | Any failure rejects session | Acceptance rule |
| QSP-4.3.2-REQ-0306 | MUST | QSP 4.3.2 | §5.4–§5.5 | RK0 derivation MUST include all required secrets (ss1, optional ss2, dh1, optional dh2) in order | unit | RK0 matches vector | Omitted term produces mismatch | Hybrid security |
| QSP-4.3.2-REQ-0307 | MUST | QSP 4.3.2 | §5.5 | Responder MUST verify A identity keys via KT (KT is REQUIRED) | integration | KT verified | KT bypass rejected | Mode definition |
| QSP-4.3.2-REQ-0308 | MUST | QSP 4.3.2 | §5.5 | Responder MUST verify A signatures over HS1 | unit/integration | Valid accepted | Invalid rejected |  |
| QSP-4.3.2-REQ-0309 | MUST | QSP 4.3.2 | §5.6 | Both sides MUST bind `ct3` via `RK_init = KDF_RK_PQ(RK0, ss3)` | unit | RK_init matches | Wrong ct3 fails conf_B |  |
| QSP-4.3.2-REQ-0310 | MUST | QSP 4.3.2 | §5.6 | Both sides MUST compute `dh_init` and apply `KDF_RK_DH` to derive CK0 | unit | CK0 matches | Wrong dh_init fails |  |
| QSP-4.3.2-REQ-0311 | MUST | QSP 4.3.2 | §5.6 | Role assignment: A sets CK_s=CK0, B sets CK_r=CK0 (others None) | unit | Role init matches | Swapped role fails vectors | Interop critical |
| QSP-4.3.2-REQ-0312 | MUST | QSP 4.3.2 | §5.6 | Initialize counters Ns=0, Nr=0, PN=0 and caches empty | unit | Clean init | Non-zero init rejected by harness |  |
| QSP-4.3.2-REQ-0313 | MUST | QSP 4.3.2 | §5.6 | Initialize PQ peer receive key info from handshake peer advertisement | integration | Peer PQ fields set | Missing fields handled per suite | Needed for PQ boundary |
| QSP-4.3.2-REQ-0314 | MUST | QSP 4.3.2 | §10.5 | Responder MUST reject unsupported `suite_id` and MUST NOT respond with different suite_id | interop | Supported accepted | Mismatch rejected | Anti-downgrade |
| QSP-4.3.2-REQ-0315 | MUST | QSP 4.3.2 | §10.5 | Initiator MUST reject HandshakeResp if suite_id differs from HandshakeInit | interop | Match accepted | Mismatch rejected |  |

## 5.5 Associated data (AD), nonces, and flags
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSP-4.3.2-REQ-0401 | MUST | QSP 4.3.2 | §6.1 | Suite-1 AD_hdr and AD_body constructed exactly as specified | unit | AD matches vector | AD mismatch fails AEAD |  |
| QSP-4.3.2-REQ-0402 | MUST | QSP 4.3.2 | §6.1 | Suite-1B MUST compute `pq_bind` from on-wire flags + PQ prefix fields | unit/property | pq_bind matches | Any PQ prefix tamper causes AEAD fail | Control-plane binding |
| QSP-4.3.2-REQ-0403 | MUST | QSP 4.3.2 | §6.1 | Suite-1B MUST include pq_bind in both AD_hdr and AD_body | unit | AD includes pq_bind | Missing pq_bind breaks interop |  |
| QSP-4.3.2-REQ-0404 | MUST | QSP 4.3.2 | §6.1 | PQ prefix modifications MUST cause verification failure; MUST NOT commit ratchet state | security | Tamper rejected | State not advanced | Commit discipline |
| QSP-4.3.2-REQ-0405 | MUST NOT | QSP 4.3.2 | §6.1 | Envelope metadata MUST NOT be included in QSP AEAD AD | unit/integration | AD excludes envelope | Inclusion changes must fail tests | Cross-layer separation |
| QSP-4.3.2-REQ-0406 | MUST | QSP 4.3.2 | §6.2 | Sender MUST compute `nonce_hdr` deterministically from (session_id, DH_pub, N) | unit | Matches vector | Wrong nonce rejected |  |
| QSP-4.3.2-REQ-0407 | MUST | QSP 4.3.2 | §6.2 | Receiver MUST recompute expected nonce_hdr after decrypt and reject mismatch | unit/security | Match accepted | Mismatch rejected | Anti-malleability |
| QSP-4.3.2-REQ-0408 | MUST | QSP 4.3.2 | §6.2 | `nonce_body` computed deterministically from (session_id, DH_pub, N) | unit | Matches vector | Wrong nonce fails AEAD |  |
| QSP-4.3.2-REQ-0409 | MUST | QSP 4.3.2 | §6.3 | If FLAG_PQ_ADV set, FLAG_BOUNDARY MUST also be set | unit/fuzz | Valid combos accepted | Invalid combo rejected | Flag invariant |
| QSP-4.3.2-REQ-0410 | MUST | QSP 4.3.2 | §6.3 | If FLAG_PQ_CTXT set, FLAG_BOUNDARY MUST also be set | unit/fuzz | Valid combos accepted | Invalid combo rejected | Flag invariant |
| QSP-4.3.2-REQ-0411 | MUST | QSP 4.3.2 | §6.3 | Boundary messages MUST be header-encrypted under boundary header key and accepted only if hdr_source==CURRENT_NHK | interop/security | Boundary accepted | Wrong hdr_source rejected | Anti-spoof |
| QSP-4.3.2-REQ-0412 | MUST | QSP 4.3.2 | §6.3 | Messages without FLAG_BOUNDARY MUST NOT include PQ prefix fields | unit | Non-boundary without PQ ok | Non-boundary with PQ rejected | Structural |
| QSP-4.3.2-REQ-0413 | MUST | QSP 4.3.2 | §6.3 | Unknown flags MUST be rejected | fuzz | Known accepted | Unknown bits rejected | Parser hardening |
| QSP-4.3.2-REQ-0414 | MUST | QSP 4.3.2 | §6.3 | AD_hdr flags value MUST equal final on-wire flags (including PQ flags) | unit | AD matches final flags | Wrong AD causes AEAD fail | “Late flag flip” defense |

## 5.6 ProtocolMessage wire format and length invariants
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSP-4.3.2-REQ-0501 | MUST | QSP 4.3.2 | §7.1 | Prefix fields are encoded in canonical order, including optional PQ fields | unit | Encode/decode stable | Reordered fields rejected | Canonical parsing |
| QSP-4.3.2-REQ-0502 | MUST | QSP 4.3.2 | §7.1 | `hdr_ct_len` MUST equal 24; encoders set 24; decoders reject others | unit/fuzz | 24 accepted | Any other value rejected | Interop critical |
| QSP-4.3.2-REQ-0503 | MUST | QSP 4.3.2 | §7.1 | `body_ct_len` MUST be >=16 and <= MAX_BODY_CT_LEN | unit/fuzz | 16 accepted | <16 or >max rejected | MAX_BODY_CT_LEN profile |
| QSP-4.3.2-REQ-0504 | MUST | QSP 4.3.2 | §7.2 | HeaderPlain = PN(u32) || N(u32) | unit | Parse correct | Wrong size/parse rejected |  |
| QSP-4.3.2-REQ-0505 | MUST | QSP 4.3.2 | §7.1 | QSP message must fit within QSE MAX_PAYLOAD_LEN when transported in QSE envelopes | integration | Typical message fits | Oversize prevented/rejected | Cross-spec constraint |

## 5.7 State commit, bounds, and counter rules
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSP-4.3.2-REQ-0601 | MUST | QSP 4.3.2 | §8.2 | No durable state committed unless both header and body decrypt succeed and validations pass | crash-safety | Crash after header decrypt does not advance | Forced partial commit forbidden | Transactional semantics |
| QSP-4.3.2-REQ-0602 | MUST | QSP 4.3.2 | §8.3 | Enforce MAX_SKIP=1000, MAX_MKSKIPPED=2000, MAX_HEADER_ATTEMPTS=100, MAX_HKSKIPPED=4 with TTL 7d | perf-DoS/soak | Within bounds ok | Exceed bounds evicted/rejected | Deterministic eviction rules |
| QSP-4.3.2-REQ-0603 | MUST | QSP 4.3.2 | §8.3.1 | Treat u32 counters as monotonic without wraparound; terminate before wrap | unit/security | Near-max triggers terminate | Wrap attempt rejected | Prevent nonce reuse |
| QSP-4.3.2-REQ-0604 | MUST | QSP 4.3.2 | §8.3.1 | Arithmetic comparisons on counters MUST use wider type (u64) and avoid under/overflow | unit/property | Correct compare | Underflow case rejected | Implementation safety |
| QSP-4.3.2-REQ-0605 | MUST | QSP 4.3.2 | §10.1 | Reject messages whose protocol_version or suite_id differs from session parameters | unit/interop | Match accepted | Mismatch rejected | Anti-downgrade |
| QSP-4.3.2-REQ-0606 | MUST | QSP 4.3.2 | §10.1 | Treat (protocol_version,suite_id,session_id) as immutable per session | unit | Enforced | Any mutation rejected |  |

## 5.8 Boundary messages and epoch transitions
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSP-4.3.2-REQ-0701 | MUST | QSP 4.3.2 | §8.4 | PQ fields MUST only appear on boundary messages | unit/fuzz | Boundary with PQ ok | Non-boundary with PQ rejected |  |
| QSP-4.3.2-REQ-0702 | MUST | QSP 4.3.2 | §8.4 | Sender MUST set FLAG_BOUNDARY on first outbound message after DHRatchetSend | unit | Send ratchet triggers boundary | Missing boundary flagged | Protocol invariant |
| QSP-4.3.2-REQ-0703 | MUST | QSP 4.3.2 | §8.4 | Boundary header MUST be encrypted under pre-ratchet NHK_s (boundary_HK) | interop | Boundary decrypt via CURRENT_NHK | Wrong key rejected | Anti-spoof |
| QSP-4.3.2-REQ-0704 | MUST | QSP 4.3.2 | §8.4 | If PQ_peer_pub known, sender MUST include FLAG_PQ_CTXT on boundary and apply KDF_RK_PQ | interop | PQ boundary advances RK | Missing PQ_CTXT flagged | Suite intent |
| QSP-4.3.2-REQ-0705 | MUST | QSP 4.3.2 | §8.4 | Sender MUST include FLAG_PQ_ADV on every boundary and advertise fresh PQ_RCV key with unique id | integration | PQ_ADV updates peer state | Reused id rejected by harness | Cache bound |
| QSP-4.3.2-REQ-0706 | MUST | QSP 4.3.2 | §8.4 | Receiver: if FLAG_BOUNDARY and msg.DH_pub != st.DH_peer, MUST require hdr_source==CURRENT_NHK | security/interop | Valid epoch accepted | Spoofed epoch rejected |  |
| QSP-4.3.2-REQ-0707 | MUST | QSP 4.3.2 | §8.4 | Receiver MUST reject msg.DH_pub != st.DH_peer without boundary (except delayed old-epoch proven by HKSKIPPED) | interop | Delayed old accepted | Unflagged new epoch rejected | Parser/state safety |
| QSP-4.3.2-REQ-0708 | MUST | QSP 4.3.2 | §8.4 | PQ fields processed only after passing boundary acceptance rules | security | Accepted boundary processes PQ | Spoofed boundary does not process | Commit discipline |

## 5.9 Ratchet algorithms and message processing
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSP-4.3.2-REQ-0801 | MUST | QSP 4.3.2 | §9.1 | DHRatchetSend MUST capture pre-ratchet NHK_s as boundary_HK and set boundary_pending | unit | boundary_HK correct | Missing capture breaks boundary decrypt | Critical invariant |
| QSP-4.3.2-REQ-0802 | MUST | QSP 4.3.2 | §9.2 | DHRatchetReceive MUST store old HK/NHK into HKSKIPPED with TTL/cap | unit/soak | Old epoch decrypt possible | Exceed cap evicts oldest |  |
| QSP-4.3.2-REQ-0803 | MUST | QSP 4.3.2 | §9.3 | Final prefix (flags + PQ fields) MUST be determined before AD + encryption | unit | Deterministic output | Late mutation causes failure | Parser differential defense |
| QSP-4.3.2-REQ-0804 | MUST | QSP 4.3.2 | §9.3 | Boundary header key selection: boundary uses boundary_HK, non-boundary uses HK_s | unit | Correct key used | Wrong key rejected by receiver |  |
| QSP-4.3.2-REQ-0805 | MUST | QSP 4.3.2 | §9.3 | If FLAG_PQ_CTXT set, derive MK_eff = KMAC(MK, label, pq_ss) and update RK via KDF_RK_PQ | unit/interop | MK_eff matches | Wrong ordering breaks interop | Hybrid mixing |
| QSP-4.3.2-REQ-0806 | MUST | QSP 4.3.2 | §9.3 | Persisted state MUST be crash-consistent; MUST NOT send boundary while persisting pre-boundary state | crash-safety | Crash tests preserve invariants | Rollback/dup boundary prevented | Durability critical |
| QSP-4.3.2-REQ-0807 | MUST | QSP 4.3.2 | §9.4 | Header decrypt attempts must be bounded by MAX_HEADER_ATTEMPTS and record hdr_source | perf-DoS | Bounded attempts | Attempt amplification prevented |  |
| QSP-4.3.2-REQ-0808 | MUST | QSP 4.3.2 | §9.4 | MUST NOT DH-ratchet solely because msg.DH_pub != st.DH_peer | security | Correct classification | Premature ratchet forbidden | Prevent desync |
| QSP-4.3.2-REQ-0809 | MUST | QSP 4.3.2 | §9.5 | Work on copy tmp; commit only on full success | crash-safety | Commit on success | No partial updates |  |
| QSP-4.3.2-REQ-0810 | MUST | QSP 4.3.2 | §9.5 | Old-epoch delayed messages must not trigger DH-ratchet; boundary flag on old epoch is violation | interop | Old epoch decrypt ok | Boundary-on-old rejected |  |
| QSP-4.3.2-REQ-0811 | MUST | QSP 4.3.2 | §9.5 | New epoch acceptance requires FLAG_BOUNDARY and hdr_source==CURRENT_NHK | security/interop | New epoch accepted | Spoof rejected |  |
| QSP-4.3.2-REQ-0812 | MUST | QSP 4.3.2 | §9.5 | If FLAG_BOUNDARY set but msg.DH_pub == tmp.DH_peer, require hdr_source==CURRENT_NHK | interop | Correct accepted | Wrong source rejected | Prevent boundary misuse |
| QSP-4.3.2-REQ-0813 | MUST | QSP 4.3.2 | §9.5 | PQ decapsulation key must be retained by pq_target_id; after committed decap, delete key and reject reuse | security | One-time decap enforced | Reuse rejected | Key hygiene + anti-replay |
| QSP-4.3.2-REQ-0814 | MUST | QSP 4.3.2 | §9.5 | If body AEAD fails, MUST drop with no commit | security | Valid accepted | Invalid tag causes no state change | Core invariant |
| QSP-4.3.2-REQ-0815 | MUST | QSP 4.3.2 | §9.7 | Enforce MKSKIPPED TTL/cap and never scan more than MAX_MKSKIPPED_SCAN=50 per message | perf-DoS | Scan bounded | Unbounded scan prevented | Deterministic scan order |
| QSP-4.3.2-REQ-0816 | MUST | QSP 4.3.2 | §10.6 | Persisted state MUST not roll back RK/counters; rollback detection discards session | crash-safety/security | Power-loss tests | Forced rollback triggers discard | Platform-specific anti-rollback |

## 5.10 RNG, side-channels, and hybrid composition
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSP-4.3.2-REQ-0901 | MUST | QSP 4.3.2 | §10.2 | Ephemeral keygen and PQ ops MUST use CSPRNG; fail closed on RNG failure | security | RNG ok | Simulated RNG failure halts | Fault injection |
| QSP-4.3.2-REQ-0902 | MUST | QSP 4.3.2 | §10.3 | Secret key material MUST be wiped when discarded | security | Wipe on evict | Leak checks / sanitizer | Platform-dependent |
| QSP-4.3.2-REQ-0903 | MUST | QSP 4.3.2 | §10.4 | MUST NOT omit classical terms when PQ present, and MUST NOT omit PQ terms when present | unit/security | Full hybrid used | Omission breaks vectors | Hybrid correctness |
| QSP-4.3.2-REQ-0904 | MUST | QSP 4.3.2 | §10.4 | Any decapsulation failure MUST cause handshake rejection | unit | Valid decap ok | Malformed ct fails handshake | Fail closed |

## 5.11 Test vector and harness obligations (project-level requirements inside QSP)
| Requirement ID | Level | Spec source | Spec section | Requirement statement | Test type | Positive tests | Negative/abuse tests | Notes |
|---|---|---|---|---|---|---|---|---|
| QSP-4.3.2-REQ-1001 | MUST | QSP 4.3.2 | §11.1 | Project MUST publish test vectors for listed areas (KT, bundle, handshake, messaging, OOO, HK rotation, PQ mixing) | governance/vectors | Vectors exist | Missing set fails release gate | Treated as release criteria |
| QSP-4.3.2-REQ-1002 | SHALL | QSP 4.3.2 | §11.3 | Conformance checklist SHALL map every MUST/MUST NOT to tests | governance | Checklist complete | Missing mappings flagged | This artifact fulfills structure |
| QSP-4.3.2-REQ-1003 | MUST | QSP 4.3.2 | §11.4 | Vectors MUST be machine-readable; byte strings lowercase hex; labels included verbatim | vectors | Parse vectors | Reject malformed vectors | Generator must be tested |
| QSP-4.3.2-REQ-1004 | MUST | QSP 4.3.2 | §11.4.1 | Vectors MUST include required fields and intermediate values as specified | vectors | Reproducible | Missing fields flagged | Some “public-only” allowed |
| QSP-4.3.2-REQ-1005 | MUST | QSP 4.3.2 | §11.4.3 | Vectors MUST be stable once published; changes require new version + changelog | governance | Versioned vectors | Unversioned changes blocked | Release discipline |

---

## 6. Open items to be expanded in v1.1+ (expected Phase 3 growth)
The following areas often generate additional concrete requirements during implementation and should be expanded into explicit checklist entries as tests are authored:
- Detailed AEAD failure taxonomy (uniform error handling vs distinguishability).
- Exact eviction order for MKSKIPPED/HKSKIPPED under cap pressure.
- Exact persistence transaction boundaries (per platform).
- KMS/HSM-backed key material handling and secure deletion primitives.
- Interop boundaries across transports (WebSocket, push relay, store-and-forward).

---
**End of document.**
