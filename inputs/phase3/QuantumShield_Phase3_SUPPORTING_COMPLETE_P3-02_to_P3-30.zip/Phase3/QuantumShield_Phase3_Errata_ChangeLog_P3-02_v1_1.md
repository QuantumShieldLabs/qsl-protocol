# QuantumShield Phase 3 — Errata & Change Request Log
**Artifact ID:** P3-02  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs:** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Version:** 1.1  
**Date:** 2025-12-18  
**Timezone:** America/Chicago

## 0. Purpose
This log is the single Phase 3 registry for any issue discovered that would normally require:
- clarification of canonical language,
- correction of ambiguity/inconsistency,
- or a proposed wire/behavior change.

**Canonical documents are not edited during Phase 3.** Any findings are recorded here and remain **non-normative** until an explicit change window (e.g., Phase 4) is opened.

## 1. Definitions
**Errata candidate (E):** Ambiguity, inconsistency, missing requirement, or unclear security property in canonical text that can be resolved without changing wire format or protocol behavior (in principle).

**Change request (CR):** Any proposal that changes wire format, protocol behavior, cryptographic construction, state machine, or interoperability expectations.

**Implementation note (IN):** Clarification, best practice, or deployment guidance that does not require changing canonical text and is not intended to modify required behavior.

## 2. Severity rubric
- **S0 — Informational:** no security/interop impact; editorial or naming clarity only.
- **S1 — Low:** minor ambiguity; low interop risk; easy to resolve with a note.
- **S2 — Medium:** credible interop divergence or operational failure if misunderstood.
- **S3 — High:** security degradation plausible; subtle misuse likely; attack surface increased.
- **S4 — Critical:** exploitable vulnerability or strong likelihood of catastrophic failure.

## 3. Workflow
1. Record the issue as a new row.
2. Assign type (E/CR/IN) and severity (S0–S4).
3. Provide a minimal reproducible description (what a correct implementer might do, and how it diverges).
4. If applicable, map the issue to:
   - a **conformance requirement** (P3-03),
   - an **interop test** (P3-04),
   - a **negative/adversarial test** (P3-11),
   - and a **fix strategy** (supporting artifact or Phase 4 proposal).
5. Do not “resolve” by editing canonical docs during Phase 3. Resolution is either:
   - “Covered by supporting artifact” (IN), or
   - “Errata candidate prepared for Phase 4”, or
   - “Change request prepared for Phase 4”.

## 4. Log fields (schema)
Each entry MUST include:
- **Log ID:** stable identifier (e.g., E-0001, CR-0007, IN-0012)
- **Date discovered**
- **Source:** QSP 4.3.2 or QSE 1.8.2
- **Section/anchor:** canonical location (section number + heading)
- **Type:** E / CR / IN
- **Severity:** S0–S4
- **Title:** short description
- **Description:** exact problem statement (what is ambiguous/incorrect)
- **Impact:** security/interop/operational implications
- **Reproduction / divergence scenario:** how two reasonable implementations could differ
- **Proposed disposition:** Phase 3 note vs Phase 4 errata vs Phase 4 change request
- **Test mapping:** where we will encode the guardrail (P3-03/04/11)
- **Owner:** who is driving the analysis
- **Status:** Open / Under review / Drafted / Deferred / Resolved (Phase 4)

## 5. Entries
**Supersedes:** P3-02 v1.0 (added initial tracked issue)

> Keep entries concise but complete. Add an appendix if a single item needs more depth.

| Log ID | Date | Source | Section/Anchor | Type | Severity | Title | Description | Impact | Divergence / Repro | Proposed Disposition | Test Mapping | Owner | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E-0001 | 2025-12-18 | QSE 1.8.2 | §1 Wire format | E | S2 | Wire-format definition line truncated/ellipsized | The canonical inline wire-format line uses ellipses (e.g., `route_token(varby...6)`), which can obscure the exact field list and types when copy/pasted or used as a single source of truth. The surrounding bullet list implies the intended fields/order, but the definition line itself is not self-contained. | Interop risk: independent implementers may disagree on exact ordering/types if they rely on the definition line alone; parser/writer mismatch possible. | Implementer A uses bullet list order; implementer B uses the (ellipsized) definition line as authoritative and omits/misorders a field. | Phase 4 errata: replace wire-format line with explicit full definition; Phase 3 mitigation: supporting artifacts (P3-04/P3-03) state explicit field order and enforce tests. | P3-03 (QSE extracted reqs) + P3-04 IT-QSE-001/002/005 | Spec editor | Open |
| CR-0001 |  |  |  | CR | S0 |  |  |  |  |  |  |  | Open |
| IN-0001 |  |  |  | IN | S0 |  |  |  |  |  |  |  | Open |

## 6. Appendix A — Resolution notes (optional)
Use this section for longer-form analysis that should not clutter the table, including:
- threat-model linkage,
- formal reasoning sketches,
- compatibility impact assessment,
- and recommended migration strategy for Phase 4 changes.

---
**End of document.**
