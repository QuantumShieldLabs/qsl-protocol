# QuantumShield Phase 3 — Integration Architecture Guide
**Artifact ID:** P3-05  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs:** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Version:** 1.0  
**Date:** 2025-12-18  
**Timezone:** America/Chicago

## 0. Scope and goals
This document defines a **reference integration architecture** for deploying QuantumShield under the Phase 3 default profile (service-edge relay + store-and-forward). It specifies:
- system components and trust boundaries,
- message and control-plane flows,
- deployment and key-management expectations,
- operational guardrails for metadata minimization, and
- integration requirements that **do not modify** QSP/QSE.

**Non-normative:** QSP/QSE are the authoritative specifications for wire format and cryptographic behavior. This guide provides deployable patterns and integration contracts that remain within canonical constraints.

## 1. Phase 3 defaults (confirmed)
### 1.1 Deployment baseline
- **Transport:** service-edge relay + store-and-forward (RSF).  
- **Optional mode:** direct peer-to-peer exists as a future extension and is out of scope for minimum Phase 3 interop.
- **Clients:** iOS (Swift), Android (Kotlin), Desktop (Rust or TypeScript).
- **Server:** Rust services.
- **Key custody:**
  - client long-term keys in OS keystore / secure enclave where available;
  - server-held signing keys in KMS/HSM where applicable; software-only dev fallback permitted.

### 1.2 Canonical invariants (must not be violated)
The following integration invariants are derived from QSP/QSE and are treated as **hard integration constraints**:
1. **RSF MUST NOT decrypt QSP payloads.** RSF treats payload bytes as opaque.
2. **One QSP message per QSE envelope.** RSF MUST NOT concatenate or fragment QSP messages within a single envelope.
3. **Canonical parsing only.** All components that parse QSE or QSP MUST reject malformed/trailing/duplicate encodings per canonical rules.
4. **DoS bounds enforcement.** RSF and receivers MUST enforce QSE bounds; QSP implementations MUST enforce protocol bounds (header attempts, skip windows, caches).
5. **Fail-closed security posture.** RNG failures, validation failures, KT failures (Authenticated mode), and AEAD/tag failures MUST not “degrade” into weaker behavior.

## 2. System model
### 2.1 Components
This architecture is composed of five logical services and three client roles:

**Client roles**
- **Sender client (SC):** originates QSP messages; wraps them in QSE envelopes for transport.
- **Receiver client (RC):** receives QSE envelopes; unwraps QSE; processes QSP; commits ratchet state transactionally.
- **Client key store (CKS):** OS secure storage for long-lived identity keys, pinned KT state, and ratchet state.

**Server-side services**
- **RSF (Relay / Store-and-Forward):** queues and forwards QSE envelopes; enforces size/bounds and coarse anti-abuse policies; does not decrypt QSP.
- **PDS (Prekey Directory Service):** publishes device bundles; serves bundles to initiators; serves OPKs with **serve-at-most-once** semantics.
- **KTL (Key Transparency Log service):** publishes STHs and proofs; supports inclusion + consistency verification.
- **AuthN/AuthZ (Control-plane identity service):** authenticates API clients for PDS/KTL/RSF control-plane endpoints (not part of QSP/QSE).
- **Observability/Audit sink:** receives redacted events and counters (no secrets) for abuse detection and operational monitoring.

**Note:** PDS and KTL may be operated by the same organization but are logically distinct. For test and development they may be co-located.

### 2.2 Trust boundaries and attacker model (integration-relevant)
- RSF is **honest-but-curious** and can observe QSE metadata (`route_token`, `timestamp_bucket`, lengths).
- Network adversary may be **active** (replay, drop, reorder, delay, inject malformed envelopes).
- Server compromise is considered possible for RSF and PDS; architecture therefore:
  - minimizes RSF knowledge of identifiers,
  - makes PDS/KTL integrity verifiable by clients (signatures + KT), and
  - isolates signing keys behind KMS/HSM.

### 2.3 Data classes and secrecy expectations
| Data class | Location | Confidential? | Integrity-protected? | Notes |
|---|---|---:|---:|---|
| QSP message plaintext | endpoints only | Yes | Yes | Never visible to RSF/PDS/KTL |
| QSP ciphertext | on wire / RSF | No (ciphertext) | Yes | Authenticated by AEAD/tag |
| QSE route_token | RSF | No (metadata) | N/A | MUST NOT embed stable plaintext identifiers |
| QSE timestamp_bucket | RSF | No (metadata) | N/A | Coarse replay damping only |
| Bundle public keys | PDS/KTL/clients | No | Yes | Integrity via signatures + KT |
| OPKs (public) | PDS/clients | No | Yes | OPK private keys remain on device |
| Signed bundles, STHs | PDS/KTL/clients | No | Yes | MUST verify signatures; Authenticated mode requires KT |
| Ratchet state | endpoints | Yes | Yes | Must be crash-safe and rollback-resistant |

## 3. Message-plane flow (RSF path)
### 3.1 High-level sequence
```
 Sender Client                          RSF                          Receiver Client
      |                                 |                                 |
      |  (1) QSP Encrypt + QSE Wrap      |                                 |
      |-------------------------------->|                                 |
      |                                 |  (2) Enqueue by route_token     |
      |                                 |-------------------------------->|
      |                                 |  (3) Deliver/Fetch envelopes     |
      |                                 |<--------------------------------|
      |                                 |                                 |
      |                                 |  (4) Receiver QSE Unwrap         |
      |                                 |      + QSP ReceiveMessage        |
      |                                 |                                 |
```

### 3.2 RSF responsibilities (minimum)
RSF MUST:
- validate QSE envelope structure and enforce QSE DoS bounds before accepting into queues,
- treat `payload` as opaque bytes (no parsing, no inspection),
- store and forward envelopes keyed by `route_token`,
- optionally overwrite or set `timestamp_bucket` to authoritative values in service-edge deployments (recommended by QSE),
- provide replay/delay damping as an operational control (not a cryptographic guarantee),
- provide delivery acknowledgements and queue visibility **without leaking stable identifiers**.

RSF MUST NOT:
- split or concatenate payloads,
- attempt heuristic recovery on malformed envelopes,
- store plaintext identifiers inside `route_token`.

### 3.3 Receiver responsibilities (minimum)
Receivers MUST:
- validate and parse QSE canonically (reject malformed/trailing/overrun),
- enforce timestamp bucket acceptance policy (`ALLOW_ZERO_TIMESTAMP_BUCKET=true` in Phase 3 baseline),
- parse QSP payload and run `ReceiveMessage` transactionally (operate on a copy, commit only on full success),
- enforce QSP bounds (MAX_SKIP, header attempts, cache limits),
- reject replays and duplicates at the QSP layer (cryptographically enforced),
- persist state safely (see §7).

### 3.4 Sender responsibilities (minimum)
Senders MUST:
- generate and manage QSP session state per canonical suite rules,
- wrap each QSP message in exactly one QSE envelope,
- select padding policy consistent with deployment profile,
- for service-edge baseline: set `timestamp_bucket=0` and allow the edge to set authoritative bucket if deployed.

## 4. Control-plane flows (PDS + KTL)
### 4.1 Device registration and key publication
The following is a reference pattern; specific endpoints are formalized in P3-06.

1. Client generates long-term identity material (per QSP) and device keys.
2. Client uploads a **device bundle** to PDS:
   - identity public keys,
   - signed bundle metadata,
   - a batch of OPK public keys (optional but recommended).
3. PDS validates signatures (basic hygiene) and stores bundle, indexed by user + device_id.

Operational notes:
- Device bundles and OPK pools SHOULD be refreshed on a schedule to reduce “stale prekey” risk.
- PDS MUST support safe concurrent updates for multi-device accounts.

### 4.2 Bundle retrieval (initiator)
When initiating a session, the sender:
1. fetches receiver bundle from PDS,
2. verifies the bundle signatures (EC and PQ where applicable),
3. performs **Key Transparency verification** (Authenticated mode), including:
   - STH signature verification,
   - inclusion proof verification,
   - consistency proof verification where required,
   - rollback resistance by pinning prior STH state.

If any verification fails, initiation MUST fail-closed (no silent downgrade).

### 4.3 One-time prekey (OPK) serving semantics
PDS MUST implement **serve-at-most-once** semantics:
- each OPK is issued at most once,
- issuance MUST be atomic with marking consumed,
- PDS MUST NOT re-serve an OPK after crash/restart,
- PDS MUST produce audit-safe events for OPK issuance/consumption (no secrets).

If no OPKs are available:
- behavior follows canonical handshake rules (OPK optionality/handling is defined in QSP).

## 5. Envelope metadata minimization (QSE integration)
### 5.1 route_token design (recommended)
QSE requires an opaque `route_token` that RSF can use for delivery. To minimize metadata leakage:

RECOMMENDED properties:
- **Unlinkability:** token SHOULD not be stable across long time windows.
- **Opacity:** token MUST NOT embed stable plaintext identifiers (user_id, device_id, phone/email).
- **Rotation:** token SHOULD rotate at least daily; high-risk deployments rotate more frequently.
- **Length discipline:** keep within `MAX_ROUTE_TOKEN_LEN` and avoid long structured fields.

Reference constructions (choose one; do not mix without careful analysis):
- **Random token:** RSF stores mapping `route_token -> inbox/queue`. Tokens rotated by re-registration.
- **Encrypted token:** `route_token = AEAD_k( user_inbox_id || epoch || nonce )` where `k` is RSF-only; requires careful rotation and abuse logging discipline.
- **Blinded token:** `route_token = HMAC_k( user_inbox_id || epoch )` with rotation; leaks less structure but is deterministic within epoch.

**Phase 3 baseline recommendation:** random tokens with explicit rotation, because they minimize structure and reduce parsing ambiguity.

### 5.2 timestamp_bucket policy (Phase 3 baseline)
- **ALLOW_ZERO_TIMESTAMP_BUCKET = true** at receivers.
- Senders set `timestamp_bucket=0`.
- RSF may overwrite/set `timestamp_bucket` to an authoritative coarse bucket (recommended).
- Receivers apply a configurable acceptance window for non-zero buckets; bucket is replay damping only.

### 5.3 Padding policy (reference)
To reduce length leakage:
- set a deployment `MIN_ENVELOPE_BYTES` (baseline test value 1024),
- pad to at least that minimum; optionally pad to a small set of size buckets (e.g., 1KB/2KB/4KB).
- padding bytes SHOULD be CSPRNG in production.

## 6. Network security and transport considerations
### 6.1 TLS and termination
- All control-plane endpoints (PDS/KTL/RSF APIs) SHOULD be served over TLS with modern configurations.
- TLS termination may occur at an ingress proxy, but services handling:
  - authentication tokens, or
  - sensitive operational metadata
  SHOULD be placed behind strict mTLS between ingress and service where feasible.

### 6.2 Authentication and authorization (non-protocol)
QSP/QSE do not define account authentication. Integration MUST provide:
- client authentication for PDS uploads and RSF fetch/ack,
- rate limiting and abuse mitigation keyed to authenticated identities,
- minimal metadata exposure (avoid placing stable IDs in URLs; prefer opaque handles).

### 6.3 Replay, delay, and reordering
- RSF may see replays; QSP must handle them cryptographically.
- RSF SHOULD implement coarse replay damping:
  - drop duplicates by `(route_token, envelope_hash)` within a small window,
  - enforce queue TTL,
  - enforce per-token rate limits.

These controls are best-effort and MUST NOT be treated as security-critical.

## 7. State persistence and crash-safety boundaries (integration view)
Canonical QSP requires transactional receive semantics (operate on a copy; commit only on full success). Integration MUST ensure:

### 7.1 Client persistence model (minimum)
- Ratchet state is persisted in an **atomic commit unit**.
- A crash at any point during receive MUST not cause partial advancement.
- After restart, duplicate delivery MUST be rejected consistently.

**Reference pattern (portable):**
- write new state to a temp record,
- fsync / commit,
- atomically replace pointer to active state (copy-on-write).

### 7.2 Rollback resistance (minimum)
- pinned KT state and ratchet state SHOULD be protected against rollback:
  - include monotonic counters / version numbers,
  - store in OS-protected storage where possible,
  - optionally use hardware-backed monotonicity (secure enclave / TPM) if available.

P3-07 formalizes this into implementable requirements.

## 8. Observability, telemetry, and audit (redline-safe)
### 8.1 Logging redlines (do not cross)
No component may log:
- plaintext message content,
- any long-term private keys, OPK private keys, ratchet secrets,
- raw QSP decrypted headers/bodies,
- per-message derived symmetric keys,
- full route_token values (unless explicitly required; prefer hashes).

### 8.2 Allowed operational signals (recommended)
- RSF: queue depth per token (aggregated), envelope size histograms, accept/reject counters, rate-limit events.
- PDS: bundle publish events, OPK issuance counters, OPK pool depletion warnings.
- KTL: STH publish cadence, proof serving performance, signature verification failure rates (at clients).
- Clients: crash-safety events, KT verification status, key rotation reminders (no secrets).

### 8.3 Audit event normalization
If audit events are emitted, normalize with:
- time (coarse), event_type, component_id, severity,
- opaque identifiers hashed with deployment salt,
- structured “reason codes” for rejects (parse_fail, bounds_fail, kt_fail, aead_fail, replay, policy).

## 9. Scaling and deployment topology
### 9.1 Minimal production topology
```
                 +-------------------+
                 |   AuthN/AuthZ     |
                 +---------+---------+
                           |
         +-----------------+-----------------+
         |                                   |
+--------v--------+                 +--------v--------+
|      RSF        |                 |   PDS (+KTL)    |
| (store/forward) |                 | (bundles, KT)   |
+--------+--------+                 +--------+--------+
         |                                   |
   QSE envelopes                        bundles/OPKs
         |                                   |
+--------v--------+                 +--------v--------+
|   Receiver(s)   |                 |   Sender(s)     |
|     clients     |                 |    clients      |
+-----------------+                 +-----------------+
```

### 9.2 Sharding and data placement
- RSF queues should be shardable by `route_token` hash prefix.
- PDS bundle storage should be shardable by `(user_handle, device_id)` or by opaque bundle_id.
- KTL is append-only; scale via read replicas for proof serving.

### 9.3 Key management placement
- keep signing keys (PDS/KTL) behind KMS/HSM; services request signatures rather than holding raw keys.
- rotate signing keys on schedule; publish key IDs and rotation events to clients via authenticated channels.

## 10. Interop alignment (Phase 3)
This architecture is aligned to the minimum interop plan (P3-04):
- QSE canonical encode/decode + bounds + smuggling resistance,
- PDS OPK serve-at-most-once semantics,
- KTL STH/inclusion/consistency verification,
- crash between decrypt and commit,
- Suite-1 and Suite-1B, including pq_bind boundary behavior.

## Appendix A — Reference integration checkpoints
These checkpoints are actionable “ready to integrate” milestones:

1. **RSF ingress validation:** rejects malformed QSE, enforces bounds, stores opaque payload.
2. **Client receive pipeline:** QSE parse → policy → QSP ReceiveMessage copy/commit.
3. **PDS OPK semantics:** atomic consume; crash-safe; audit-safe events.
4. **KT verification:** STH/inclusion/consistency; pinned state persisted.
5. **Telemetry redlines:** secrets never logged; route_token hashed in logs.
6. **Rotation:** route_token rotation + signing key rotation + bundle refresh schedule.

## Appendix B — Glossary (integration)
- **QSP:** QuantumShield Protocol (payload crypto and state machine)
- **QSE:** QuantumShield Envelope (transport framing + metadata minimization primitives)
- **RSF:** Relay/Store-and-Forward (transport service)
- **PDS:** Prekey Directory Service (bundles + OPKs)
- **KTL:** Key Transparency Log service (STH + proofs)
- **STH:** Signed Tree Head
- **OPK:** One-time prekey
- **Authenticated mode:** deployment policy requiring KT verification for session establishment

---
**End of document.**
