# QuantumShield Phase 3 — Interoperability Test Plan
**Artifact ID:** P3-04  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs:** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Version:** 1.0  
**Date:** 2025-12-18  
**Timezone:** America/Chicago

## 0. Purpose
This plan defines the **minimum interoperability (interop) test suite** required to demonstrate that two independent implementations of:
- **QSP 4.3.2** (protocol), and
- **QSE 1.8.2** (envelope)

can exchange messages safely and deterministically under the Phase 3 default deployment profile.

This plan is **supporting** and **non-normative**; the canonical documents govern behavior.

## 1. Interop profiles (Phase 3 defaults)
### 1.1 Deployment profile (confirmed defaults)
Baseline operating assumptions:
- **Transport:** service-edge relay + store-and-forward baseline; optional direct mode is out-of-scope for minimum interop.
- **Clients:** iOS (Swift), Android (Kotlin), one desktop client (Rust or TypeScript).
- **Server:** Rust.
- **Key custody:** client long-term keys local to OS keystore/secure enclave where available; server-held signing keys in KMS/HSM where applicable, with software-only dev fallback.

### 1.2 QSE envelope profile (test parameters)
These are **test profile parameters** (not protocol changes):
- `env_version = 0x0100` (QSE 1.x)
- `flags = 0x0000` (QSE 1.8.x)
- `MAX_ROUTE_TOKEN_LEN = 512`
- `MAX_PAYLOAD_LEN = 1_048_576`
- `MAX_PAD_LEN = 1_048_576`
- `MAX_ENVELOPE_LEN = 2_097_152`
- `ALLOW_ZERO_TIMESTAMP_BUCKET = true` (service-edge authoritative)
- `BUCKET_WIDTH_SECONDS = 900` (15 minutes; RECOMMENDED by QSE)
- `BUCKET_SKEW_TOLERANCE = ±2` buckets (RECOMMENDED by QSE)
- `MIN_ENVELOPE_BYTES = 1024` (test value; deployments choose their own)

### 1.3 QSP suite coverage (minimum)
Interop MUST cover both suites:
- **QSP-SUITE-1**
- **QSP-SUITE-1B** (PQ boundary + pq_bind semantics)

### 1.4 Key Transparency (KT) coverage
Interop MUST cover the **Key Transparency profile (normative minimum)** for authenticated sessions, including:
- STH verification,
- inclusion proof verification,
- consistency proof verification,
- and rollback resistance rules for pinned STH state.

## 2. Interop actors and responsibilities
### 2.1 Actors
- **Impl-A:** independent implementation A (client stack)
- **Impl-B:** independent implementation B (client stack)
- **Prekey Directory Service (PDS):** serves bundles and one-time prekeys (OPKs), enforcing at-most-once semantics.
- **KT Log Service (KTL):** provides STHs and proofs required for Authenticated mode verification.
- **Relay / Store-and-Forward (RSF):** carries QSE envelopes without inspecting QSP payload.

### 2.2 Trust boundaries (test assumptions)
- RSF is **honest-but-curious**: it forwards envelopes but may observe envelope metadata and attempt replay/delay.
- PDS and KTL are **logically distinct**; tests may run them in-process for determinism.
- Time is controlled in tests via a **mock clock** for KT freshness and QSE bucket checks.

## 3. Test harness requirements (minimum)
### 3.1 Determinism and fixtures
The harness MUST provide:
- deterministic key generation for test fixtures (seeded CSPRNG in test mode only),
- deterministic transcript and intermediate value capture for debugging (non-production),
- reproducible ordering for out-of-order delivery tests,
- crash/restart injection for persistence tests.

### 3.2 Reporting format
Each test MUST emit a machine-readable record:
- `case_id`
- `suite_id`
- `roles` (A initiator/B responder or vice versa)
- `result` (pass/fail)
- `failure_stage` (parse, kt_verify, hs, hdr_decrypt, body_decrypt, commit, bounds, policy)
- `evidence` (hashes of vectors, STH identifiers, and any derived values permitted for release)

## 4. Interop test catalog (minimum)
**Legend:**  
- Suites: S1 = Suite-1, S1B = Suite-1B  
- Transport: QSE always used unless explicitly stated.  
- “Reject” means: drop message and **MUST NOT commit any durable ratchet state**.

### 4.1 QSE envelope interop
**IT-QSE-001 (S1/S1B): canonical encode/decode round-trip**  
- **Spec refs:** QSE §1, §2  
- **Steps:** Impl-A encodes an envelope containing a single valid QSP message; Impl-B decodes; then re-encodes and compares fields.  
- **Expected:** exact field preservation for `env_version, flags, route_token, timestamp_bucket, payload_len, pad_len`; payload bytes unchanged.

**IT-QSE-002 (S1/S1B): one-QSP-message-per-envelope enforcement**  
- **Spec refs:** QSE §1, §2  
- **Steps:** construct an envelope whose payload concatenates two QSP messages; deliver to receiver.  
- **Expected:** receiver rejects (no heuristic splitting).

**IT-QSE-003: bounds enforcement**  
- **Spec refs:** QSE §3  
- **Steps:** generate envelopes that exceed each MAX_* bound by 1 byte.  
- **Expected:** reject each violating case; accept boundary-equal cases.

**IT-QSE-004: timestamp bucket policy (service-edge authoritative)**  
- **Spec refs:** QSE §4.1–§4.4  
- **Steps:** deliver envelopes with `timestamp_bucket=0`, and with bucket values within/outside tolerance using mock clock.  
- **Expected:** accept `0` when allowed; accept within tolerance; reject outside tolerance.

**IT-QSE-005: smuggling resistance**  
- **Spec refs:** QSE §2  
- **Steps:** add trailing bytes beyond pad; truncate mid-field; set lengths that overrun remaining bytes.  
- **Expected:** reject all malformed cases.

### 4.2 Prekey bundles + KT interop (Authenticated mode)
**IT-KT-001: verify both bundle signatures**  
- **Spec refs:** QSP §4.3  
- **Steps:** deliver bundle with valid EC signature but invalid PQ signature (and vice versa).  
- **Expected:** reject if any signature fails.

**IT-KT-002: verify STH signatures and pinning**  
- **Spec refs:** QSP §4.4.4–§4.4.6  
- **Steps:** provide valid STH; then provide a different STH with invalid signature; then provide a valid newer STH.  
- **Expected:** reject invalid; accept valid newer and update pinned state.

**IT-KT-003: inclusion proof verification**  
- **Spec refs:** QSP §4.4.4–§4.4.5  
- **Steps:** provide bundle whose leaf is not in the log (bad inclusion proof).  
- **Expected:** reject authenticated session establishment.

**IT-KT-004: consistency proof and rollback resistance**  
- **Spec refs:** QSP §4.4.6  
- **Steps:** start with pinned STH; provide a new STH with smaller tree_size; provide a new STH with unjustified root_hash.  
- **Expected:** reject rollback/unjustified states.

### 4.3 OPK service semantics interop
**IT-OPK-001: serve-at-most-once (atomic consume)**  
- **Spec refs:** QSP §4.5  
- **Steps:** request an OPK twice concurrently for the same device; also crash the PDS between “select” and “consume” in an injected-fault run.  
- **Expected:** at most one successful issuance; no re-serve after crash; consistent audit events.

**IT-OPK-002: OPK absence handling**  
- **Spec refs:** QSP §4.2, §5 (where OPK is optional in handshake)  
- **Steps:** run handshake when device has no OPKs available.  
- **Expected:** handshake proceeds or fails exactly as specified by canonical text; interop demonstrates consistent behavior across implementations.

### 4.4 Handshake interop (S1 and S1B)
**IT-HS-001 (S1): baseline handshake A→B**  
- **Spec refs:** QSP §5.1–§5.6  
- **Steps:** A fetches bundle for B (KT verified); sends HandshakeInit; B responds HandshakeResp; both derive post-handshake state.  
- **Expected:** both sides reach “session established”; derived state matches on both sides (session_id, suite_id, counters initialized, RK/CK alignment as specified).

**IT-HS-002 (S1): responder rejects suite mismatch**  
- **Spec refs:** QSP §2.4, §5, §10  
- **Steps:** deliver HandshakeResp with mismatched suite_id/protocol_version.  
- **Expected:** initiator rejects; no state committed.

**IT-HS-003 (S1B): baseline handshake A→B + pq_bind readiness**  
- **Spec refs:** QSP §6.1, §8.4  
- **Steps:** establish S1B session; verify that subsequent boundary message enforces pq_bind behavior (see IT-MSG-2xx).  
- **Expected:** both sides agree on suite and boundary handling; pq_bind mismatch leads to reject.

**IT-HS-004: invalid conf/signature paths**  
- **Spec refs:** QSP §5.2–§5.6  
- **Steps:** flip bits in signatures and conf fields in HandshakeInit/HandshakeResp.  
- **Expected:** reject; no partial commit.

### 4.5 Messaging interop: in-order, out-of-order, replay, skip
**IT-MSG-001 (S1): post-handshake in-order messaging**  
- **Spec refs:** QSP §7–§9  
- **Steps:** exchange 100 messages alternating directions; no ratchets triggered.  
- **Expected:** all decrypt; counters advance correctly; no memory leaks; bounded caches respected.

**IT-MSG-002 (S1): out-of-order delivery within MAX_SKIP**  
- **Spec refs:** QSP §8.3, §9.5  
- **Steps:** send messages N..N+50; deliver in permuted order; include duplicates.  
- **Expected:** decrypt in-range messages; duplicates rejected; caches bounded.

**IT-MSG-003 (S1): out-of-order beyond MAX_SKIP**  
- **Spec refs:** QSP §8.3  
- **Steps:** deliver a message with sequence gap beyond MAX_SKIP.  
- **Expected:** reject; no unbounded scan.

**IT-MSG-004 (S1): replay of already accepted message**  
- **Spec refs:** QSP §8.3, §9.5  
- **Steps:** deliver the same ciphertext twice after success.  
- **Expected:** second delivery rejected without state change.

### 4.6 DH ratchet + boundary interop
**IT-RAT-001 (S1): sender DH ratchet triggers boundary message**  
- **Spec refs:** QSP §8.4, §9.1–§9.5  
- **Steps:** force DHRatchetSend at A; verify first outbound after ratchet is boundary; B receives and ratchets.  
- **Expected:** epoch transition succeeds; wrong-key or missing-boundary cases reject.

**IT-RAT-002 (S1): delayed old-epoch message handling**  
- **Spec refs:** QSP §8.4, §9.2, §9.5  
- **Steps:** send ratchet boundary; then deliver an old-epoch message late.  
- **Expected:** old-epoch decrypt (if allowed by HKSKIPPED); MUST NOT trigger ratchet or accept boundary-on-old epoch misuse.

**IT-RAT-003 (S1): MAX_HEADER_ATTEMPTS bound enforcement**  
- **Spec refs:** QSP §8.3  
- **Steps:** craft messages that force repeated header-decrypt attempts and exceed the maximum.  
- **Expected:** bounded work; reject beyond cap.

### 4.7 PQ boundary interop (Suite-1B)
**IT-PQ-001 (S1B): pq_bind tamper resistance**  
- **Spec refs:** QSP §6.1, §8.4  
- **Steps:** modify on-wire PQ prefix fields or PQ flags while keeping ciphertext constant.  
- **Expected:** receiver rejects; MUST NOT commit any ratchet state.

**IT-PQ-002 (S1B): PQ advertisement and target_id discipline**  
- **Spec refs:** QSP §8.4, §9.5  
- **Steps:** boundary message advertises PQ receive key; later boundary uses PQ ciphertext targeted to that id.  
- **Expected:** correct decapsulation; one-time use enforced; reuse rejected.

**IT-PQ-003 (S1B): missing or invalid PQ ciphertext on boundary**  
- **Spec refs:** QSP §8.4  
- **Steps:** boundary missing required PQ_CTXT fields or contains invalid ciphertext.  
- **Expected:** reject; no partial commit.

### 4.8 Persistence and crash-safety interop (minimum)
**IT-DUR-001: crash between decrypt and commit**  
- **Spec refs:** QSP §9.5, §10.6; QSE §2  
- **Steps:** inject crash after header decrypt but before body decrypt; after body decrypt but before commit; then restart.  
- **Expected:** no partial state advancement; replay behavior consistent post-restart.

**IT-DUR-002: rollback detection**  
- **Spec refs:** QSP §10.6 (anti-rollback guidance)  
- **Steps:** restore prior persisted state snapshot and attempt to continue.  
- **Expected:** detection and discard of compromised session per canonical rules.

---

## 5. Exit criteria (minimum)
Interop is considered successful when:
- All test cases above pass for **A↔B** in both initiator directions and for **Suite-1** and **Suite-1B**.
- Negative tests demonstrate **fail-closed** behavior and **no partial commit**.
- Bounds tests demonstrate **strict work limits** and no quadratic/unbounded scans.
- KT tests demonstrate correct pinning and rollback resistance behavior.
- Crash-safety tests demonstrate transactional state semantics across restart.

---
**End of document.**
