# QuantumShield Phase 3 — Key Directory / Prekey Service Contract (PDS + KTL)
**Artifact ID:** P3-06  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs:** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Version:** 1.0  
**Date:** 2025-12-19  
**Timezone:** America/Chicago

## 0. Purpose and scope
This document specifies the integration contract for:
- **PDS (Prekey Directory Service)**: device bundle publication, bundle retrieval for initiators, and one-time prekey (OPK) serving with **serve-at-most-once** semantics.
- **KTL (Key Transparency Log Service)**: minimal interface required for clients (or PDS) to obtain STHs and proofs used in QSP Authenticated mode.

This is a **supporting** artifact. It does not modify QSP/QSE wire formats. It defines deployable service APIs and operational semantics consistent with canonical requirements.

## 1. Roles and trust boundaries
### 1.1 Roles
- **Publisher (Device)**: a device that owns identity keys and publishes (or updates) its bundle and OPK pools.
- **Initiator (Client)**: retrieves a receiver’s bundle(s) to initiate a QSP handshake.
- **PDS**: stores bundle metadata and OPK pools; serves bundles; consumes OPKs at-most-once.
- **KTL**: append-only transparency log for bundle leaf commitments; provides STH and proofs.

### 1.2 Trust boundaries (deployment default)
- PDS is a service component and may be compromised; the protocol safety model relies on **client-side signature verification and KT verification** for authenticated sessions (per QSP).
- KTL integrity is verified by clients through log signing keys pinned out-of-band (per QSP KT profile).
- PDS MUST NOT require access to endpoint private keys. PDS MUST NOT see QSP plaintext messages.

## 2. Canonical alignment (what this contract assumes)
This contract intentionally treats certain items as **opaque bytes** whose canonical structure is defined by QSP:
- **PrekeyBundle**: served to initiators; it is the canonical encoding defined in **QSP 4.3.2 §4.3** (including signatures and KT fields as defined there).
- **KT objects**: STH, inclusion proof, consistency proof; canonical encodings are defined in **QSP 4.3.2 §4.4**.

PDS may store structured metadata for indexing and policy, but the served bundle MUST be the canonical QSP encoding.

## 3. High-level functional requirements
### 3.1 Directory guarantees
PDS MUST provide:
1. **Bundle publication** for a `(user_handle, device_id)` pair.
2. **Bundle retrieval** for a target user (returning one or more device bundles).
3. **OPK management**: upload, inventory status, and on-demand consumption when serving bundles.

### 3.2 OPK serve-at-most-once (hard requirement)
Consistent with QSP 4.3.2 §4.5 service requirement:
- PDS MUST hand out each OPK at most once per device.
- PDS MUST atomically mark the OPK as consumed (or delete it) when served.
- PDS MUST reject replay of consumed OPKs.

Operational strengthening (recommended, and REQUIRED for production profiles that claim “at-most-once” under crash):
- PDS SHOULD ensure that after crash/restart it does not re-serve a previously consumed OPK (i.e., consumption is durable and atomic with issuance).

### 3.3 Privacy requirements (service-layer)
- PDS endpoints MUST be authenticated and authorization-controlled to prevent bulk enumeration.
- PDS identifiers MUST be opaque and MUST NOT require exposing stable plaintext identifiers in URLs or logs.
- PDS responses SHOULD avoid returning unnecessary metadata (counts, precise timestamps) that increase linkage risk.

## 4. Data model
### 4.1 Identifiers
- `user_handle` (string): an opaque stable identifier used by services (not necessarily the same as QSP `user_id`).
  - RECOMMENDED: 16–32 bytes base64url or hex, derived from a server-issued opaque handle.
- `device_id` (u32): device identifier; may correspond to QSP bundle fields but does not need to be globally meaningful outside the account namespace.
- `bundle_id` (string): opaque identifier for a published bundle version.
- `opk_id` (u32): identifier for a one-time prekey (DH and/or PQ) as used in QSP bundle fields.
- `log_id` (32 bytes): KT log identifier as per QSP KT profile.

### 4.2 Stored objects
#### 4.2.1 BundleRecord
A PDS BundleRecord SHOULD store:
- `user_handle`
- `device_id`
- `bundle_id`
- `bundle_tbs_fields` (optional structured fields used for policy; may be stored as opaque bytes)
- `sig_ec` (bytes)
- `sig_pq` (bytes)
- `valid_from`, `valid_to` (u64 or ISO-8601)
- `pq_rcv_id`, `pq_rcv_pub` (optional indexing fields; may remain opaque)
- `bundle_revision` (monotonic integer for optimistic concurrency)
- `status` (active | revoked | suspended)
- `published_at` (coarse timestamp)

PDS MUST be able to produce a served **PrekeyBundle** in canonical QSP encoding for initiators, optionally including an OPK.

#### 4.2.2 OPK pools
Separate pools per `(user_handle, device_id)`:
- **OPK_DH pool**: entries `{opk_id, opk_pub(32), state: available|consumed, created_at, consumed_at?}`
- **OPK_PQ pool**: entries `{opk_id, opk_pub(1184), state: available|consumed, created_at, consumed_at?}`

PDS SHOULD maintain per-pool inventory counters (coarse, for alerts), but MUST avoid leaking them to unauthorized parties.

#### 4.2.3 KT material (optional storage strategy)
Two acceptable strategies:
- **Client-fetch KT**: clients query KTL directly for STH/proofs; PDS returns bundle material that references log_id and leaf binding inputs.
- **PDS-packaged KT (recommended for UX)**: PDS retrieves KT materials from KTL and embeds them into the served PrekeyBundle fields (`kt_log_id`, `kt_sth`, `kt_inclusion_proof`, `kt_consistency_proof`) per QSP bundle format.

This contract supports both; production deployments SHOULD prefer PDS-packaged KT to reduce client complexity and ensure consistent freshness policy.

## 5. API overview (versioning and transport)
### 5.1 Transport
- HTTPS required for all endpoints.
- JSON request/response bodies for service control-plane APIs.
- Canonical QSP objects (PrekeyBundle, KT varbytes) are returned as **base64url** fields in JSON.

### 5.2 Versioning
- All endpoints are under `/v1/`.
- Backwards-incompatible API changes require `/v2/`.

### 5.3 Authentication/authorization
- Use a standard bearer token or mTLS identity bound to an account.
- Authorization MUST enforce:
  - publishers may modify only their own `(user_handle, device_id)` records,
  - initiators may retrieve only bundles they are entitled to request (policy-defined),
  - administrative endpoints restricted.

## 6. PDS API: bundle publication
### 6.1 Publish or update a device bundle
`PUT /v1/pds/users/{user_handle}/devices/{device_id}/bundle`

Purpose: publish the device’s bundle signing material and validity window.

Request (JSON):
- `bundle_format`: string (e.g., `"QSP-4.3.2"`)
- `bundle_fields_b64`: base64url (the canonical bytes of all bundle fields up to OPK fields, excluding signatures and KT data; i.e., the fields used to compute BundleTBS in QSP §4.3.1)
- `sig_ec_b64`: base64url
- `sig_pq_b64`: base64url
- `valid_from`: u64 (seconds since epoch) or ISO-8601 string
- `valid_to`: u64 (seconds since epoch) or ISO-8601 string
- `kt_log_id_b64`: base64url(32) (preferred log)
- `idempotency_key`: string (required for safe retries)

Response (JSON):
- `bundle_id`: string
- `bundle_revision`: integer
- `status`: `"active"`
- `warnings`: array of strings (optional)

Semantics:
- PDS MUST store the bundle material and make it retrievable by initiators.
- PDS MAY perform basic hygiene checks (sizes, required fields present), but MUST NOT “fix” publisher data.
- PDS SHOULD validate that `valid_to` is not excessively long-lived (deployment policy).
- PDS MUST support safe retry via `idempotency_key` (same request yields same `bundle_id`/revision).

Concurrency:
- If the request includes `if_revision` (optional integer), PDS MUST reject with `409 conflict` if it does not match the current `bundle_revision`.

### 6.2 Revoke a bundle/device
`POST /v1/pds/users/{user_handle}/devices/{device_id}/revoke`

Request:
- `reason_code`: string (optional)
- `idempotency_key`: string

Response:
- `status`: `"revoked"`
- `revoked_at`: coarse timestamp

Semantics:
- Revocation prevents the bundle from being served to initiators.
- PDS SHOULD keep revoked records for audit, but MUST NOT retain secrets (it should not have any).

## 7. PDS API: OPK management
### 7.1 Upload OPKs (DH)
`POST /v1/pds/users/{user_handle}/devices/{device_id}/opk_dh:batchUpload`

Request:
- `items`: array of `{opk_id: u32, opk_pub_b64: base64url(32)}`
- `idempotency_key`: string

Response:
- `accepted`: integer
- `rejected`: integer
- `reject_reasons`: optional array (per item)

Semantics:
- PDS MUST reject duplicate `opk_id` for the same `(user_handle, device_id)` unless the identical public key is re-uploaded with idempotency semantics.
- PDS SHOULD enforce per-device pool caps (DoS control).
- PDS MUST treat OPK pubs as public data, but MUST still protect them from bulk scraping via authZ and rate limits.

### 7.2 Upload OPKs (PQ)
`POST /v1/pds/users/{user_handle}/devices/{device_id}/opk_pq:batchUpload`

Request:
- `items`: array of `{opk_id: u32, opk_pub_b64: base64url(1184)}`
- `idempotency_key`: string

Response: same shape as DH.

### 7.3 Optional: OPK inventory (authorized)
`GET /v1/pds/users/{user_handle}/devices/{device_id}/opkInventory`

Response:
- `dh_available`: integer (coarse bucketed count; e.g., 0, 1–10, 11–100, 101+)
- `pq_available`: integer (coarse bucketed count)
- `last_upload_at`: coarse timestamp

This endpoint MUST be restricted (publisher and/or admin only).

## 8. PDS API: bundle retrieval (initiator path)
### 8.1 Retrieve bundles for a user
`GET /v1/pds/users/{user_handle}/bundles`

Query parameters:
- `protocol_version`: optional (e.g., `0x0403`)
- `suite_id`: optional (e.g., `0x0001`)
- `opk_policy`: `"preferred"` (default) | `"required"` | `"none"`
- `kt_mode`: `"packaged"` (default) | `"client_fetch"`

Response (JSON):
- `user_handle`
- `bundles`: array of objects, each:
  - `device_id`: u32
  - `bundle_id`: string
  - `prekey_bundle_b64`: base64url (the canonical QSP PrekeyBundle encoding)
  - `served_opk`: object (optional; informational only)
    - `dh_opk_id`: u32? (if included)
    - `pq_opk_id`: u32? (if included)
  - `expires_at`: coarse timestamp (optional)
- `sth_hint`: optional object (for client_fetch mode)
  - `kt_log_id_b64`
  - `sth_b64` (optional)

Semantics:
- For each active device, PDS SHOULD return one bundle.
- PDS MUST NOT serve revoked/suspended devices.
- If `opk_policy=preferred`, PDS includes an OPK when available; otherwise serves bundle with OPK absent flags.
- If `opk_policy=required`, PDS MUST return `409 opk_unavailable` if no OPK is available (for the requested suite’s OPK types).
- If `opk_policy=none`, PDS MUST NOT consume an OPK and MUST serve bundle with OPK absent flags.

KT packaging:
- If `kt_mode=packaged`, PDS MUST embed `kt_log_id`, `kt_sth`, `kt_inclusion_proof`, and `kt_consistency_proof` inside the served PrekeyBundle fields, per QSP format.
- If `kt_mode=client_fetch`, PDS may omit KT fields in the served bundle (only if QSP format allows omission for a mode); otherwise PDS returns KT materials separately. Deployments SHOULD prefer packaged KT.

### 8.2 OPK consumption atomicity
When `opk_policy` causes OPK issuance, PDS MUST:
- select one available OPK from the appropriate pool(s),
- atomically transition that OPK to `consumed` as part of producing the served PrekeyBundle,
- ensure concurrent requests do not cause double-issuance of the same OPK.

Atomicity patterns (implementation guidance):
- single-row transactional update with `WHERE state=available LIMIT 1 RETURNING ...` (DB-specific),
- compare-and-swap state transitions,
- or a durable queue/lease mechanism with immediate consume.

## 9. KTL API (minimal contract)
This section is the minimal KTL surface needed for QSP Authenticated mode. Implementations may add endpoints, but must preserve these semantics.

### 9.1 Fetch latest STH
`GET /v1/ktl/logs/{log_id}/sth`

Response:
- `sth_b64`: base64url (canonical STH bytes as defined in QSP §4.4)
- `cache_ttl_seconds`: integer (optional)

### 9.2 Fetch inclusion proof for a leaf
`POST /v1/ktl/logs/{log_id}/inclusionProof`

Request:
- `leaf_hash_b64`: base64url(32)
- `tree_size`: u64 (optional; if omitted, KTL uses latest)

Response:
- `sth_b64`
- `inclusion_proof_b64` (canonical encoding per QSP §4.4.5)

### 9.3 Fetch consistency proof between two tree sizes
`POST /v1/ktl/logs/{log_id}/consistencyProof`

Request:
- `from_tree_size`: u64
- `to_tree_size`: u64 (optional; default latest)

Response:
- `to_sth_b64`
- `consistency_proof_b64` (canonical encoding per QSP §4.4.5; may be empty when allowed)

### 9.4 Append leaf (service/operator path)
If PDS is responsible for submitting leaves:
`POST /v1/ktl/logs/{log_id}/append`

Request:
- `leaf_data_b64`: base64url (canonical leaf binding inputs per QSP §4.4.3)
- `idempotency_key`: string

Response:
- `sth_b64`
- `inclusion_proof_b64`

Note: Some deployments treat KTL append as admin-only and handle leaf ingestion out-of-band. If so, PDS-packaged KT may be delayed; in that case, PDS MUST clearly signal freshness/availability constraints to clients.

## 10. Error model
### 10.1 Common error response
On non-2xx, return JSON:
- `error_code`: string
- `message`: string (safe for logs; no secrets)
- `retryable`: boolean
- `details`: object (optional; sanitized)

### 10.2 Standard error codes
- `unauthorized` (401)
- `forbidden` (403)
- `not_found` (404)
- `conflict` (409) — revision mismatch, duplicate IDs, invariant violation
- `opk_unavailable` (409) — opk_policy=required but none available
- `rate_limited` (429)
- `invalid_request` (400)
- `server_error` (500)

## 11. Security and abuse controls
### 11.1 Rate limits (recommended)
- Per authenticated principal:
  - bundle fetch: N/min
  - OPK upload: M/min
- Per target `user_handle` to prevent harassment enumeration.

### 11.2 Enumeration resistance
- Require auth for all fetch endpoints.
- Avoid precise “user exists” signals: for unauthorized requesters, return generic 404.
- Consider response padding to reduce distinguishability (optional; deployment-dependent).

### 11.3 Logging redlines
PDS/KTL MUST NOT log:
- any endpoint private keys (they should never be present),
- raw bearer tokens,
- full `prekey_bundle_b64` contents,
- full `route_token` values (QSE), if ever handled in adjacent services.

Allowed logs:
- request IDs, coarse timestamps, outcome codes,
- hashed `user_handle`/`device_id` with deployment salt,
- OPK consumption events referencing `opk_id` only (public).

### 11.4 Audit events (recommended schema)
Emit sanitized events:
- `BUNDLE_PUBLISHED` (user_handle_hash, device_id, bundle_id)
- `BUNDLE_REVOKED`
- `OPK_UPLOADED` (count, dh/pq)
- `OPK_CONSUMED` (opk_id, dh/pq)
- `KT_STH_SERVED` / `KT_PROOF_SERVED` (counts only)

## 12. Interop and conformance mapping (Phase 3)
Minimum tests to implement (aligned with P3-03/P3-04):
- OPK at-most-once: concurrent fetches do not duplicate issuance.
- OPK replay: re-request after consume does not return same OPK.
- Bundle retrieval returns canonical PrekeyBundle bytes; clients can verify signatures and (where applicable) KT proofs.
- KT canonical encoding: proofs rejected if trailing bytes or malformed counts per QSP §4.4.5.
- Failure modes: opk_policy=required returns deterministic error when depleted.

## Appendix A — Worked examples (illustrative)
### A.1 Retrieve bundle (preferred OPK)
Client:
`GET /v1/pds/users/uh_9f3c.../bundles?opk_policy=preferred&kt_mode=packaged`

PDS returns:
- one bundle per device
- each `prekey_bundle_b64` includes OPK fields when available and includes KT materials embedded per QSP bundle format

### A.2 OPK depletion
If depleted and opk_policy=preferred:
- serve bundle without OPK (present flags set to 0) and include warning in `details` (optional)

If depleted and opk_policy=required:
- return 409 `opk_unavailable` (retryable=true)

---
**End of document.**
