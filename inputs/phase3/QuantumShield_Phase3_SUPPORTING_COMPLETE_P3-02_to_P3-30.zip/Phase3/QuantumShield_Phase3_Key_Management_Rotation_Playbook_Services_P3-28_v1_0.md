# QuantumShield Phase 3 — Key Management & Rotation Playbook (Services)
**Artifact ID:** P3-28  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (alignment only):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Related Phase 3 artifacts (alignment only):** P3-11 (Ops/Privacy Runbook), P3-12 (Parameter Registry), P3-20 (AuthN/AuthZ), P3-21 (KT Verification), P3-26 (Observability), P3-27 (Abuse Controls), P3-30 (Release Acceptance)  
**Version:** 1.0  
**Date:** 2025-12-19  
**Timezone:** America/Chicago  

## 0. Purpose and scope
This document defines the **key management, rotation, and incident response playbook** for QuantumShield Phase 3 services:

- **RSF** (Relay/Store-and-Forward)
- **PDS** (Prekey Directory Service)
- **KTL** (Key Transparency Log)
- **Auth** (token issuer; may be external but must conform to this playbook when used for QuantumShield)

It specifies:
- what key materials exist (by service and purpose),
- how they must be generated, stored, accessed, audited, and rotated,
- emergency procedures for suspected compromise, and
- conformance requirements and evidence collection.

This artifact is **supporting** and **atomic**. It does not modify QSP/QSE wire formats or cryptographic constructions; it governs operational handling of keys used by services surrounding the canonical protocol.

## 1. Non-negotiable rules (MUST)
1. **Environment separation:** Dev/staging/prod keys MUST be cryptographically and administratively isolated (separate KMS projects/accounts/tenants).
2. **No plaintext key material at rest outside KMS/HSM:** Long-lived private keys and master encryption keys MUST reside in KMS/HSM-backed storage; exporting private keys is prohibited unless explicitly required for migration and approved with dual control.
3. **Least privilege + dual control:** Key creation, rotation, and deletion MUST require privileged roles with separation of duties (two-person approval for production signing keys).
4. **Rotation overlap:** Rotations MUST include an overlap window so verifiers can accept both old and new keys for a bounded period.
5. **Auditability:** Every privileged key event (create/rotate/disable/destroy/export) MUST generate an audit event retained per policy (P3-26).
6. **Fail closed:** If the key infrastructure is unavailable or returns unexpected key material, services MUST fail closed (deny signing operations; do not silently downgrade to insecure behavior).
7. **No secrets in telemetry:** Keys, tokens, and raw identifiers MUST NOT appear in logs/metrics/traces (P3-26 redlines).

## 2. Key inventory (by service)
This section defines the **minimum** key materials required for an interoperable Phase 3 deployment. Deployments may add keys for infrastructure needs, but must not remove these without a security review.

### 2.1 Auth service (token issuer) keys
**Purpose:** Sign access tokens (and refresh tokens, if used).  
**Type:** Signing keys; symmetric MAC keys are discouraged unless strictly internal.

Required keys:
- **AUTH.JWT.SIGN.EC** (recommended): ECDSA P-256 *or* Ed25519 signing key.
- **AUTH.JWT.SIGN.PQ** (optional, forward-looking): PQ signature for token objects (if a hybrid scheme is implemented).

Constraints:
- Token validation keys MUST be distributable to RSF/PDS/KTL verifiers via a trusted configuration channel.
- Tokens MUST carry a `kid` (key id) and `iss`/`aud` claims (P3-20).

### 2.2 RSF keys
**Purpose:** Protect RSF operational data and authenticate internal service calls.

Required keys:
- **RSF.DB.ENC.MASTER**: master encryption key for RSF datastore encryption (envelope storage and mapping tables).
- **RSF.APP.SECRET**: application secret for deterministic, non-cryptographic purposes (rate limit salt derivation seed, if not supplied by KMS; see §6.3). This is not a signing key and MUST NOT be used for encryption.
- **RSF.MTLS.IDENTITY** (if using mTLS): TLS private key/certificate for service identity.

Notes:
- RSF MUST NOT store raw `route_token` in logs; datastore may store route_token bytes (needed for routing) but should encrypt at rest using RSF.DB.ENC.MASTER.

### 2.3 PDS keys
**Purpose:** Protect bundle storage, OPK inventory metadata, and service identity.

Required keys:
- **PDS.DB.ENC.MASTER**: master encryption key for PDS datastore encryption.
- **PDS.IDEMPOTENCY.MAC** (optional): a MAC key used to derive idempotency record keys to avoid storing raw idempotency keys. If used, must be KMS-managed.
- **PDS.MTLS.IDENTITY** (if using mTLS): TLS private key/certificate for service identity.

Notes:
- PDS must handle OPK “serve-at-most-once”; key management must ensure that DB encryption does not break atomicity guarantees.

### 2.4 KTL keys
**Purpose:** Produce authenticated, append-only transparency log artifacts.

Required keys:
- **KTL.STH.SIGN.EC**: Ed25519 signing key for STHs (P3-21).
- **KTL.STH.SIGN.PQ**: ML-DSA-65 signing key for STHs (P3-21).
- **KTL.DB.ENC.MASTER**: encryption key for log storage (leaves, checkpoints, operator metadata).
- **KTL.MTLS.IDENTITY** (if using mTLS): TLS private key/certificate for internal operator pipeline.

Constraints:
- KTL signing keys are security-critical and MUST be HSM-backed where available.
- KTL verifiers MUST pin public keys out-of-band (P3-21). Rotation must therefore be carefully staged (see §5.4).

### 2.5 Shared operational keys
Some keys are shared across services in tightly controlled deployments; avoid this unless necessary.

If shared keys exist:
- Their scope MUST be limited (e.g., a shared KMS CMK used only for envelope-at-rest encryption), and
- Access policies MUST remain per-service (RSF and PDS principals not interchangeable).

## 3. Key lifecycle states and required metadata
### 3.1 States
Keys MUST have explicit states:
- `PENDING` (created, not yet active)
- `ACTIVE` (used for signing/encryption)
- `DEPRECATED` (no longer used for new operations; still accepted for verification/decryption)
- `RETIRED` (no longer accepted; kept only for archival if required)
- `DESTROYED` (material deleted; irreversible)

### 3.2 Metadata fields (MUST)
Each key MUST be tracked with:
- `key_name` (stable identifier, e.g., `KTL.STH.SIGN.EC`)
- `kid` (unique key id; include version)
- `env` (dev/staging/prod)
- `created_at`, `activated_at`, `deprecated_at`, `retired_at` (timestamps)
- `owner` (service name)
- `algo` (e.g., Ed25519, ML-DSA-65, AES-256-GCM key in KMS)
- `kms_uri` or HSM slot reference
- `rotation_policy` (period + overlap)
- `break_glass` contacts / runbook link

## 4. Storage and access controls
### 4.1 KMS/HSM requirements
Production deployments SHOULD use managed KMS or dedicated HSM:
- Signing operations for KTL and Auth SHOULD occur inside HSM/KMS (non-exportable keys).
- DB master keys SHOULD be KMS keys used to wrap data encryption keys (DEKs) or used directly as envelope encryption keys in a standard envelope encryption pattern.

### 4.2 Envelope encryption pattern (recommended)
For RSF/PDS/KTL datastores:
- Use a KMS master key to wrap per-record or per-table DEKs.
- Encrypt data with AEAD (e.g., AES-256-GCM or XChaCha20-Poly1305) using DEKs.
- Store DEK-wrapped blobs alongside ciphertext in DB.
- Rotate master key by re-wrapping DEKs (fast) rather than re-encrypting all records (slow).

### 4.3 Access control model (MUST)
- Each service runtime identity MUST be granted:
  - `sign` permission for its own signing keys (if applicable),
  - `decrypt` / `wrap` / `unwrap` for its own DB master keys,
  - no permissions for other services’ keys.
- Human operators MUST NOT have routine access to private key material. Administrative actions are performed via audited KMS APIs with strong authentication.

### 4.4 Secret distribution (MUST)
Configuration channels that distribute public keys, `kid` allowlists, and service endpoints MUST be authenticated and integrity protected (e.g., signed config, mTLS, or secure config management system).

Do not distribute private keys through configuration.

## 5. Rotation policies (planned maintenance)
Rotations are of three types:
- **Verification-affecting signing keys** (Auth and KTL)
- **Encryption master keys** (DB encryption)
- **Service identity keys** (mTLS)

### 5.1 Standard rotation intervals (recommended)
- Auth token signing keys: every 30–90 days
- KTL STH signing keys: every 180–365 days (rare; requires pinning transition)
- DB master keys: every 90–180 days
- mTLS service identities: every 30–90 days (automated), or per cert TTL

Deployments may tighten schedules; do not extend without justification.

### 5.2 Overlap windows (normative)
- Auth token signing keys overlap: at least 2x max access-token TTL + clock skew
  - Recommended: 48 hours overlap
- DB encryption keys overlap: accept decrypt with all `DEPRECATED` keys until rewrap completes
- mTLS overlap: support multiple trusted issuer certs during rotation

### 5.3 Auth token signing rotation (procedure)
1. **Create** new signing key version in KMS/HSM (`PENDING`).
2. **Distribute** new public key + `kid` to RSF/PDS/KTL verifiers via secure config.
3. **Activate** new key for signing (`ACTIVE`) while keeping old key `DEPRECATED` for verification.
4. Maintain overlap for the full overlap window.
5. **Retire** old key: remove from verifier allowlist after overlap; mark `RETIRED`.
6. **Destroy** only if policy permits and after audit retention requirements.

Failure handling:
- If verifiers cannot fetch new key config, do not switch signers to the new key; maintain availability.

### 5.4 KTL STH signing rotation (pinning-sensitive procedure)
Because clients pin KT log signing keys (P3-21), rotation must be staged with explicit client acceptance.

Minimum staged approach:
1. **Dual-sign period:** Introduce a new keypair and publish STHs signed by both old and new keys (requires STH format support for multiple keys; if not supported, publish a signed “key transition statement” out-of-band).
2. **Client update:** Update clients/SDKs to trust the new public keys (allowlist) while still trusting old keys.
3. **Overlap window:** Maintain dual acceptance for a long overlap (recommended: 90 days).
4. **Deprecate old keys:** After sufficient client update coverage, stop signing with old keys; keep old keys in verifier allowlists until overlap ends.
5. **Retire** old keys.

If your STH format includes exactly two signatures (EC and PQ), the “dual-sign” step refers to rotating EC and PQ keys separately but maintaining one active pair at a time. In that case, rotation MUST be coordinated with a separate “log keyset id” and client allowlist update, not by adding extra signatures.

This document does not change STH encoding; it defines the operational constraints to keep pinning safe.

### 5.5 DB master key rotation (procedure)
Preferred method: re-wrap DEKs rather than re-encrypting entire DB.

1. Create new KMS CMK version (`PENDING`).
2. Update service config to allow decrypt/unwarp with both old and new CMK.
3. Activate new CMK for wrapping newly created DEKs.
4. Run rewrap job:
   - scan DEK-wrapped blobs,
   - unwrap with old CMK,
   - rewrap with new CMK,
   - write back atomically.
5. After rewrap completion and verification, remove old CMK from service allowlist (still retained in KMS if policy requires).
6. Mark old CMK `RETIRED`; destroy only per policy.

Hard rule:
- Rewrap jobs MUST be resumable and crash-safe; partial completion must not brick the datastore.

### 5.6 mTLS identity rotation (procedure)
1. Issue new certificate for service identity (automated CA).
2. Deploy new cert alongside old (hot reload if supported).
3. Ensure peer trust bundles include both old and new CA roots/intermediates during the window.
4. Remove old cert after window; revoke if required.

## 6. Emergency rotation (suspected compromise)
Emergency procedures prioritize containment and integrity, even at the cost of availability.

### 6.1 Incident severity mapping
- **SEV-0:** KTL signing key compromise or equivocation suspected.
- **SEV-1:** Auth token signing key compromise or token minting suspected.
- **SEV-2:** DB encryption key compromise or unauthorized decrypt suspected.
- **SEV-2:** Service identity compromise (mTLS key) or credential leak.
- **SEV-3:** Non-critical secret exposure (application secret used for rate limit salt, etc.)

### 6.2 Emergency steps (common)
For any suspected compromise:
1. Declare incident; restrict access; freeze deployments.
2. Rotate affected credentials immediately (generate new key versions).
3. Revoke/disable compromised keys in KMS/HSM (mark `RETIRED` and disable usage).
4. Invalidate dependent artifacts:
   - Auth: revoke refresh tokens, reduce access token TTL, force re-auth.
   - KTL: publish incident statement; block authenticated mode if necessary.
5. Audit: preserve logs and audit trails; produce evidence bundle per P3-18.
6. Post-incident: root cause and hardening actions.

### 6.3 Emergency: Auth token signing key compromise (SEV-1)
Immediate actions:
- Generate new signing key.
- Push verifier allowlist updates to RSF/PDS/KTL.
- Switch signing to new key.
- Revoke refresh tokens and reduce access token TTL temporarily (e.g., to 5 minutes) until confidence restored.
- Increase auth anomaly monitoring (P3-26) and tighten rate limits (P3-27).

Client impact:
- Clients may need to re-authenticate; do not allow fallback to unauthenticated modes for protected endpoints.

### 6.4 Emergency: KTL signing key compromise (SEV-0)
KTL compromise is catastrophic for authenticated transparency.

Immediate actions:
- Stop issuing new STHs until containment.
- Rotate KTL signing keys in HSM/KMS.
- Publish a signed incident statement through the trusted distribution channel used for pinning key updates.
- Require clients to update pinned keys; until updated, authenticated mode should fail closed.
- Consider freezing bundle acceptance that depends on KT until the transition completes.

If equivocation is suspected:
- Preserve all STHs, proofs, and append logs for forensics.
- Coordinate with independent monitors (if deployed).

### 6.5 Emergency: DB encryption key compromise (SEV-2)
Actions:
- Rotate master CMK immediately.
- Rewrap DEKs (or re-encrypt) as required.
- Assess whether plaintext exposure occurred; if yes, treat as data breach with privacy response.

Note: DB encryption protects at-rest data; it does not replace access controls. Compromise may indicate broader system compromise.

### 6.6 Emergency: mTLS identity compromise (SEV-2)
Actions:
- Revoke the compromised cert.
- Issue new cert and rotate trust bundles.
- Rotate any secondary credentials used by the service (API keys, etc.).
- Review access logs and lateral movement potential.

## 7. Operational checklists
### 7.1 Pre-rotation checklist (planned)
- Confirm change window and rollback plan.
- Confirm key inventory and current states.
- Confirm verifier distribution channel health.
- Confirm monitoring dashboards/alerts in place (P3-26).
- Confirm rate limits for rollout safety (P3-27).
- Verify that services can accept both old and new keys.

### 7.2 Post-rotation checklist (planned)
- Validate new signatures verify across services.
- Validate old tokens remain valid for overlap window only.
- Validate decrypt works for all existing DB records.
- Validate no increase in auth failures or 5xx.
- Record audit event and attach evidence.

### 7.3 Evidence bundle contents (recommended)
Packaged per P3-18:
- sanitized audit log extracts (create/activate/deprecate events),
- configuration change records (public keys, kids),
- a signed change approval record (ticket id),
- SLO impact report and anomalies.

## 8. Conformance requirements (Phase 3)
A deployment is conformant to P3-28 if it can demonstrate:
1. All required keys exist and are scoped to environments.
2. KTL and Auth signing keys are non-exportable (or equivalently protected) in production.
3. Rotation overlap is implemented and documented.
4. Emergency rotation playbooks exist and have been exercised at least once in staging.
5. Telemetry redlines are enforced (no secrets/identifiers in logs/metrics).

## 9. Parameter registry hooks (alignment with P3-12)
Deployments SHOULD expose configuration keys:
- `auth.token_ttl_seconds`
- `auth.refresh_ttl_seconds`
- `auth.key_overlap_seconds`
- `kt.key_overlap_days`
- `db.cmk_rotation_days`
- `mtls.cert_rotation_days`
- `kms.keyring_uri` (per service, per env)

## 10. Security notes (non-normative)
- Prefer HSM-backed signing for KTL to reduce theft risk.
- Keep token TTLs short to limit blast radius.
- Treat “key management” as part of the cryptosystem; operational weakness can defeat strong protocol design.

---
**End of document.**
