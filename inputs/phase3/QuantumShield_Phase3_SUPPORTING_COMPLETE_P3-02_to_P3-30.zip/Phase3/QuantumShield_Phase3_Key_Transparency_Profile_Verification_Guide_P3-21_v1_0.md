# QuantumShield Phase 3 — Key Transparency Profile & Verification Guide
**Artifact ID:** P3-21  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (alignment only):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Related Phase 3 artifacts (non-required):** P3-06 (PDS Contract), P3-09 (RSF Contract), P3-12 (Parameter Registry), P3-13 (OpenAPI), P3-14 (Shared Schemas), P3-16 (CI Harness), P3-17 (Storage Schema), P3-20 (AuthN/AuthZ)  
**Version:** 1.0  
**Date:** 2025-12-20  
**Timezone:** America/Chicago  

## 0. Purpose and scope
This document defines the **Key Transparency (KT) profile** used by QuantumShield Phase 3 deployments and provides a complete, interoperable **verification guide** for clients and services.

It is intended to remove ambiguity and ensure consistent behavior across:
- client SDKs (verification, pinning, rollback detection),
- PDS (bundles carrying STH and proofs),
- KTL (proof construction, STH production).

This artifact is **supporting** and **atomic**: it includes all required formats, algorithms, and policy hooks. It does not modify QSP/QSE wire formats; it restates and operationalizes the KT requirements embedded in QSP 4.3.2.

## 1. Normative conventions
### 1.1 Integers and byte order
All integer fields defined in this document are **unsigned** and encoded **big-endian**.

### 1.2 varbytes<u16>
`varbytes<u16>` is encoded as:
- `u16 len || len bytes`

Receivers MUST reject:
- truncated encodings,
- lengths that exceed remaining bytes,
- trailing bytes beyond the canonical encoding for the object contained in the varbytes.

### 1.3 Hash and signature primitives
This KT profile uses QSP’s primitives:

- `H(m) = SHA-512(m)` (64 bytes)
- Ed25519 signatures are 64 bytes.
- ML-DSA-65 signatures are 3309 bytes.

**KT hash width:** KT Merkle hashes are 32 bytes. Define:
- `H32(m) = Trunc32(SHA-512(m))` where `Trunc32(x)` is the first 32 bytes.

This is required for interoperability because STH root hashes and proof node hashes are fixed at 32 bytes.

### 1.4 Domain separation labels
This profile uses the exact ASCII labels below:

- `"QSP4.3/KT/STH"`
- `"QSP4.3/KT/LEAFDATA"`
- `"QSP4.3/KT/LEAF"`
- `"QSP4.3/KT/NODE"`

Implementations MUST use these labels exactly (case-sensitive) and MUST NOT apply Unicode normalization.

## 2. KT objects (wire format)
### 2.1 Signed Tree Head (STH)
STH is serialized as:

`STH = log_id(32) || tree_size(u64) || root_hash(32) || timestamp(u64) || sig_ec(64) || sig_pq(3309)`

Where:
- `log_id` is a 32-byte log identifier (pinned by clients).
- `tree_size` is the number of leaves in the tree.
- `root_hash` is the Merkle root hash (32 bytes).
- `timestamp` is log operator time, in **Unix seconds** (u64).
- `sig_ec` is an Ed25519 signature.
- `sig_pq` is an ML-DSA-65 signature.

#### 2.1.1 STH signature transcript
Define:

`STH_TBS = H("QSP4.3/KT/STH" || log_id || tree_size || root_hash || timestamp)`

Signatures are computed over the 64-byte `STH_TBS` digest:
- `sig_ec = Ed25519.Sign(log_sig_ec_priv, STH_TBS)`
- `sig_pq = MLDSA.Sign(log_sig_pq_priv, STH_TBS)`

Verification:
- `Ed25519.Verify(log_sig_ec_pub, STH_TBS, sig_ec) == true`
- `MLDSA.Verify(log_sig_pq_pub, STH_TBS, sig_pq) == true`

**Pinned log signing keys:** Clients MUST pin the KT log’s signing public keys out-of-band (or via a higher trust root) and MUST NOT accept unsigned or unpinned log keys.

### 2.2 InclusionProof (canonical encoding inside varbytes<u16>)
`kt_inclusion_proof` (varbytes<u16>) MUST contain exactly:

`u16 count || (count * node_hash32) || u64 leaf_index`

Where:
- `count` is the number of sibling hashes (path length).
- Each `node_hash32` is 32 bytes.
- `leaf_index` is the 0-based index of the leaf proven to be included.

Constraints:
- `count` MUST be <= 64.
- The varbytes payload length MUST equal `2 + (count * 32) + 8`.
- Verifiers MUST reject any trailing bytes.

### 2.3 ConsistencyProof (canonical encoding inside varbytes<u16>)
`kt_consistency_proof` (varbytes<u16>) MUST contain exactly:

`u16 count || (count * node_hash32)`

Constraints:
- `count` MUST be <= 64.
- The varbytes payload length MUST equal `2 + (count * 32)`.
- Verifiers MUST reject any trailing bytes.

Empty consistency proofs (`count=0`) are permitted **only** when policy allows (see §7.3).

## 3. Leaf binding and leaf_data
### 3.1 PrekeyBundle fields relevant to KT
A PrekeyBundle includes (at minimum) these fields which are bound into the KT leaf:
- `user_id` (varbytes<u16>) — the **canonical varbytes encoding**, not just the raw bytes.
- `device_id` (u32)
- `valid_from` (u32, Unix seconds)
- `valid_to` (u32, Unix seconds)
- `BundleTBS` (64 bytes) — defined by QSP as `H("QSP4.3/BUNDLE" || ...)`

### 3.2 leaf_data canonical encoding
Define:

`leaf_data = "QSP4.3/KT/LEAFDATA" || user_id_varbytes || device_id(u32) || BundleTBS(64) || valid_from(u32) || valid_to(u32)`

Notes:
- `user_id_varbytes` is exactly the `u16 len || len bytes` encoding from the bundle.
- All integers are big-endian.
- `BundleTBS` is the 64-byte SHA-512 digest.

### 3.3 LeafHash and NodeHash
Define:
- `LeafHash = H32("QSP4.3/KT/LEAF" || leaf_data)`
- `NodeHash = H32("QSP4.3/KT/NODE" || left || right)`

Where `left` and `right` are 32-byte child hashes.

## 4. Merkle tree model
### 4.1 Tree definition (Merkle Tree Hash / CT-style)
The log maintains an append-only sequence of leaves `[0..tree_size-1]`, each leaf being `LeafHash(leaf_data)`.

The Merkle root is computed over these 32-byte leaf hashes using a deterministic **Merkle Tree Hash (MTH)** algorithm in the style of Certificate Transparency (RFC6962), but using the `LeafHash` and `NodeHash` functions defined in §3.3.

Define a fixed empty-tree root:
- `EmptyRoot = H32("QSP4.3/KT/NODE")`  (i.e., the label bytes alone)

Define `MTH(leaves[])` recursively:
- If `n = 0`: `MTH([]) = EmptyRoot`
- If `n = 1`: `MTH([h0]) = h0`
- If `n > 1`:
  - Let `k` be the largest power of two such that `k < n`.
  - `MTH(leaves[0..k-1] || leaves[k..n-1]) = NodeHash(MTH(leaves[0..k-1]), MTH(leaves[k..n-1]))`

This definition uniquely determines how odd-sized subtrees are handled and is compatible with standard inclusion/consistency proof constructions.

KTL implementations MUST use this exact MTH definition; clients MUST verify roots accordingly.

### 4.2 Maximum depth
For all realistic deployments, depth is <= 64, consistent with `count <= 64`.

## 5. Inclusion proof verification (client)
Inputs:
- `STH` with `(tree_size, root_hash)`
- `leaf_data` (constructed per §3)
- `InclusionProof` with `(count, siblings[], leaf_index)`

Algorithm (normative):
1. Reject if `leaf_index >= tree_size`.
2. Set `h = LeafHash(leaf_data)`.
3. Set `idx = leaf_index`.
4. For each sibling hash `s` in order:
   - If `idx` is even: `h = NodeHash(h, s)`
   - Else: `h = NodeHash(s, h)`
   - Set `idx = idx // 2`
5. After consuming all siblings, the computed `h` MUST equal `root_hash`. Otherwise reject.

Canonical constraints:
- Proof decoding must enforce exact lengths (see §2.2).
- Verifiers MUST reject proofs where `count` is insufficient to reach the root for the given `tree_size` if the computed root does not match.

## 6. Consistency proof verification (client)
Consistency proofs justify that a newer STH extends an older STH without rewriting history.

Inputs:
- pinned old STH: `(old_size, old_root)`
- new STH: `(new_size, new_root)`
- `ConsistencyProof` list `proof[]` (32-byte hashes)

Normative rules:
- If `new_size < old_size`: reject (rollback).
- If `new_size == old_size`: accept only if `new_root == old_root` and proof may be empty.
- If `old_size == 0`: accept (first contact) and proof may be empty.

For `0 < old_size < new_size`, verification uses the standard “RFC6962-style” algorithm, adapted to this profile’s `NodeHash`:

Pseudocode (normative):
```
fn verify_consistency(old_size, old_root, new_size, new_root, proof[]):
    if old_size == 0: return true
    if old_size == new_size: return (old_root == new_root)

    # Find the largest power-of-two k such that k is the largest subtree aligned with old_size.
    # Standard approach: walk bits of (old_size - 1) and (new_size - 1).
    # This algorithm is deterministic and widely implemented for CT logs.

    if proof.len == 0: return false

    # Step A: Initialize.
    let fn = None
    let sn = None
    let os = old_size - 1
    let ns = new_size - 1

    # While os is odd, shift right (skip identical right edges).
    while (os & 1) == 1:
        os >>= 1
        ns >>= 1

    fn = proof[0]
    sn = proof[0]
    let i = 1

    # Step B: Consume proof nodes.
    while os != 0:
        if (os & 1) == 1:
            fn = NodeHash(proof[i], fn)
            sn = NodeHash(proof[i], sn)
            i += 1
        else:
            sn = NodeHash(sn, proof[i])
            i += 1
        os >>= 1
        ns >>= 1
        while os != 0 and (os & 1) == 0:
            os >>= 1
            ns >>= 1

    # Step C: Fold remaining proof nodes into sn only.
    while i < proof.len:
        sn = NodeHash(sn, proof[i])
        i += 1

    return (fn == old_root) and (sn == new_root)
```

Constraints:
- `proof.len` MUST be <= 64.
- Decoding MUST be canonical (see §2.3).
- Implementations MUST constant-time compare hashes where feasible.

This algorithm matches standard CT verification patterns. KTL implementations SHOULD also publish known-answer tests in the vector set (see §9).

## 7. Client pinning and freshness policy
### 7.1 Pinned state
Clients implementing Authenticated mode MUST maintain per log_id:
- `pinned_tree_size` (u64)
- `pinned_root_hash` (32 bytes)
- `pinned_timestamp` (u64)
- `pinned_log_sig_keys` (public keys, pinned out-of-band)

Pinned state MUST be committed atomically with session/bundle acceptance (see P3-07 / P3-17 principles).

### 7.2 Update rule (Authenticated mode)
When a new bundle includes `kt_sth`, `kt_inclusion_proof`, `kt_consistency_proof`, the client MUST:
1. Verify both bundle signatures and validity window.
2. Verify STH signatures (both).
3. Verify inclusion proof for `leaf_data`.
4. If a pinned STH exists for log_id and this is not first contact:
   - Verify consistency proof from pinned to new STH.
5. If all checks pass, update pinned state to the new STH.

If any check fails, the bundle MUST NOT be used for an authenticated session.

### 7.3 Empty consistency proofs
Empty consistency proofs (`count=0`) MUST be accepted only in these cases:
- pinned state does not exist (first contact), OR
- `old_size == 0`, OR
- `old_size == new_size` and `old_root == new_root`.

In all other cases, an empty consistency proof MUST be rejected.

### 7.4 Timestamp policy
Clients MUST reject STHs with timestamps that move backwards beyond tolerance:
- `new_timestamp + kt.max_past_skew_seconds < pinned_timestamp` → reject.

Clients SHOULD also reject STHs too far in the future (deployment policy):
- `new_timestamp > now + kt.max_future_skew_seconds` → reject.

Recommended defaults:
- `kt.max_past_skew_seconds = 600`
- `kt.max_future_skew_seconds = 600`

## 8. Service responsibilities
### 8.1 KTL (log) requirements
KTL MUST:
- publish STHs with monotonic `tree_size`,
- ensure STH signatures use the pinned signing keys,
- serve inclusion proofs where `leaf_index` exists under `tree_size`,
- serve consistency proofs for `(old_size, new_size)` pairs.

KTL MUST bound work:
- reject requests with `tree_size` exceeding current,
- reject proof requests with invalid ranges,
- cap proof size (`count <= 64`) and fail closed.

### 8.2 PDS requirements
PDS MUST treat KT objects as security-critical metadata:
- In Authenticated mode, PDS MUST attach `kt_log_id`, `kt_sth`, and proofs to bundles.
- PDS MUST ensure the bundle’s `leaf_data` (as defined here) corresponds to the served bundle fields.

PDS MAY obtain proofs from KTL and MUST verify basic sanity (canonical length checks) before returning to clients.

## 9. Interop and conformance tests (required)
Implementations MUST include these tests in CI (P3-16 alignment):

1. **Canonical encoding tests**
   - inclusion proof length matches `2 + 32*count + 8`
   - consistency proof length matches `2 + 32*count`
   - reject trailing bytes in KT varbytes

2. **Rollback tests**
   - `new_size < old_size` rejected
   - invalid consistency proof rejected
   - timestamp backwards beyond tolerance rejected

3. **Inclusion proof KAT**
   - known tree with fixed leaves; verify computed root == expected and proof validates

4. **Consistency proof KAT**
   - known pair of STH sizes (e.g., 8 -> 16) with proof validates

5. **Failure side-effects**
   - on KT verification failure, client state (pinned STH) MUST NOT advance

## 10. Security notes (non-normative)
- KT provides auditability and prevents undetected key substitution attacks, but does not eliminate the need for secure client pinning and fail-closed verification.
- Treat any consistency failure as a potential equivocation attempt; consider escalation paths (user warning, telemetry with privacy redlines, retry with another KTL replica).

---
**End of document.**
