# QuantumShield Phase 3 — Observability, SLOs & Telemetry Redlines
**Artifact ID:** P3-26  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (alignment only):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Related Phase 3 artifacts (alignment only):** P3-11 (Ops/Privacy Runbook), P3-12 (Parameters), P3-14 (Schemas/Reason Codes), P3-16 (CI Harness), P3-18 (Packaging), P3-20 (AuthN/AuthZ), P3-24 (Client Retry/Backoff)  
**Version:** 1.0  
**Date:** 2025-12-19  
**Timezone:** America/Chicago  

## 0. Purpose and scope
This document defines the **minimum required observability** for QuantumShield Phase 3 deployments, including:

- Service-level **SLOs** and error budgets for RSF, PDS, and KTL
- Client-side reliability signals (privacy-preserving)
- A strict **telemetry redlines policy** that prevents secret/identifier leakage
- Standard metric/log/trace/event schemas and naming conventions
- Dashboards and alerting requirements sufficient for production operations

This is a **supporting, atomic** artifact. It does not modify QSP/QSE. It is intended to be directly implementable in common telemetry stacks (Prometheus/OpenTelemetry/ELK/Splunk/etc.).

## 1. Non-negotiable privacy and security rules (telemetry redlines)
### 1.1 MUST NOT record
Services and clients MUST NOT record (in logs, metrics labels, traces, or events):

- Raw `route_token` bytes (or base64url representations)
- Raw QSE envelopes, QSP ciphertexts, or plaintext
- Access tokens, refresh tokens, authorization headers, cookies
- Private keys, derived keys, shared secrets, ratchet state, message keys
- Full KT proofs, raw STH root hashes, leaf_data bytes (unless explicitly configured for a quarantined lab environment)

### 1.2 MUST NOT label
Metrics MUST NOT include as labels/dimensions:

- `user_handle`, `device_id`, `inbox_id`, `msg_handle`
- per-connection IDs, per-request payload hashes, IP addresses
- anything that uniquely identifies a user/device/queue at high cardinality

### 1.3 Allowed identifier representations (strict)
Where an identifier is operationally needed for correlation or abuse response, use **privacy-preserving surrogates**:

- **Salted hash** (rotating salt): `H32("telemetry" || salt || identifier)`
- Salt rotation: at most **24 hours** (recommended 1 hour for high-sensitivity environments)
- The salted hash MUST be used only in **security/audit events** (not metrics labels), and MUST NOT be emitted by default in client telemetry.

### 1.4 Payload size and latency buckets
Allowed aggregations:

- Size buckets: `<1KB`, `<4KB`, `<16KB`, `<64KB`, `<256KB`, `>=256KB`
- Latency buckets: standard histogram buckets (ms to tens of seconds)
- Status class buckets: `2xx`, `4xx`, `5xx`
- Reason codes: from P3-14 registry (low cardinality)

### 1.5 Retention and access control
- **Service logs** retention SHOULD be short (e.g., 7–14 days).
- **Security/audit logs** retention MAY be longer (e.g., 30–90 days) but must remain sanitized.
- Access to logs/traces MUST be least-privilege and audited.

## 2. Telemetry taxonomy and minimal outputs
### 2.1 Telemetry types
Implementations SHOULD support these channels:

1. **Metrics** (low-cardinality counters, histograms, gauges)
2. **Structured logs** (sanitized, request-scoped)
3. **Traces** (OpenTelemetry or equivalent; sanitized attributes)
4. **Security/audit events** (sanitized but higher fidelity; limited access)

### 2.2 Correlation identifiers
- Generate a `request_id` per inbound request.
- Propagate `request_id` through internal services.
- `request_id` MAY appear in logs and traces.
- `request_id` MUST NOT be derived from user identifiers or message content.

## 3. Standard naming conventions
### 3.1 Service prefixes
Use the following prefixes in metric names:

- `qshield_rsf_*` for RSF
- `qshield_pds_*` for PDS
- `qshield_ktl_*` for KTL
- `qshield_client_*` for client SDK/app telemetry (if emitted)

### 3.2 Common label set (approved)
All service metrics SHOULD use only these labels unless explicitly approved by security review:

- `env` (dev/staging/prod)
- `region` (e.g., us-east-1)
- `service` (rsf/pds/ktl)
- `endpoint` (stable low-cardinality route name, not full URL)
- `method` (GET/POST/PUT)
- `status_class` (2xx/4xx/5xx)
- `reason` (P3-14 reason code string; or `none`)
- `build` (commit or build id; low cardinality)

Forbidden labels include anything user-specific or unbounded-cardinality.

## 4. RSF observability requirements
### 4.1 Metrics (minimum)
**Request volume and outcomes**
- `qshield_rsf_requests_total{endpoint,method,status_class,reason,env,region,build}` (counter)
- `qshield_rsf_request_latency_seconds{endpoint,method,status_class,env,region,build}` (histogram)

**Queue health**
- `qshield_rsf_inbox_visible_items{env,region,build}` (gauge) — total visible/unacked items aggregated across inboxes
- `qshield_rsf_inbox_visible_bytes{env,region,build}` (gauge)
- `qshield_rsf_message_expirations_total{env,region,build}` (counter)
- `qshield_rsf_lease_conflicts_total{env,region,build}` (counter) — lease contention counts (if leasing used)

**Rotation**
- `qshield_rsf_route_token_rotations_total{status_class,reason,env,region,build}` (counter)
- `qshield_rsf_route_token_overlap_active{env,region,build}` (gauge) — count of active overlap bindings

**DoS protection**
- `qshield_rsf_reject_bounds_total{reason,env,region,build}` (counter) — oversize/noncanonical rejects
- `qshield_rsf_rate_limited_total{endpoint,env,region,build}` (counter)

### 4.2 RSF structured logs (minimum)
Logs MUST be structured (JSON) and include:

- `ts` (timestamp)
- `service=rsf`
- `request_id`
- `endpoint` / `method`
- `status` (HTTP)
- `reason` (P3-14)
- `latency_ms`
- `payload_size_bucket` (approved buckets)
- `auth_principal_type` (user/device/service/operator)
- `auth_result` (success/denied)

Logs MUST NOT include route_token, msg_handle, or envelope bytes.

### 4.3 SLOs (RSF)
SLOs are defined over **authorized** requests (exclude 401/403 from availability, but include them in security monitoring).

- **Availability (RSF API):** 99.95% successful responses for `enqueue`, `fetch`, `ack` over 30 days.
  - Success: 2xx and expected 4xx outcomes that are client-caused (e.g., `invalid_request`) are not counted as service errors.
  - Service errors: 5xx and 429 due to internal overload count against availability.

- **Latency:**
  - `enqueue`: p99 < 500 ms
  - `fetch` (non-long-poll): p99 < 500 ms
  - `ack`: p99 < 300 ms

- **Freshness / delivery promptness (operational SLI):**
  - `fetch` returns queued items within p99 < 2 seconds under normal load (excluding long-poll).

### 4.4 Alerts (RSF)
Required alerts (example thresholds; tune per deployment):

- `RSF_5XX_RATE_HIGH`: 5xx > 0.1% for 10 minutes
- `RSF_RATE_LIMIT_SPIKE`: 429 > 1% for 10 minutes
- `RSF_QUEUE_GROWTH`: visible_items increasing monotonically for 30 minutes AND expirations increasing
- `RSF_ROTATION_ERRORS`: rotation conflict/forbidden spikes above baseline

## 5. PDS observability requirements
### 5.1 Metrics (minimum)
**Requests and latency**
- `qshield_pds_requests_total{endpoint,method,status_class,reason,env,region,build}` (counter)
- `qshield_pds_request_latency_seconds{endpoint,method,status_class,env,region,build}` (histogram)

**OPK pool health (aggregated)**
- `qshield_pds_opk_available{pool,env,region,build}` (gauge) where `pool ∈ {dh,pq}` aggregated across devices
- `qshield_pds_opk_consumed_total{pool,env,region,build}` (counter)
- `qshield_pds_opk_unavailable_total{env,region,build}` (counter) — `opk_unavailable` events

**Bundle publication**
- `qshield_pds_bundle_publish_total{status_class,reason,env,region,build}` (counter)
- `qshield_pds_bundle_active_revisions{env,region,build}` (gauge) — total active bundles (aggregate)

**Idempotency**
- `qshield_pds_idempotency_hits_total{op_type,env,region,build}` (counter)

**Abuse controls**
- `qshield_pds_rate_limited_total{endpoint,env,region,build}` (counter)
- `qshield_pds_enumeration_suspect_total{env,region,build}` (counter) — coarse heuristic signal

### 5.2 PDS structured logs (minimum)
Include fields analogous to RSF, plus:

- `op_type` (publish_bundle, get_bundles, upload_opk_dh, upload_opk_pq, revoke)
- `idempotency_used` (true/false)
- `opk_policy` (none/preferred/required) when applicable (NOT tied to user identifiers)

Must not log OPK bytes, bundle bytes, or user identifiers.

### 5.3 SLOs (PDS)
- **Availability:** 99.90% for `get_bundles` and 99.95% for device-owner writes (`publish`, `upload`, `revoke`) over 30 days.
- **Latency:**
  - `get_bundles`: p99 < 800 ms
  - `publish_bundle`: p99 < 700 ms
  - OPK uploads: p99 < 700 ms

- **OPK depletion SLI:** percentage of `get_bundles` requests resulting in `opk_unavailable` (for required policy) should be < 0.1% under steady-state.

### 5.4 Alerts (PDS)
- `PDS_5XX_RATE_HIGH`: 5xx > 0.2% for 10 minutes
- `PDS_OPK_DEPLETION`: `opk_available` drops below low-watermark for 15 minutes
- `PDS_ENUMERATION_SPIKE`: enumeration_suspect_total spikes over baseline

## 6. KTL observability requirements
KTL is security-sensitive; monitoring must focus on integrity signals and availability.

### 6.1 Metrics (minimum)
- `qshield_ktl_requests_total{endpoint,method,status_class,reason,env,region,build}` (counter)
- `qshield_ktl_request_latency_seconds{endpoint,method,status_class,env,region,build}` (histogram)

**Tree growth**
- `qshield_ktl_tree_size{env,region,build}` (gauge)
- `qshield_ktl_sth_publish_total{env,region,build}` (counter)

**Proof workload**
- `qshield_ktl_proof_requests_total{proof_type,env,region,build}` (counter) where `proof_type ∈ {inclusion,consistency}`
- `qshield_ktl_proof_cache_hit_total{proof_type,env,region,build}` (counter) (if caching)

**Integrity signals**
KTL should NOT emit per-user signals. However, it SHOULD emit operator-side integrity events:
- `qshield_ktl_sth_monotonicity_violations_total{env,region,build}` (counter) — should be zero

### 6.2 SLOs (KTL)
- **Availability (read endpoints):** 99.90% over 30 days.
- **Latency:** p99 < 1.0 s for inclusion proofs; p99 < 1.5 s for consistency proofs (cache on).
- **STH publish cadence SLI:** STH publish at least every configured cadence (e.g., ≤ 60s). Alert on missed cadence.

### 6.3 Alerts (KTL)
- `KTL_STH_STALL`: tree_size not increasing for > 30 minutes while append expected
- `KTL_STH_MONOTONICITY`: any monotonicity violation event (page immediately)
- `KTL_5XX_RATE_HIGH`: 5xx > 0.2% for 10 minutes

## 7. Client telemetry (privacy-preserving)
Client telemetry is optional but recommended for reliability in production. If enabled:

### 7.1 Approved client metrics/events
Clients MAY record local counters and upload aggregated telemetry only if it satisfies §1.

Recommended client event fields:
- `client_platform` (ios/android/desktop)
- `client_build` (low cardinality)
- `op` (rsf_enqueue/rsf_fetch/pds_get_bundles/kt_verify)
- `outcome` (success/fail)
- `reason` (P3-14 where applicable, else `local_error` class)
- `latency_bucket`
- `retry_attempts_bucket` (0,1,2-3,4-5,>5)

Clients MUST NOT upload raw timing sequences that can reveal interaction patterns at high fidelity unless explicitly approved.

### 7.2 Client security signals
Clients SHOULD treat these as security-relevant and report in a privacy-preserving way:
- repeated `kt_rollback_detected`
- repeated `invalid_signature` for KT STH
- repeated QSE noncanonical envelopes received from RSF

Such signals MUST be rate-limited and aggregated.

## 8. Tracing requirements (sanitized)
If tracing is enabled:

- Traces MUST propagate `request_id`.
- Trace attributes MUST obey label redlines (§1.2).
- Do not attach request/response bodies.
- Sampling MUST be conservative for sensitive endpoints.

Recommended sampling:
- Baseline: 0.1% for normal traffic
- Increase to 1% temporarily during incident response (time-bounded), still sanitized

## 9. Standard dashboards (minimum)
### 9.1 RSF dashboard
- Request rate by endpoint and status_class
- Latency p50/p95/p99 by endpoint
- Rate limit rate and 5xx rate
- Queue visible items/bytes and expirations
- Rotations success vs conflict

### 9.2 PDS dashboard
- Request rate and latency by endpoint
- OPK available gauge (dh/pq) vs low-watermark
- OPK consumed rate
- get_bundles availability and `opk_unavailable` rate
- Publish/upload success rates

### 9.3 KTL dashboard
- Request rate and latency
- Tree size and growth rate
- STH publish cadence
- Proof request volumes and cache hits
- Integrity violation counters

## 10. Mapping to reason codes and client behavior
Telemetry should align with P3-14 reason codes and P3-24 behavior:

- `auth_failed` spikes indicate token lifecycle problems (P3-20)
- `rate_limited` indicates tuning needed (P3-27)
- `bounds_exceeded`/`noncanonical_*` spikes indicate client bugs or active probing
- KT failures (`kt_invalid`, `kt_rollback_detected`) are security-critical and should page on sustained patterns

## 11. Conformance and tests
A CI harness (P3-16) SHOULD enforce:

- lint rules preventing forbidden fields in structured logs
- unit tests that metric label sets do not include forbidden identifiers
- synthetic traffic tests that route_token marker bytes never appear in logs
- sampling tests ensuring traces do not include payload bodies

## 12. Implementation checklist (minimum)
Deployments MUST implement:

- the minimal metric families defined in §§4–6
- structured logging with redlines enforced (§§1, 4.2, 5.2)
- SLO evaluation rules with a published dashboard and alert policy
- retention and access controls for telemetry data

Deployments SHOULD implement:
- a “security events” pipeline with restricted access
- client telemetry with aggregation and strict sampling

---
**End of document.**
