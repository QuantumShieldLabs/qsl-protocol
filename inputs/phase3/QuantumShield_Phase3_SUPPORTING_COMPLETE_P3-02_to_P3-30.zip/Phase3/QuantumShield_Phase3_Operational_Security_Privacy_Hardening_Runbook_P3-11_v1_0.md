# QuantumShield Phase 3 — Operational Security & Privacy Hardening Runbook
**Artifact ID:** P3-11  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (alignment only):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Version:** 1.0  
**Date:** 2025-12-20  
**Timezone:** America/Chicago

## 0. Purpose and scope
This runbook defines operational security and privacy controls for Phase 3 deployments of QuantumShield. It applies to RSF (relay/store-and-forward), PDS (prekey directory), KTL (key transparency log), the control-plane identity layer (AuthN/AuthZ), and client applications/SDKs.

The runbook covers configuration baselines, key management, access control, retention, logging redlines, abuse controls, monitoring, and incident response. It does not change QSP/QSE; cryptographic correctness and wire format rules remain solely defined by the canonical specifications.

## 1. Security and privacy objectives
### 1.1 End-to-end confidentiality and integrity
- QSP ciphertext confidentiality and integrity MUST be preserved end-to-end. RSF MUST treat QSE payload bytes as opaque and MUST NOT parse or decrypt QSP.
- Clients MUST fail closed on any AEAD/tag failure, parsing failure, or verification failure.

### 1.2 Metadata minimization
- RSF MUST avoid stable identifiers in routing. `route_token` is opaque and MUST be rotated.
- Service logs MUST avoid raw identifiers and MUST use salted hashes and coarse buckets.
- Service APIs MUST avoid precise counts/timestamps that increase linkability unless strictly required.

### 1.3 Authenticity (bundle signing and Key Transparency)
- Clients MUST verify bundle signatures.
- In deployments that claim Authenticated mode, clients MUST verify KT STHs and proofs and MUST resist rollback by pinning prior state.

### 1.4 Availability under abuse
- RSF/PDS/KTL MUST enforce bounds, request-size limits, rate limits, and queue caps.
- Abuse mitigation MUST not degrade cryptographic security (no silent downgrades).

## 2. Component inventory and trust boundaries
### 2.1 Components
- **RSF:** accepts, stores, and forwards QSE envelopes; cannot decrypt QSP.
- **PDS:** publishes and serves device bundles and OPKs; enforces OPK serve-at-most-once semantics.
- **KTL:** append-only transparency log; serves STHs and proofs.
- **AuthN/AuthZ:** issues access tokens or identities and enforces authorization policies.
- **Observability/Audit:** collects sanitized metrics and events.

### 2.2 Trust boundaries
- RSF is assumed honest-but-curious: it can see QSE metadata (route_token length, envelope length, coarse timestamps) but must not gain plaintext.
- PDS and KTL are verifiable by clients through signatures and KT proofs; compromise must be detectable.
- Clients are the primary trust anchor; long-term secrets remain client-side.

## 3. Baseline configuration (recommended defaults)
All maxima MUST be configured to remain within canonical limits (QSE/QSP). Exact canonical maxima are defined by the specs; this runbook provides operational defaults.

### 3.1 RSF defaults
- Envelope TTL: 7 days
- Fetch default: 20 items or 256 KiB, whichever first
- Long-poll wait: up to 60 seconds
- Visibility lease (optional): 30–120 seconds
- Per-inbox caps: 10,000 items and/or 50 MiB (bucketed enforcement; tune by cost)
- Dedupe hint window (non-security): 10 minutes using `H(envelope_bytes)`
- route_token rotation overlap: 24 hours

### 3.2 PDS defaults
- OPK pool low-water alert: < 50 available keys (per device per pool)
- OPK upload cap per device: 10,000 (per pool)
- Bundle validity window policy: 30–180 days typical (deployment-defined)
- Idempotency window: 24 hours for publish/upload endpoints

### 3.3 KTL defaults
- STH publish cadence: 1–10 minutes typical
- Proof serving SLO: 99% < 1 second (regional)
- Immutable storage: append-only log with periodic signed checkpoints

### 3.4 Logging and retention defaults
- Service logs retention: 14–30 days (short by default)
- Security/audit logs retention: 90–180 days (strictly sanitized)
- Metrics retention: 30–90 days (aggregated)

## 4. Key management and secrets handling
### 4.1 Secret classes
- **KTL signing key:** signs STHs; highest sensitivity.
- **PDS signing key (if used):** signs bundle attestations or service receipts if deployment adds them.
- **Auth token signing keys:** sign bearer tokens or session credentials.
- **Database encryption keys:** encrypt RSF queues and service databases at rest.
- **Salts for hashing identifiers:** used to hash route_tokens/user handles in logs.
- **Service-to-service credentials:** mTLS keys, API keys.

### 4.2 Storage requirements
- Production signing keys SHOULD be in an HSM/KMS and never exported.
- Database encryption keys SHOULD be in KMS with envelope encryption (DEK wrapped by KEK).
- Hash salts MUST be stored as secrets (KMS/secret manager) and rotated with care.
- Secrets MUST NOT be committed to source control or embedded in client apps.

### 4.3 Rotation policy
- KTL signing key: planned rotation 6–12 months; emergency rotation immediately on compromise.
- Auth token signing keys: 90 days typical; keep overlapping old keys for token validation for a bounded window.
- DB encryption KEKs: 6–12 months; rotate DEKs as part of re-encryption or rolling migration.
- Hash salts: 90–180 days; preserve old salt for log correlation only if strictly necessary.

### 4.4 Emergency rotation playbook (minimum)
When a critical key is suspected compromised:
1. Declare incident, freeze deployments, and restrict administrative access.
2. Rotate the key in KMS/HSM.
3. Publish new verification material to clients (for KTL, update pinned trust anchors via out-of-band secure channel).
4. Invalidate/expire old credentials promptly.
5. Backfill monitoring to detect continued misuse.
6. Document timeline and postmortem.

## 5. Identity, access control, and change management
### 5.1 Least privilege
- Each service MUST run under a dedicated service identity.
- RBAC MUST separate: operators, deployers, security administrators, and auditors.
- Direct database access MUST be restricted to break-glass procedures.

### 5.2 Token scope and authorization
- RSF fetch/ack authorization MUST NOT rely on secrecy of route_token alone.
- PDS publish endpoints must require authenticated device/account identity.
- KTL append must be admin-only or service-identity-only.

### 5.3 Administrative controls
- Require MFA for all privileged access.
- Use short-lived credentials and just-in-time access.
- All configuration changes MUST be reviewed (two-person rule) for: rate limits, bounds, retention, and key material.

## 6. Data at rest, retention, and deletion
### 6.1 RSF stored envelopes
- RSF stores QSE envelopes (ciphertext). Treat as sensitive because metadata can still be valuable.
- Encrypt RSF storage at rest (disk encryption minimum; application-level encryption preferred for high-risk deployments).
- Enforce TTL deletion by server time. TTL should be independent of client-provided timestamps.
- Backups of RSF queues SHOULD be avoided; if required, encrypt and keep very short retention.

### 6.2 PDS storage
- PDS stores public bundles, signatures, and public OPKs. Even though public, bulk access must be prevented.
- OPK consumption records MUST be durable and crash-safe to prevent re-serve after restart.
- Avoid storing unnecessary metadata (IP addresses, user agent strings) beyond short-lived abuse windows.

### 6.3 KTL storage
- KTL is append-only. Protect integrity with signed checkpoints and immutable storage controls.
- Maintain secure, offsite backups of the log and checkpoints.

### 6.4 Backup policy
- All backups MUST be encrypted.
- Backup restores MUST be tested quarterly.
- Backups MUST not introduce rollback vulnerabilities for pinned KT state; clients must resist rollback regardless.

## 7. Logging, telemetry, and audit redlines
### 7.1 Absolute logging prohibitions
Services and clients MUST NOT log:
- plaintext messages or decrypted QSP headers/bodies,
- private keys, seed material, root/chain/message/header keys,
- raw bearer tokens or session cookies,
- raw route_tokens or full QSE envelope bytes.

### 7.2 Allowed logging (sanitized)
Allowed data includes:
- request IDs, coarse timestamps, status codes,
- salted hashes of identifiers: `id_hash = H(id || salt)`,
- coarse buckets (queue depth bucket, size bucket, age bucket),
- reject reason codes (noncanonical, bounds_exceeded, rate_limited, kt_fail),
- performance metrics (latency percentiles, error rates).

### 7.3 Audit events
Audit events SHOULD be structured and minimal. Example event fields:
- `event_type`, `component`, `severity`, `time_bucket`, `request_id`, `id_hash`, `outcome`, `reason_code`.

## 8. Network and runtime hardening
### 8.1 TLS and service mesh
- All external endpoints MUST use TLS with modern ciphers and HSTS.
- Internal service-to-service traffic SHOULD use mTLS.
- Disable insecure protocol versions and weak ciphers.

### 8.2 Edge protections
- Apply WAF rules and DDoS protection.
- Enforce request body size limits.
- Enforce header size limits.
- Prefer POST for payload-bearing endpoints.

### 8.3 Host and container hardening
- Run as non-root, drop Linux capabilities.
- Use read-only root filesystem where feasible.
- Apply seccomp/AppArmor profiles.
- Patch OS and dependencies on a defined schedule.

## 9. Abuse controls and privacy-preserving enforcement
### 9.1 Rate limiting
Implement multi-dimensional rate limits:
- per authenticated principal,
- per inbox (route_token hash),
- per target user_handle (PDS) to prevent harassment enumeration,
- per IP range as a last resort (avoid long retention of IPs).

### 9.2 Queue caps and backpressure (RSF)
- Enforce per-inbox caps and return `queue_full` when exceeded.
- Use coarse buckets in status responses to avoid precise leakage.

### 9.3 Enumeration resistance (PDS)
- Require authentication for bundle fetch.
- Avoid differentiating errors that reveal whether a user exists to unauthorized callers.

### 9.4 route_token rotation
- Require rotation support with overlap window (see RSF contract).
- Encourage client rotation cadence of at least daily; high-risk deployments rotate more frequently.

## 10. Incident response playbooks
### 10.1 Suspected RSF compromise or queue exfiltration
Indicators:
- unusual administrative access, data export anomalies, sudden increase in queue reads.
Actions:
1. Contain: revoke RSF administrative credentials, restrict network paths.
2. Rotate: RSF database encryption keys (if used) and log hash salts.
3. Force route_token rotation for all inboxes (server-driven prompt).
4. Monitor for replay floods and abuse.
5. Communicate risk accurately: ciphertext remains protected; metadata exposure depends on logs and route_tokens.

### 10.2 OPK re-serve bug or PDS atomicity failure
Indicators:
- duplicated OPK IDs observed by clients, or audit inconsistency.
Actions:
1. Freeze OPK serving or switch to “no OPK” mode temporarily (policy).
2. Patch PDS to enforce atomic consume.
3. Audit affected window and notify security review.
4. Add regression tests and crash-injection tests.

### 10.3 KTL signing key compromise
Indicators:
- unexpected STH signatures, mismatch with pinned key.
Actions:
1. Stop STH publishing and isolate KTL.
2. Rotate KTL signing key in HSM/KMS.
3. Publish new trust anchor to clients via secure update channel.
4. Require clients to re-establish pins based on new anchor (policy-defined).
5. Perform full forensic review.

### 10.4 Auth token signing key compromise
Actions:
1. Rotate signing keys.
2. Invalidate all tokens (reduce TTL and require re-auth).
3. Review logs for abuse; increase rate limiting.

### 10.5 KT inconsistency detected by clients
Indicators:
- spikes in client `kt_fail` reason codes.
Actions:
1. Treat as high severity; it may indicate log equivocation or operational fault.
2. Validate KTL checkpoint chain and consistency proofs.
3. If log integrity is uncertain, pause Authenticated-mode session establishment and require a safe operational fallback policy (deployment-defined).

### 10.6 Supply chain vulnerability in crypto dependency
Actions:
1. Identify affected builds via SBOM.
2. Patch and rebuild with verified sources.
3. Rotate any impacted service keys if exposure is plausible.
4. Trigger client update with clear version constraints.

## 11. Monitoring and alerting (minimum)
### 11.1 RSF metrics
- enqueue rate, fetch rate, ack rate
- queue depth bucket distributions
- TTL expirations
- bounds_exceeded and noncanonical_qse reject rates
- p95/p99 latency for enqueue/fetch

Alert recommendations:
- sustained `noncanonical_qse` spikes (possible active probing)
- sustained `queue_full` events (abuse or capacity)
- anomalous growth in queue depth buckets

### 11.2 PDS metrics
- bundle publish success/failure rates
- OPK pool levels and depletion rates
- OPK consume failures and transaction conflicts
- fetch rates per user bucket

### 11.3 KTL metrics
- STH publish cadence and monotonic growth
- proof serving latency
- signature verification failure rates (from clients)

### 11.4 Client signals (sanitized)
- decrypt failures by reason code bucket
- KT verification failures
- crash-safety test assertions (in pre-release channels)

## 12. Release engineering and supply-chain controls
- Generate and store SBOMs for all services and clients.
- Pin dependencies; require review for crypto library upgrades.
- Use reproducible builds where feasible.
- Sign release artifacts; verify signatures in deployment pipeline.
- Run SAST, dependency scanning, and secrets scanning on every CI run.
- Run fuzzing against parsers (QSE and QSP canonical parsing) and maintain a corpus of negative tests.

## 13. Component hardening checklists
### 13.1 RSF checklist
- [ ] Canonical QSE parsing and strict bounds enforcement
- [ ] No QSP parsing/decryption in RSF code paths
- [ ] Rate limits, queue caps, request size limits
- [ ] route_token rotation with overlap and authorization
- [ ] Logs: salted hashes and buckets only
- [ ] Short retention; TTL enforcement; minimal backups

### 13.2 PDS checklist
- [ ] Auth required for publish and fetch
- [ ] OPK serve-at-most-once is atomic and crash-safe
- [ ] Idempotency keys on publish/upload
- [ ] Bundle and KT materials served as canonical bytes
- [ ] Enumeration resistance and rate limiting

### 13.3 KTL checklist
- [ ] Append-only storage with signed checkpoints
- [ ] Signing key in HSM/KMS
- [ ] Proof endpoints rate limited
- [ ] Operational monitoring for equivocation signals

### 13.4 Client checklist
- [ ] Transactional receive: copy-then-commit persistence
- [ ] Fail-closed on all parse/verify/decrypt failures
- [ ] KT pinned state stored with rollback resistance best-effort
- [ ] Secure storage for long-term keys (OS keystore)
- [ ] No sensitive logging

### 13.5 Observability checklist
- [ ] Sanitized event schema and reason codes
- [ ] Short retention for detailed logs
- [ ] Access controls for log and metric systems

## Appendix A — Standard reason codes (suggested)
- `noncanonical_qse`
- `bounds_exceeded`
- `rate_limited`
- `queue_full`
- `auth_failed`
- `forbidden`
- `kt_fail`
- `bundle_sig_fail`
- `aead_fail`
- `replay`
- `policy_reject`

## Appendix B — Example sanitized log event (illustrative)
```json
{
  "time_bucket": "2025-12-20T01:00:00Z",
  "component": "rsf",
  "event_type": "ENQUEUE_REJECT",
  "severity": "warn",
  "request_id": "req_8f1c2d",
  "route_token_hash": "h_2f3a9c0b0d",
  "envelope_size_bucket": "1-2KB",
  "outcome": "reject",
  "reason_code": "noncanonical_qse"
}
```

---
**End of document.**
