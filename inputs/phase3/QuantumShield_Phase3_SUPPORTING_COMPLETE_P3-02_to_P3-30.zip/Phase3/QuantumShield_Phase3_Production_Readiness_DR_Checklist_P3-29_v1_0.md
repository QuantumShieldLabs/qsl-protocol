# QuantumShield Phase 3 — Production Readiness & Disaster Recovery Checklist
**Artifact ID:** P3-29  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (alignment only):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Related Phase 3 artifacts (alignment only):** P3-11 (Ops/Privacy), P3-17 (Storage), P3-20 (AuthN/AuthZ), P3-26 (Observability), P3-27 (Abuse Controls), P3-28 (Key Management), P3-30 (Release Acceptance)  
**Version:** 1.0  
**Date:** 2025-12-19  
**Timezone:** America/Chicago  

## 0. Purpose and scope
This document defines a **production readiness** and **disaster recovery (DR)** checklist for Phase 3 services and their dependencies:

- **RSF** (Relay/Store-and-Forward)
- **PDS** (Prekey Directory Service)
- **KTL** (Key Transparency Log)
- **Auth** (token issuer; may be external but MUST meet the controls below when used)
- Supporting infrastructure: databases, caches, queues, object storage, KMS/HSM, CI/CD, and observability stack

The checklist is designed to be used as:
- a pre-production gate,
- a release go/no-go checklist,
- a quarterly DR drill worksheet,
- evidence for Phase 3 release acceptance (P3-30).

This artifact is **supporting and atomic**. It does not modify QSP/QSE wire formats.

## 1. Definitions (normative)
### 1.1 RTO/RPO
- **RTO (Recovery Time Objective):** maximum tolerated downtime.
- **RPO (Recovery Point Objective):** maximum tolerated data loss window.

### 1.2 Availability and correctness
For Phase 3 services, “availability” is not sufficient: **correctness and safety invariants** (e.g., at-most-once OPK serving, crash-safe commits) are part of readiness.

### 1.3 Evidence bundle
An **evidence bundle** is a packaged set of sanitized artifacts (logs/metrics summaries, run outputs, approvals) with cryptographic digests suitable for audit.

## 2. Target readiness posture (recommended baseline)
Deployments SHOULD adopt (and document) minimum targets:

- **RTO:** 60 minutes (single-region) / 30 minutes (multi-region active-standby)
- **RPO:** 15 minutes for RSF/PDS/KTL state; 0–5 minutes for Auth state (token issuance) if internally hosted
- **Availability SLOs:** as in P3-26

If your posture differs, record the actual targets in §12 and ensure DR drills match.

## 3. Hard safety invariants (MUST)
Readiness is blocked unless all items below are demonstrably satisfied.

### 3.1 Canonical parsing and bounds
- Services MUST reject non-canonical encodings and bounds violations early.
- Maximum request sizes MUST be enforced at the edge and at the application layer.

### 3.2 Crash-safety and atomicity
- Any state transition that impacts security semantics MUST be atomic:
  - RSF: route_token registration/rotation mappings
  - PDS: OPK consume-at-most-once, bundle revision updates
  - KTL: append-only log growth and STH issuance

### 3.3 No leakage in telemetry
- Telemetry MUST satisfy the redlines in P3-26 (no secrets, no raw stable identifiers).

### 3.4 Key handling
- Key storage/rotation MUST satisfy P3-28 (environment isolation, non-exportable signing keys where required, audit trails).

### 3.5 AuthZ binding
- Service authorization MUST be based on principal identity and server-side bindings (never on possession of route_token bytes).

## 4. Pre-production gate checklist (all services)
Each item MUST be recorded as **PASS/FAIL** with an evidence reference.

### 4.1 Build and supply chain
- [ ] Reproducible builds enabled (build_id, SBOM generated).
- [ ] Dependency scanning performed; no critical vulnerabilities accepted without documented risk waiver.
- [ ] Container images signed and verified in deployment.
- [ ] Runtime configuration is immutable and versioned (GitOps or equivalent).

### 4.2 Environment isolation
- [ ] Separate accounts/projects/tenants for dev/staging/prod.
- [ ] Separate KMS/HSM keyrings per environment.
- [ ] Separate databases/buckets per environment; no shared credentials.

### 4.3 Access control and secrets
- [ ] Least-privilege IAM roles per service identity.
- [ ] No static long-lived credentials in code repos.
- [ ] Break-glass access defined with approvals and time-bounded elevation.
- [ ] Operator actions (rotate keys, revoke devices, KTL append) require dual control.

### 4.4 Network and edge posture
- [ ] TLS configuration hardened (modern ciphers, certificate rotation path).
- [ ] Request size limits enforced at edge for each endpoint group.
- [ ] WAF / DDoS protections configured for public endpoints (KTL reads if public).
- [ ] Rate limiting enabled per P3-27 with correct reason codes.

### 4.5 Observability
- [ ] Metrics, logs, and (optional) traces are enabled and validated against redlines.
- [ ] Dashboards exist for service overview + RSF/PDS/KTL-specific views.
- [ ] Alerting configured for SLO burn, 5xx spikes, auth anomalies, and correctness invariants.

### 4.6 Data management
- [ ] Encryption at rest enabled for all persistent stores.
- [ ] Backups configured and tested (see §7).
- [ ] Retention policies defined and implemented (logs, audit, stored envelopes, OPK metadata).

### 4.7 Release mechanics
- [ ] Rolling deploy strategy defined (canary/blue-green) with rollback.
- [ ] Schema migration plan defined (forward-only migrations preferred; rollback strategy documented).
- [ ] Feature flags used for risky changes; default fail-closed.

## 5. Service-specific readiness checklists
### 5.1 RSF readiness
#### Security and correctness
- [ ] Enqueue rejects non-canonical QSE envelopes and oversized bodies.
- [ ] Fetch/ack/rotate/register require correct scopes and enforce principal-to-inbox binding.
- [ ] Route token rotation supports overlap semantics; ambiguous outcomes handled safely.
- [ ] Queue operations are bounded (max per-inbox depth and max bytes).

#### Operational
- [ ] Queue storage is monitored (depth buckets, write latency).
- [ ] Poison-pill handling policy defined (how to handle malformed/un-decryptable messages without infinite retries).
- [ ] Cleanup/retention jobs exist for expired envelopes and stale inboxes.

### 5.2 PDS readiness
#### Security and correctness
- [ ] Bundle publish is idempotent and revisioned; canonical bytes preserved.
- [ ] OPK serving is **serve-at-most-once** with atomic consume; no re-serve after crash.
- [ ] Inventory endpoints expose coarse buckets only (no precise counts).
- [ ] Enumeration defenses present for get_bundles: error normalization + per-target rate limits.

#### Operational
- [ ] OPK pool monitoring: availability buckets, consumption rates, upload success rates.
- [ ] OPK depletion runbook exists (throttling, alerts, operator messaging).
- [ ] Storage growth projections validated (bundle revisions, OPK history, audit).

### 5.3 KTL readiness
#### Security and correctness
- [ ] Append path isolated (operator-only, mTLS, audited).
- [ ] STH signing uses pinned keys; key compromise playbook exists.
- [ ] Proof endpoints enforce strict caps (`count <= 64`) and reject invalid requests early.
- [ ] Tree growth is append-only; consistency proofs validate in monitor tooling.

#### Operational
- [ ] STH issuance cadence monitored; alerts on stalls.
- [ ] Proof latency and error rates monitored.
- [ ] Independent monitor (recommended) configured to detect equivocation or rollback.

### 5.4 Auth readiness (if self-hosted)
- [ ] Token signing keys rotate with overlap.
- [ ] Token TTLs are short; refresh tokens are revocable.
- [ ] Audience and environment claims enforced.
- [ ] Revocation procedures tested (device revoke, account lock, emergency rotation).

## 6. Capacity planning and load testing (MUST)
### 6.1 Capacity model
Maintain a written capacity model that includes:
- expected peak requests/sec per endpoint group,
- expected data growth per day (RSF envelopes, PDS bundle revisions, KTL leaves),
- worst-case retry amplification assumptions (per P3-24),
- per-region scaling thresholds.

### 6.2 Load tests
Before production, execute and record results for:
- [ ] RSF enqueue sustained at target peak with p99 latency within SLO.
- [ ] RSF fetch long-poll behavior at scale without connection exhaustion.
- [ ] PDS get_bundles at peak; OPK consumption pressure scenario.
- [ ] KTL proof endpoints under adversarial but capped requests.

### 6.3 Abuse simulations
- [ ] Rate-limit correctness (429 + `rate_limited`) validated.
- [ ] Enumeration attempts do not produce existence oracles.
- [ ] Malformed input fuzzing does not cause CPU/DB amplification.

## 7. Backup, restore, and DR (MUST)
### 7.1 Backup policy (minimum)
Backups MUST be automated and encrypted.

Recommended schedule:
- RSF DB: incremental every 15 min + daily full
- PDS DB: incremental every 15 min + daily full
- KTL DB/log store: incremental every 15 min + daily full
- Config/secrets metadata (not private keys): daily snapshot

Backups MUST be stored:
- in a separate account/project and region (if possible),
- with immutable retention (WORM) for a defined window.

### 7.2 Restore tests (non-negotiable)
At least monthly in staging (and quarterly for production parity), run:
- [ ] Full restore of RSF with integrity checks.
- [ ] Full restore of PDS with validation that OPK consume semantics remain correct.
- [ ] Full restore of KTL with verification that STH chain remains valid.

Restore tests MUST include “point-in-time” restores and confirm RPO assumptions.

### 7.3 DR modes
Choose and document one mode:

**Mode A: Single-region (manual failover)**
- Restore from backup into standby region.
- Expected RTO 60–180 minutes depending on data size.

**Mode B: Multi-region active-standby (recommended for production)**
- Standby region maintains near-real-time replicas.
- Automated or semi-automated failover.

**Mode C: Multi-region active-active (advanced)**
- Requires careful conflict handling; only acceptable if invariants can be maintained (especially PDS OPK consume-at-most-once).

### 7.4 Failover runbook requirements
A failover runbook MUST specify:
- who declares failover (roles),
- cutover steps (DNS, load balancers, config),
- how to verify correctness invariants post-cutover,
- rollback steps if failover is aborted.

### 7.5 Post-restore correctness validation
After any restore/failover, execute:
- RSF: enqueue/fetch/ack smoke tests; verify route_token binding integrity.
- PDS: publish bundle, upload OPKs, fetch bundles; verify OPKs are not re-served.
- KTL: fetch STH, verify signatures, request proofs; verify consistency from last pinned checkpoint.

## 8. Upgrades, migrations, and rollback (MUST)
### 8.1 Schema migrations
- [ ] Migrations are backward compatible during rollout (old and new services can run concurrently).
- [ ] Migrations are idempotent and resumable.
- [ ] Rollback strategy exists (prefer forward-fix rather than backward schema rollback).

### 8.2 Configuration changes
- [ ] Config changes are versioned and audited.
- [ ] Safe defaults are fail-closed.
- [ ] Feature flag rollback is documented.

### 8.3 Key rotations
- [ ] Planned rotations executed in staging using P3-28 procedures.
- [ ] Emergency rotation drill executed at least annually.

## 9. Incident response readiness (MUST)
### 9.1 Runbooks
Runbooks MUST exist for:
- DDoS / rate-limit escalation
- auth token signing compromise (SEV-1)
- KTL signing compromise / equivocation suspected (SEV-0)
- database breach suspected
- OPK depletion / serving anomalies
- elevated decrypt failures / KT failures

### 9.2 Tabletop and game days
- [ ] At least one tabletop per quarter covering one SEV-0/SEV-1 scenario.
- [ ] At least one game day per quarter covering DR restore/failover.

### 9.3 Communications
- [ ] Internal comms templates prepared (no identifiers).
- [ ] External customer comms plan prepared for major incidents.

## 10. Privacy and retention (MUST)
### 10.1 Data retention
Document and enforce retention for:
- RSF stored envelopes (time-to-live)
- PDS bundle revision history (bounded)
- OPK upload history (bounded)
- KTL append history (typically long-lived, but operator metadata bounded)
- Logs/metrics/traces/audit (per P3-26)

### 10.2 Deletion and revocation
- [ ] Device revocation process implemented and tested.
- [ ] User/account deletion policy documented (what can and cannot be deleted given transparency requirements and audit).

### 10.3 Access reviews
- [ ] Quarterly access review for SRE and SecOps roles.
- [ ] Secrets and keys access reviewed and minimized.

## 11. Go-live checklist (release day)
- [ ] All pre-prod gates PASS with evidence.
- [ ] Canary deployed; error rates and latency stable.
- [ ] Rate limiting active and correctly classifying responses.
- [ ] Backup jobs green; latest restore test within the last 30 days.
- [ ] On-call coverage and escalation paths confirmed.
- [ ] Rollback plan rehearsed (at least once in staging).
- [ ] Evidence bundle for release prepared and signed/hashed.

## 12. Deployment-specific worksheet
Fill these values for each environment:

- Environment: `prod|staging|dev`:
- Regions:
- DR Mode: `A|B|C`:
- RTO target:
- RPO target:
- Backup schedule:
- Restore test cadence:
- Key rotation cadence (Auth, DB, KTL):
- On-call roster and escalation:
- Evidence bundle storage location:

## 13. Conformance criteria (Phase 3)
A deployment is conformant to P3-29 if it can demonstrate:
1. Documented RTO/RPO targets and DR mode.
2. Automated backups and at least one successful restore test with recorded evidence.
3. Rate limiting and abuse controls active and tested.
4. Observability meets redlines and SLO alerting is configured.
5. Incident runbooks and at least one tabletop exercise recorded.

---
**End of document.**
