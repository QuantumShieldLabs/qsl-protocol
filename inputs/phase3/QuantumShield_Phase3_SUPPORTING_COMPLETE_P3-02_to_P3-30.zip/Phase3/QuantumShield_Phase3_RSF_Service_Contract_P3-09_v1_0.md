# QuantumShield Phase 3 — RSF (Relay / Store-and-Forward) Service Contract
**Artifact ID:** P3-09  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (alignment only):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Version:** 1.0  
**Date:** 2025-12-20  
**Timezone:** America/Chicago

## 0. Purpose and scope
This document specifies the **integration contract** for the QuantumShield **RSF** (Relay / Store-and-Forward) service under the Phase 3 baseline (service-edge relay + store-and-forward).

RSF responsibilities are strictly transport-layer:
- accept, validate, and queue **QSE envelopes**,
- deliver queued envelopes to authorized receivers,
- provide acknowledgements and replay/dedup *hints* (non-cryptographic),
- enforce DoS bounds and abuse controls,
- support privacy-preserving **route_token** rotation.

RSF MUST NOT:
- decrypt QSP payloads,
- parse or interpret QSP message contents,
- modify QSP ciphertext bytes,
- silently “repair” malformed envelopes.

This is a **supporting** artifact (atomic). It is designed to be implementable without requiring other Phase 3 artifacts to be read.

---

## 1. Terms
- **QSE envelope:** Canonical transport framing defined by QSE 1.8.2; RSF treats the payload portion as opaque bytes.
- **route_token:** Opaque routing handle carried in QSE, used to select the receiver queue/inbox.
- **inbox:** Server-side queue keyed by route_token (or internally by an inbox_id mapped from route_token).
- **publisher:** Sender client posting envelopes to RSF.
- **receiver:** Client fetching envelopes for a route_token it controls.
- **msg_handle:** RSF-generated opaque handle identifying an enqueued envelope instance for ACK purposes.
- **idempotency_key:** Caller-supplied key to safely retry enqueue without duplicate insertion (recommended).

---

## 2. Non-negotiable invariants
RSF MUST enforce the following invariants:

1. **Opaque payload:** RSF MUST NOT decrypt or interpret the payload bytes inside QSE. Payload is treated as an opaque octet string.
2. **Canonical parse / fail-closed:** RSF MUST parse QSE envelopes canonically and reject malformed or non-canonical encodings (including trailing bytes).
3. **Bounds enforcement:** RSF MUST enforce QSE size limits (envelope size, route_token length, payload length, padding length) and MUST reject out-of-bounds values.
4. **One-envelope atomicity:** RSF MUST store and forward envelopes as indivisible units. RSF MUST NOT split, concatenate, or transcode envelopes.
5. **Privacy discipline:** RSF MUST NOT require stable plaintext identifiers for routing. route_token MUST be treated as opaque, unstructured bytes.
6. **No security downgrades:** RSF failures or policy rejections MUST NOT trigger a weaker client behavior. Clients must fail closed at the cryptographic layer.

---

## 3. Service model and delivery semantics
### 3.1 Delivery guarantees
RSF provides **at-least-once** delivery:
- An accepted envelope may be delivered multiple times (e.g., retries, reconnects).
- RSF may reorder envelopes.
- RSF may drop envelopes due to TTL expiry, storage pressure, or abuse policies.

QSP provides cryptographic replay protection; RSF does not provide a cryptographic guarantee of replay prevention.

### 3.2 Ordering
RSF SHOULD preserve FIFO ordering **within a single inbox shard** as a best-effort property, but clients MUST NOT rely on ordering.

### 3.3 Queue retention and TTL
RSF MUST enforce a per-envelope TTL:
- Default TTL SHOULD be 7 days (deployment policy).
- TTL MUST be enforced without requiring client-supplied timestamps.

RSF SHOULD also enforce:
- per-inbox message count caps,
- per-inbox byte caps,
- global caps to protect service health.

### 3.4 Visibility and ACK
RSF supports a pull-based delivery model with explicit acknowledgements:
- receiver fetches a batch (possibly long-poll),
- RSF returns envelopes with `msg_handle`,
- receiver ACKs delivered messages using `msg_handle`.

RSF MAY implement a **visibility timeout** (lease) to avoid concurrent receivers duplicating work:
- if visibility timeout is enabled, fetched messages become invisible for `lease_seconds`,
- if not ACKed, they become visible again.

Clients MUST tolerate duplicates regardless of leasing.

---

## 4. Privacy and metadata minimization requirements
### 4.1 route_token handling
RSF MUST:
- treat route_token as an opaque byte string,
- avoid logging raw route_token values; if needed, log only `H(route_token || salt)` (salted hash),
- support route_token rotation (see §9).

RSF MUST NOT:
- require route_token to embed user_id/device_id/email/phone,
- attempt to parse route_token structure,
- expose route_token values to unauthorized parties (including via error messages).

### 4.2 Length leakage and padding
RSF MUST accept QSE envelopes whose padding is client-chosen (or edge-chosen) and MUST NOT strip or rewrite padding.

RSF MAY enforce minimum/maximum envelope sizes consistent with QSE bounds, but MUST NOT apply variable-sized transformations that increase distinguishability across clients.

### 4.3 timestamp_bucket handling
Deployment baseline:
- receivers SHOULD allow `timestamp_bucket=0` (policy-controlled),
- RSF MAY overwrite/set `timestamp_bucket` to an authoritative value when acting as a service-edge component.

If RSF overwrites timestamp_bucket:
- it MUST do so deterministically (based on server time),
- it MUST NOT derive bucket from client identity,
- it MUST NOT require client-supplied timestamps.

---

## 5. Transport, auth, and authorization
### 5.1 Transport security
All RSF endpoints MUST be served over HTTPS with modern TLS configurations.

### 5.2 Authentication
RSF MUST authenticate callers using one of:
- bearer tokens (recommended), or
- mTLS identities.

### 5.3 Authorization model
RSF MUST authorize:
- **enqueue**: publishers may submit envelopes, but policies SHOULD restrict bulk abuse (rate limits, proof-of-work, paid tiers, etc.). Enqueue authorization does not imply decrypt capability.
- **fetch/ack**: only the party authorized for an inbox may fetch/ack for that inbox.

A receiver proves authorization via:
- an access token scoped to the inbox (preferred), OR
- a token scoped to the account/device that owns the route_token mapping.

RSF MUST NOT rely on secrecy of route_token alone for authorization.

---

## 6. Common encoding conventions for RSF APIs
RSF APIs use JSON over HTTPS.

### 6.1 base64url
All binary values in JSON MUST be base64url (RFC 4648 URL-safe, **no padding**).
Fields containing base64url end with `_b64`.

### 6.2 Canonical envelope bytes
When an API field carries a QSE envelope, it is represented as:
- `qse_envelope_b64`: base64url of the canonical QSE envelope bytes.

RSF MUST validate canonical encoding per QSE 1.8.2 before accepting.

---

## 7. Error model (normative)
### 7.1 Error response body
On non-2xx responses, RSF MUST return JSON:

- `error_code`: string
- `message`: string (sanitized; MUST NOT include route_token or secrets)
- `retryable`: boolean
- `details`: optional object (sanitized)

### 7.2 Standard error codes
- `unauthorized` (401)
- `forbidden` (403)
- `not_found` (404)
- `invalid_request` (400)
- `noncanonical_qse` (400)
- `bounds_exceeded` (413 or 400)
- `rate_limited` (429)
- `queue_full` (503 or 409)
- `server_error` (500)

---

## 8. RSF API surface (v1)
All endpoints are under `/v1/rsf/`.

### 8.1 Enqueue envelope
`POST /v1/rsf/enqueue`

**Purpose:** Accept and queue a QSE envelope.

**Request (JSON):**
- `qse_envelope_b64` (required)
- `idempotency_key` (optional but strongly recommended; string 16–128 chars)
- `priority` (optional; `"normal"` default; deployments may support `"high"`)

**Response (JSON):**
- `accepted` (boolean)
- `msg_handle` (string, opaque; present if accepted)
- `queued_at` (coarse RFC3339 timestamp)
- `inbox_hint` (optional object; sanitized operational hints)
  - `approx_queue_depth_bucket` (e.g., `"0"`, `"1-10"`, `"11-100"`, `"100+"`)

**Semantics:**
- RSF parses QSE, extracts `route_token`, validates bounds, and enqueues the envelope.
- RSF MUST NOT modify the envelope bytes (except optionally overwriting timestamp_bucket when acting as a service-edge component; see §4.3).
- If `idempotency_key` is provided, RSF SHOULD provide exactly-once *insertion* for retries within an idempotency window (e.g., 24h), returning the same `msg_handle`.

**DoS controls (required):**
- RSF MUST enforce envelope size/bounds prior to enqueue.
- RSF MUST apply rate limits and reject with `rate_limited` when exceeded.

### 8.2 Fetch envelopes (pull)
`POST /v1/rsf/fetch`

**Purpose:** Retrieve queued envelopes for an authorized receiver.

**Request (JSON):**
- `route_token_b64` (required; base64url bytes; treated as opaque)
- `max_items` (optional; default 20; max 200)
- `max_bytes` (optional; default 256 KiB; max deployment-defined)
- `wait_seconds` (optional; default 0; max 60) — long-poll
- `visibility_timeout_seconds` (optional; default 0; max deployment-defined)
- `client_cursor` (optional; string; opaque pagination token)

**Response (JSON):**
- `items`: array of:
  - `msg_handle` (string)
  - `qse_envelope_b64` (string)
  - `queued_at` (coarse timestamp)
- `next_cursor` (optional; string)
- `lease_expires_at` (optional; timestamp; present if visibility timeout used)

**Semantics:**
- RSF authenticates and authorizes the caller for the inbox associated with `route_token_b64`.
- RSF returns up to `max_items` and `max_bytes`, whichever limit is reached first.
- If `wait_seconds>0` and the queue is empty, RSF holds the request until:
  - an item becomes available, or
  - wait_seconds elapses.

**Important:** Receivers MUST treat delivered envelopes as potentially duplicated.

### 8.3 ACK delivered envelopes
`POST /v1/rsf/ack`

**Purpose:** Remove envelopes from the queue once successfully processed.

**Request (JSON):**
- `route_token_b64` (required)
- `acks`: array of `msg_handle` strings (required; 1..500)

**Response (JSON):**
- `acked`: integer
- `not_found`: integer
- `errors`: optional array with per-handle error codes (sanitized)

**Semantics:**
- RSF MUST only accept ACKs from an authorized receiver for the inbox.
- ACK MUST be idempotent: ACKing an already-ACKed handle should be treated as success or counted in `not_found` without error escalation.

### 8.4 NACK / release lease (optional)
`POST /v1/rsf/nack`

**Purpose:** Release a visibility lease early (if leasing enabled).

**Request (JSON):**
- `route_token_b64`
- `msg_handles`: array of strings

**Response (JSON):**
- `released`: integer

If leasing is not enabled, RSF MAY respond with `invalid_request` or treat as no-op.

### 8.5 Inbox status (authorized; optional)
`POST /v1/rsf/status`

**Request (JSON):**
- `route_token_b64`

**Response (JSON):**
- `queue_depth_bucket` (string)
- `queue_bytes_bucket` (string)
- `oldest_item_age_bucket` (string)
- `policy` (object; optional)
  - `ttl_days` (integer; optional)
  - `max_items` (integer; optional)

This endpoint MUST NOT reveal precise counts to avoid metadata leakage.

---

## 9. route_token registration and rotation
Route token rotation is required to minimize metadata linkage over time.

### 9.1 Design goals
- Allow receivers to rotate route_token without message loss.
- Avoid revealing stable identifiers to RSF operators beyond what is necessary for authZ.
- Ensure senders can obtain current tokens via out-of-band mechanisms (e.g., PDS/bundles), without RSF being a directory.

### 9.2 Registration model
RSF MUST maintain a mapping:
- `route_token -> inbox_id`

route_token values are not stable identifiers; inbox_id is internal and never exposed.

### 9.3 Register / rotate token (authorized control-plane)
`POST /v1/rsf/route_tokens:rotate`

**Request (JSON):**
- `old_route_token_b64` (required)
- `new_route_token_b64` (required)
- `overlap_seconds` (optional; default 86400; max deployment-defined)
- `idempotency_key` (optional)

**Response (JSON):**
- `rotated` (boolean)
- `effective_at` (timestamp)
- `overlap_expires_at` (timestamp)

**Semantics:**
- Only an authorized receiver (owner of the inbox) may rotate.
- During overlap, RSF MUST accept fetch/ack on both old and new route_tokens for the same inbox.
- Enqueue behavior during overlap:
  - RSF MUST accept envelopes for both tokens and deliver them to the same inbox.
- After overlap expiry:
  - old token MUST be retired and SHOULD return `not_found` to fetch/ack, and `enqueue` SHOULD return `not_found` or `invalid_request` (deployment choice).

**Security requirements:**
- RSF MUST prevent token hijack: rotation requires authZ and cannot be authorized solely by presenting the old token bytes.
- RSF MUST ensure that `new_route_token_b64` is not currently bound to a different inbox.

### 9.4 Register initial token (optional)
If deployments support account provisioning:
`POST /v1/rsf/route_tokens:register`

**Request (JSON):**
- `route_token_b64`
- optional device/account proof (deployment-defined)
- `idempotency_key`

**Response (JSON):**
- `registered` (boolean)
- `effective_at` (timestamp)

---

## 10. QSE validation requirements (RSF-side)
RSF MUST validate the incoming envelope bytes as follows:

1. **Canonical decode:** parse QSE exactly; reject:
   - truncated envelopes,
   - length overrun/underrun,
   - duplicate or ambiguous encodings,
   - trailing bytes.
2. **Bounds checks:** enforce deployment maxima consistent with QSE:
   - `MAX_ENVELOPE_LEN`
   - `MAX_ROUTE_TOKEN_LEN`
   - `MAX_PAYLOAD_LEN`
   - `MAX_PAD_LEN`
3. **Smuggling resistance:** reject envelopes where declared lengths do not match actual byte counts.
4. **No heuristic recovery:** do not “salvage” partially valid envelopes.

If RSF overwrites timestamp_bucket (edge mode):
- it MUST perform the overwrite only after a successful canonical parse,
- it MUST re-encode the envelope canonically if reserialization is required by QSE rules,
- it MUST NOT modify any other fields.

---

## 11. Abuse controls (required)
RSF MUST implement:
- **rate limits** (per authenticated principal, and per route_token/inbox),
- **queue caps** (per inbox and global),
- **payload size enforcement** (before enqueue),
- **request size limits** for fetch/ack endpoints.

RSF SHOULD implement:
- **best-effort dedupe hint**: drop identical envelope bytes within a short window per inbox (e.g., keep `H(envelope_bytes)` for 10 minutes).
  - This is NOT a security property and MUST NOT be relied on.
- **greylisting** or staged penalties for repeated invalid envelopes.
- **adaptive throttling** based on global load.

Privacy requirement:
- Abuse controls MUST avoid storing stable cross-inbox identifiers beyond what is required for authN/authZ.

---

## 12. Observability and logging redlines
RSF MUST NOT log:
- raw route_token values,
- raw envelope bytes,
- raw client auth tokens,
- any derived secrets (RSF should have none).

RSF MAY log (recommended):
- request_id, response_code, coarse timestamps,
- salted hash of route_token (`H(route_token||salt)`),
- envelope size buckets,
- reject reason codes (`noncanonical_qse`, `bounds_exceeded`, `rate_limited`),
- queue depth buckets.

---

## 13. Conformance tests (minimum)
An RSF implementation is conformant to this contract if it passes:

### 13.1 QSE parsing and bounds
- Reject truncated envelope.
- Reject trailing bytes.
- Reject any envelope exceeding each configured bound.
- Reject length smuggling (declared lengths not matching actual bytes).

### 13.2 Opaque payload
- Ensure RSF does not parse/decrypt payload; validate via code review and runtime assertions (no dependency on QSP parsing).

### 13.3 Enqueue/fetch/ack semantics
- Enqueue returns msg_handle; fetch returns same envelope bytes; ack removes it.
- ACK idempotency verified.
- Duplicate enqueue with same idempotency_key returns same msg_handle (if idempotency supported).

### 13.4 Delivery properties
- At-least-once delivery under simulated failures (disconnect mid-fetch, retry).
- Optional leasing: unacked messages become visible after lease expiration.

### 13.5 route_token rotation
- Overlap window: fetch works on both tokens; enqueues to either deliver to same inbox.
- After overlap: old token retired.

### 13.6 Privacy redlines
- Verify logs contain only salted hashes and coarse buckets (no raw route_token, no raw envelope bytes).

---

## Appendix A — Recommended parameter defaults (deployment policy)
These are recommended defaults; deployments may tune based on risk and cost.

- `max_items_fetch`: 20 default, 200 max
- `max_bytes_fetch`: 256 KiB default
- `wait_seconds`: 0 default, 60 max
- `visibility_timeout_seconds`: 0 default (disabled), 30–120 if enabled
- `envelope_ttl_days`: 7 default
- `route_token_rotation_overlap_seconds`: 86400 (24h) default
- `rate_limits`: per principal and per inbox (deployment-specific)

---
**End of document.**
