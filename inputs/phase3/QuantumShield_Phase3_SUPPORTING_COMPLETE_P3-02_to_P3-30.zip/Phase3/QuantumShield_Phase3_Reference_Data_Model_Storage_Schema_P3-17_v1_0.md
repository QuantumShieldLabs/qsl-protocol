# QuantumShield Phase 3 — Reference Data Model & Storage Schema (RSF/PDS/KTL + Client State)
**Artifact ID:** P3-17  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (alignment only):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Related Phase 3 artifacts:** P3-06 (PDS Contract), P3-07 (Persistence/Crash-Safety), P3-09 (RSF Contract), P3-12 (Parameter Registry), P3-13 (OpenAPI), P3-14 (Shared Schemas)  
**Version:** 1.0  
**Date:** 2025-12-20  
**Timezone:** America/Chicago  

## 0. Purpose and scope
This document provides an implementation-neutral reference **data model** and **storage schema blueprint** for Phase 3 QuantumShield deployments, covering:

- **RSF** (Relay / Store-and-Forward): inboxes, queued envelopes, leasing, ACK, TTL expiry, route_token rotation overlap.
- **PDS** (Prekey Directory Service): users/devices, bundle revisions, OPK pools (DH/PQ) with atomic consume, idempotency, revocation.
- **KTL** (Key Transparency Log): append-only leaves, STH/checkpoints, proof cache, operator audit.
- **Client state**: QSP session persistence (copy-then-commit), MKSKIPPED/HKSKIPPED bounded caches, KT pinning state with rollback resistance markers.

This is a **supporting** artifact. It does not change QSP/QSE. Where numeric limits exist, deployments MUST respect canonical caps; this schema records operational defaults as tunables (see §2).

## 1. Design goals (non-negotiable)
1. **Crash-safety / atomicity:** All state transitions that matter to cryptographic correctness must be committed atomically (transaction or atomic pointer swap).
2. **Fail-closed semantics:** Non-canonical parsing, bounds violations, and verification failures must not partially update persistent state.
3. **Bounded storage and bounded work:** Tables and indexes must enforce bounded growth aligned to configured caps and canonical limits.
4. **Privacy discipline:** Avoid stable identifiers in transport services; treat route_token as opaque; avoid logging raw identifiers; prefer salted hashes and coarse buckets.
5. **Idempotency:** Network retries are normal. Enqueue, publish, and upload endpoints should be safely retryable using idempotency keys.
6. **Auditability without secrets:** Record enough evidence for operational debugging and abuse response without storing cryptographic secrets in service logs.

## 2. Parameterization (how sizes and TTLs map to config)
This schema uses parameter keys that SHOULD be sourced from P3-12 (Parameter Registry) or equivalent deployment config. The following keys are referenced in this document; values are deployment-defined but MUST remain within canonical caps:

- RSF: `rsf.envelope_ttl_seconds`, `rsf.visibility_timeout_seconds`, `rsf.inbox_max_items`, `rsf.inbox_max_bytes`, `rsf.dedupe_hint_window_seconds`, `rsf.route_token_rotation_overlap_seconds`
- QSE bounds: `qse.max_route_token_len`, `qse.max_payload_len`, `qse.max_pad_len`, `qse.max_envelope_len`
- PDS: `pds.idempotency_window_seconds`, `pds.opk_pool_cap_per_device`, `pds.opk_low_watermark`, `pds.bundle_validity_max_seconds`
- Client/QSP bounds: `qsp.max_skip`, `qsp.max_mkskipped`, `qsp.max_mkskipped_scan`, `qsp.max_header_attempts`, `qsp.max_hkskipped`, `qsp.mkskipped_ttl_seconds`, `qsp.hkskipped_ttl_seconds`
- Logging retention: `log.service_retention_seconds`, `log.security_retention_seconds`

## 3. Conventions
### 3.1 Identifier types
This blueprint uses the following abstract types; implementers may map to DB-native types:

- `bytes`: raw bytes; in JSON it is base64url; in DB it is `BYTEA`/`BLOB`.
- `hash32`: 32-byte hash.
- `ts`: timestamp with timezone (or epoch seconds).
- `u32`, `u64`: unsigned integers.
- `opaque_id`: random, unstructured identifier (ULID/UUIDv7/etc.).

### 3.2 Encryption at rest
- RSF queue storage and client session state SHOULD be encrypted at rest (DB encryption or filesystem protection).
- KTL signing keys and token signing keys MUST be stored in KMS/HSM (outside of DB). This schema does not store such keys.

### 3.3 Redlines
Services MUST NOT store or log:
- plaintext message content,
- QSP secrets (ratchet keys, message keys, header keys),
- raw route_token in logs (store only salted hashes in audit/metrics).

Storing raw route_token in DB is allowed where needed for routing, but should be minimized and protected (encryption at rest + strict access control).

## 4. RSF reference schema
RSF stores and forwards **canonical QSE envelopes**. RSF treats the payload as opaque and MUST NOT parse QSP.

### 4.1 Core entities
- **Inbox**: internal queue entity; route_tokens map to an inbox.
- **RouteTokenBinding**: maps route_token to inbox with overlap windows for rotation.
- **Message**: queued envelope item with TTL and optional lease metadata.
- **Idempotency**: de-duplicates enqueue retries (optional but recommended).

### 4.2 Tables (relational blueprint)
#### 4.2.1 `rsf_inbox`
Purpose: internal anchor for a receiver's queue.

Columns:
- `inbox_id` (opaque_id, PK)
- `created_at` (ts, not null)
- `status` (enum: `active`, `disabled`; not null default `active`)
- `policy_ttl_seconds` (u32, nullable; if null uses `rsf.envelope_ttl_seconds`)
- `max_items` (u32, nullable; if null uses `rsf.inbox_max_items`)
- `max_bytes` (u64, nullable; if null uses `rsf.inbox_max_bytes`)

Indexes:
- PK on `inbox_id`

Notes:
- `rsf_inbox` must not include user identifiers; authorization is enforced by the auth layer.

#### 4.2.2 `rsf_route_token_binding`
Purpose: bind one or more route_tokens to the same inbox, including rotation overlap.

Columns:
- `route_token` (bytes, PK) — length MUST be <= `qse.max_route_token_len`
- `inbox_id` (opaque_id, FK -> rsf_inbox.inbox_id, not null)
- `active_from` (ts, not null)
- `active_to` (ts, nullable) — null means active indefinitely
- `state` (enum: `active`, `retired`; not null)
- `created_at` (ts, not null)
- `retired_at` (ts, nullable)

Indexes:
- PK on `route_token`
- Index on `(inbox_id, state)`

Constraints:
- A given `route_token` MUST NOT bind to multiple inbox_ids.
- During rotation overlap, both old and new tokens exist with state `active` and overlapping `[active_from, active_to)` windows.

Operational rule (rotation):
- Rotation creates a new binding for `new_route_token` and sets `active_to` for the old token to `now + overlap_seconds`.
- After overlap expires, old token state becomes `retired` and fetch/ack should return `not_found`.

#### 4.2.3 `rsf_message`
Purpose: queue storage for canonical QSE envelopes.

Columns:
- `msg_id` (opaque_id, PK) — internal id (optional; may also be msg_handle)
- `inbox_id` (opaque_id, FK, not null)
- `msg_handle` (opaque_id, unique, not null) — returned to client; can equal msg_id
- `qse_envelope` (bytes, not null) — canonical envelope bytes
- `envelope_hash` (hash32, not null) — `H(qse_envelope)` (for best-effort dedupe hints)
- `envelope_len` (u32, not null)
- `queued_at` (ts, not null)
- `expires_at` (ts, not null) — queued_at + TTL
- `visible_at` (ts, not null default queued_at) — for leasing/visibility
- `lease_owner` (opaque_id, nullable) — opaque receiver instance id (optional)
- `lease_expires_at` (ts, nullable)
- `acked_at` (ts, nullable) — null means not acked
- `reject_after` (ts, nullable) — optional poison-pill delay after repeated failed fetch processing (rare; optional)

Indexes:
- Index on `(inbox_id, acked_at, visible_at)` for fetch scans
- Index on `(inbox_id, expires_at)` for TTL expiry worker
- Optional index on `(inbox_id, envelope_hash, queued_at)` for dedupe hint windows

Constraints:
- `envelope_len` MUST be <= `qse.max_envelope_len`.
- `qse_envelope` MUST be canonical and bounds-valid at enqueue time.
- When `acked_at` is non-null, the message is logically removed (may be physically deleted asynchronously).

#### 4.2.4 `rsf_idempotency`
Purpose: exactly-once *insertion* for enqueue retries within window.

Columns:
- `scope_principal` (bytes or string, not null) — derived from auth principal (not user-controlled)
- `idempotency_key` (string, not null)
- `created_at` (ts, not null)
- `expires_at` (ts, not null)
- `msg_handle` (opaque_id, nullable) — for enqueue, points to accepted message
- `status` (enum: `accepted`, `rejected`, `pending`; not null)
- `reject_reason` (enum/reason_code, nullable)

Indexes/constraints:
- Unique `(scope_principal, idempotency_key)`
- TTL expiry index on `expires_at`

Notes:
- Scope MUST include auth principal to prevent cross-tenant collisions.

### 4.3 RSF critical transactions
#### 4.3.1 Enqueue (atomic)
Inputs: authenticated principal, `qse_envelope` bytes, optional `idempotency_key`.

Transaction (recommended):
1. If `idempotency_key` present:
   - `SELECT` existing row by `(scope_principal, key)`. If present and `status=accepted`, return existing `msg_handle`.
2. Parse QSE canonically and enforce bounds. Extract `route_token`.
3. Resolve `route_token -> inbox_id` using `rsf_route_token_binding` where state is `active` and `active_from<=now<active_to(or null)`.
4. Enforce inbox caps:
   - compute current visible+unacked message count and bytes (approximate allowed) and reject with `queue_full` if exceeded.
5. Insert `rsf_message` row and compute `expires_at` and initial `visible_at=now`.
6. Record idempotency row as `accepted` with `msg_handle` (if used).
7. Commit.

Crash-safety:
- If crash before commit, nothing is enqueued (safe retry).
- If crash after commit, idempotency ensures retry returns same handle (best case).

#### 4.3.2 Fetch (with optional leasing)
Inputs: authorized receiver, route_token, `max_items`, `max_bytes`, optional `visibility_timeout_seconds`.

Transaction (single inbox scan, repeatable read):
1. Resolve route_token to inbox_id (active binding).
2. Select messages where:
   - `acked_at IS NULL`
   - `expires_at > now`
   - `visible_at <= now`
   Order by `queued_at ASC` (best-effort FIFO).
   Limit by `max_items`, and stop accumulating when `max_bytes` reached.
3. If leasing enabled (`visibility_timeout_seconds>0`):
   - Update selected rows:
     - `visible_at = now + visibility_timeout_seconds`
     - `lease_expires_at = now + visibility_timeout_seconds`
     - `lease_owner = receiver_instance_id`
4. Return `msg_handle` + `qse_envelope` bytes.

Notes:
- If leasing is disabled, skip step 3; duplicates may increase under concurrent receivers but clients must tolerate duplicates anyway.

#### 4.3.3 ACK (idempotent)
Inputs: authorized receiver, route_token, list of msg_handles.

Transaction:
1. Resolve route_token to inbox_id.
2. Update rows where `inbox_id=inbox_id AND msg_handle IN (...) AND acked_at IS NULL` set `acked_at=now`.
3. Return counts of updated vs not found.

#### 4.3.4 Rotation
Inputs: authorized owner, old_token, new_token, overlap_seconds.

Transaction:
1. Resolve old_token binding; ensure active.
2. Ensure new_token does not exist bound to a different inbox.
3. Insert new binding for new_token to same inbox with `active_from=now`, `active_to=NULL`, state `active`.
4. Update old binding: set `active_to=now+overlap_seconds`.
5. Commit.

Background:
- A periodic job retires old tokens past active_to by setting `state=retired, retired_at=now`.

### 4.4 TTL and garbage collection
- A background job deletes (or tombstones) rows where `expires_at <= now` or `acked_at IS NOT NULL AND acked_at < now - retention`.
- For privacy and cost, RSF SHOULD keep short retention for acked items (e.g., hours) and never store raw envelopes in logs.

## 5. PDS reference schema
PDS stores device bundles and serves them to initiators. OPKs must be served **at most once** with **atomic consume** semantics.

### 5.1 Core entities
- **User**: opaque handle; avoid embedding PII in DB keys.
- **Device**: scoped to user; carries current bundle pointer and status.
- **Bundle Revision**: immutable bundle records; active pointer per device.
- **OPK pools**: DH and PQ OPKs per device with atomic consume fields.
- **Idempotency**: de-duplicates publish and upload retries.
- **Audit**: sanitized operational events.

### 5.2 Tables
#### 5.2.1 `pds_user`
Columns:
- `user_handle` (string, PK) — opaque handle (not necessarily public identifier)
- `created_at` (ts, not null)
- `status` (enum: `active`, `disabled`; not null default `active`)

Notes:
- Consider using an internal `user_id` (opaque_id) if the handle can change; if so, keep `user_handle` unique and map to `user_id`.

#### 5.2.2 `pds_device`
Columns:
- `user_handle` (string, PK part, FK -> pds_user)
- `device_id` (u32, PK part)
- `created_at` (ts, not null)
- `status` (enum: `active`, `revoked`, `disabled`; not null)
- `active_bundle_rev` (u64, nullable) — current bundle revision pointer
- `revoked_at` (ts, nullable)
- `last_publish_at` (ts, nullable)

Indexes:
- PK `(user_handle, device_id)`
- Index `(user_handle, status)`

#### 5.2.3 `pds_bundle_revision`
Purpose: immutable bundle revision store (supports audit and rollback-safe clients).

Columns:
- `user_handle` (string, not null)
- `device_id` (u32, not null)
- `bundle_rev` (u64, not null) — monotonic per device
- `bundle_format` (string, not null)
- `bundle_fields` (bytes, not null) — canonical BundleTBS bytes
- `sig_ec` (bytes, not null)
- `sig_pq` (bytes, nullable) — null or empty allowed when not applicable
- `valid_from` (ts, not null)
- `valid_to` (ts, not null)
- `kt_log_id` (bytes, nullable) — base64url(32) in API; bytes here
- `created_at` (ts, not null)
- `status` (enum: `active`, `superseded`, `revoked`; not null)

Constraints:
- PK `(user_handle, device_id, bundle_rev)`
- Unique `(user_handle, device_id, status=active)` is optional; or use active pointer in `pds_device`.
- Enforce `valid_to - valid_from <= pds.bundle_validity_max_seconds`.

#### 5.2.4 `pds_opk_dh`
Columns:
- `user_handle` (string, not null)
- `device_id` (u32, not null)
- `opk_id` (u32, not null) — client-assigned, unique per device per pool
- `opk_pub` (bytes, not null) — DH public key bytes
- `state` (enum: `available`, `consumed`, `revoked`; not null)
- `created_at` (ts, not null)
- `consumed_at` (ts, nullable)
- `consumed_by_request_id` (opaque_id/string, nullable) — for audit/idempotency
- `revoked_at` (ts, nullable)

Constraints/Indexes:
- PK `(user_handle, device_id, opk_id)`
- Index `(user_handle, device_id, state)`
- Optional unique on `(user_handle, device_id, opk_pub_hash)` to reject duplicates.

#### 5.2.5 `pds_opk_pq`
Same as `pds_opk_dh` but stores PQ public key bytes.
Columns:
- `opk_pub` size is suite-defined; store as bytes.
- Other fields identical.

#### 5.2.6 `pds_idempotency`
Columns:
- `scope_principal` (bytes/string, not null) — derived from auth principal
- `idempotency_key` (string, not null)
- `created_at` (ts, not null)
- `expires_at` (ts, not null)
- `op_type` (enum: `put_bundle`, `revoke`, `upload_opk_dh`, `upload_opk_pq`, `get_bundles`; not null)
- `status` (enum: `accepted`, `rejected`, `pending`; not null)
- `result_ref` (bytes/string, nullable) — e.g., bundle_rev or summary
- `reject_reason` (reason_code, nullable)

Constraints:
- Unique `(scope_principal, idempotency_key)`
- Index on `expires_at`

#### 5.2.7 `pds_audit_event` (sanitized)
Columns:
- `event_id` (opaque_id, PK)
- `time_bucket` (ts, not null) — coarse bucket (e.g., hour)
- `event_type` (string, not null)
- `principal_hash` (hash32, nullable)
- `target_user_hash` (hash32, nullable)
- `target_device_id` (u32, nullable)
- `reason_code` (string, nullable)
- `details` (json, nullable; sanitized; no secrets)

### 5.3 PDS critical transactions
#### 5.3.1 Publish bundle (PUT bundle)
Transaction:
1. Verify authZ (outside DB); derive `scope_principal` for idempotency.
2. If idempotency_key present, check `pds_idempotency` and return prior result if accepted.
3. Load device row; ensure not revoked.
4. Compute next `bundle_rev = active_bundle_rev + 1` (or use sequence).
5. Insert immutable `pds_bundle_revision` with status `active`.
6. Update `pds_device.active_bundle_rev = bundle_rev` and set `last_publish_at=now`.
7. Mark previous revision `superseded` (optional; can be derived by pointer).
8. Record idempotency accepted (bundle_rev).
9. Commit.

#### 5.3.2 Consume OPK at-most-once (serve path)
This is the most security-sensitive PDS operation.

Goal: When embedding an OPK into a served PrekeyBundle, PDS MUST atomically select and consume a single OPK such that no OPK is served twice.

Transaction (recommended pattern):
1. Identify candidate OPK row: select one row where `state=available` for the pool (DH or PQ), using row-level lock:
   - `SELECT ... WHERE state='available' AND user_handle=? AND device_id=? ORDER BY opk_id ASC LIMIT 1 FOR UPDATE SKIP LOCKED`
2. If none available:
   - if opk_policy is `required`, return conflict (`opk_unavailable`).
   - if `preferred`, continue serving bundle without OPK (policy).
3. Update selected row: set `state='consumed', consumed_at=now, consumed_by_request_id=request_id`.
4. Commit.
5. Build response bundle including the selected OPK public key (if any).

Crash behavior:
- Crash before commit: OPK remains available; safe retry.
- Crash after commit but before response: OPK is consumed and MUST NOT be re-served; a retry returns a different OPK or none.

Idempotency (recommended):
- If the serve endpoint supports idempotency, it may return the same OPK for the same request_id if and only if the request_id is bound to the consumed row (consumed_by_request_id), and it has not been served to a different request.

#### 5.3.3 Revoke device
Transaction:
- set `pds_device.status='revoked', revoked_at=now`
- mark active bundle revision `revoked` (optional)
- optionally mark remaining OPKs as `revoked`
- record idempotency
- commit

### 5.4 OPK pool health and caps
- Enforce `pds.opk_pool_cap_per_device` as a hard cap on available+consumed rows retained (or available rows) per device per pool.
- When cap exceeded on upload:
  - reject excess items deterministically (do not delete consumed rows needed for audit unless policy allows).
- Trigger low-water alerts when available OPKs drop below `pds.opk_low_watermark`.

## 6. KTL reference schema
KTL is an append-only log; clients verify integrity via STH signatures and proofs. This schema is a blueprint for a Merkle-tree-backed transparency log with durable checkpoints.

### 6.1 Core entities
- **Leaf**: immutable appended record (canonical leaf_data bytes).
- **STH**: signed tree head checkpoints over tree_size and root_hash.
- **Proof cache**: optional derived artifacts for speed.
- **Operator audit**: sanitized events and append provenance.

### 6.2 Tables
#### 6.2.1 `ktl_leaf`
Columns:
- `log_id` (bytes(32), PK part)
- `leaf_index` (u64, PK part) — 0-based
- `leaf_hash` (hash32, not null) — `H(leaf_data)` or profile-defined
- `leaf_data` (bytes, not null) — canonical bytes per KT profile
- `created_at` (ts, not null)

Indexes:
- PK `(log_id, leaf_index)`
- Unique `(log_id, leaf_hash)` optional (depends on profile)
- Index `(log_id, created_at)`

#### 6.2.2 `ktl_sth`
Columns:
- `log_id` (bytes(32), PK part)
- `tree_size` (u64, PK part)
- `root_hash` (hash32, not null)
- `timestamp` (u64 or ts, not null) — as encoded in STH
- `sth_bytes` (bytes, not null) — canonical STH encoding
- `signature` (bytes, not null) — signature bytes if stored separately
- `created_at` (ts, not null)

Indexes:
- PK `(log_id, tree_size)`
- Index `(log_id, created_at)`
- Optional index on `tree_size DESC` for latest lookup

#### 6.2.3 `ktl_checkpoint`
Purpose: durable operator checkpoints to support recovery and equivocation defense.

Columns:
- `log_id` (bytes(32), PK part)
- `checkpoint_id` (opaque_id, PK part) — e.g., periodic (hourly/daily)
- `tree_size` (u64, not null)
- `root_hash` (hash32, not null)
- `checkpoint_bytes` (bytes, not null) — signed checkpoint bytes (operator-defined)
- `created_at` (ts, not null)

#### 6.2.4 `ktl_proof_cache` (optional)
Columns:
- `log_id` (bytes(32), not null)
- `cache_key` (hash32, not null) — hash of (type, params, tree_size)
- `proof_bytes` (bytes, not null) — canonical encoding
- `expires_at` (ts, not null)
- `created_at` (ts, not null)

Constraints:
- PK `(log_id, cache_key)`
- Index on `expires_at`

#### 6.2.5 `ktl_audit_event` (sanitized)
Similar to PDS audit; includes append requests, rate-limit events, etc.

### 6.3 KTL critical transactions
#### 6.3.1 Append leaf (operator path)
Append must be serialized per log_id to maintain Merkle consistency.

Transaction (single log_id lock):
1. Determine next `leaf_index = current_tree_size`.
2. Insert leaf row.
3. Update in-memory or stored Merkle frontier/state (implementation-specific).
4. Periodically (per cadence) produce and store new STH in `ktl_sth`.
5. Commit.

Notes:
- The Merkle frontier can be stored in a separate table or reconstructed; if stored, updates must be part of the same atomic transaction as leaf insertion and any derived nodes needed for proofs.

#### 6.3.2 Serve STH and proofs
- Latest STH: select max tree_size row.
- Inclusion proof: compute using stored nodes/frontier or on-demand; cache in `ktl_proof_cache` with bounded TTL.
- Consistency proof: compute between two sizes; cache similarly.

## 7. Client state reference schema (QSP + KT pinning)
Client persistence is security-critical. The model below is implementation-neutral and can be implemented via SQLite/LMDB/realm/etc. Transactionality is required (see P3-07 alignment).

### 7.1 Entities
- **Session**: per peer session ratchet state (secret-bearing, encrypted at rest).
- **MKSKIPPED**: bounded store of skipped message keys.
- **HKSKIPPED**: bounded store of skipped header keys with TTL.
- **Delivered markers (optional)**: idempotent delivery hints (hashes only, bounded TTL).
- **KT pins**: pinned STH state per log_id with anti-rollback markers.

### 7.2 Tables (logical)
#### 7.2.1 `c_session`
Columns:
- `session_id` (bytes(16), PK)
- `protocol_version` (u32, not null)
- `suite_id` (u32, not null)
- `role` (enum, not null)
- `state_epoch` (u64, not null) — increments per committed transition
- `state_blob` (bytes, not null) — encrypted serialized session state (ratchet keys, counters, etc.)
- `created_at` (ts, not null)
- `updated_at` (ts, not null)

Rules:
- All receive/send commits must update `state_epoch` and `state_blob` atomically with cache mutations.

#### 7.2.2 `c_mkskipped`
Columns:
- `session_id` (bytes(16), PK part)
- `msg_no` (u64, PK part)
- `mk_blob` (bytes, not null) — encrypted message key material
- `inserted_at` (ts, not null)
- `expires_at` (ts, not null) — now + `qsp.mkskipped_ttl_seconds`

Constraints:
- Entry count per session must be <= `qsp.max_mkskipped` (evict deterministically).

#### 7.2.3 `c_hkskipped`
Columns:
- `session_id` (bytes(16), PK part)
- `hk_id` (bytes, PK part) — implementation-defined identifier for header key epoch
- `hk_blob` (bytes, not null) — encrypted header key material
- `inserted_at` (ts, not null)
- `expires_at` (ts, not null) — now + `qsp.hkskipped_ttl_seconds`

Constraints:
- Entry count per session must be <= `qsp.max_hkskipped` (evict deterministically).
- Expired entries must be purged on startup and periodically.

#### 7.2.4 `c_delivered` (optional)
Columns:
- `session_id` (bytes(16), PK part)
- `ct_hash` (hash32, PK part) — hash of ciphertext (or envelope) for idempotent delivery
- `inserted_at` (ts, not null)
- `expires_at` (ts, not null)

Constraints:
- bounded TTL and bounded count per session; do not store plaintext identifiers.

#### 7.2.5 `c_kt_pin`
Columns:
- `log_id` (bytes(32), PK)
- `pinned_tree_size` (u64, not null)
- `pinned_root_hash` (hash32, not null)
- `pinned_timestamp` (u64 or ts, not null)
- `kt_epoch` (u64, not null) — monotonic local marker
- `pin_mac` (bytes, nullable) — MAC over fields using device-local secret (recommended)
- `updated_at` (ts, not null)

Rollback resistance:
- If using `pin_mac`, verify on load; refuse to use pins that fail verification.
- Enforce monotonicity: `kt_epoch` and/or `pinned_tree_size` must not decrease on update.

### 7.3 Client critical transactions
#### 7.3.1 ReceiveMessage commit unit (required)
Receive must operate on a copy of state and commit only on full success.

Transaction commit unit MUST include:
- updated `c_session.state_blob` and `state_epoch+1`
- MKSKIPPED/HKSKIPPED insertions and evictions
- optional `c_delivered` insertion
- any housekeeping purges required to maintain bounds

If any step fails, the transaction must roll back and the committed session state must remain unchanged.

#### 7.3.2 Send commit unit (recommended)
Sending that advances send chain state should be committed atomically with any persistent “outbox” markers (if used).

#### 7.3.3 Startup maintenance (required)
On startup:
- purge expired HK entries,
- purge expired MK entries,
- enforce entry caps deterministically,
- validate session invariants; quarantine sessions that fail invariants.

## 8. Privacy-preserving audit and metrics storage (services)
Services may store sanitized events in audit tables to support operations.

Rules:
- Store only coarse timestamps (bucketed).
- Store only salted hashes of identifiers.
- Do not store raw envelopes or route_tokens in audit tables.
- Keep retention short (prefer `log.service_retention_seconds` / `log.security_retention_seconds`).

## 9. Minimal index and partitioning guidance (non-normative)
- RSF `rsf_message` is typically the largest table. Consider time-based partitioning by `queued_at` or `expires_at` and drop partitions to enforce TTL efficiently.
- KTL `ktl_leaf` is append-only and grows unbounded; partition by `leaf_index` ranges or time and store immutable in object storage with verified manifests, while keeping a DB index for recent ranges.
- Proof caches must be bounded by TTL and size; use eviction by `expires_at`.

## 10. Conformance checkpoints (what to test)
This schema is “correct” only if the following are true in implementation:
- RSF enforces canonical QSE parsing and bounds prior to enqueue.
- RSF rotation overlap works without message loss and without authorization-by-token-bytes.
- PDS OPK selection is atomic and crash-safe and never re-serves a consumed OPK.
- Client receive path is copy-then-commit and crash-safe; negative cases do not advance state.
- All bounded caches remain bounded across restarts.
- Logging and audit remain sanitized and do not leak raw identifiers or secrets.

---
**End of document.**
