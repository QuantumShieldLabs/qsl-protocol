# QuantumShield Phase 3 — Reference Deployment Topology & Minimal Production Blueprint
**Artifact ID:** P3-15  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (alignment only):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Version:** 1.0  
**Date:** 2025-12-20  
**Timezone:** America/Chicago

## 0. Purpose and scope
This document provides a concrete, security-first **reference deployment topology** for a Phase 3 QuantumShield system:
- **RSF** (Relay / Store-and-Forward): transports QSE envelopes; payload treated as opaque.
- **PDS** (Prekey Directory Service): serves bundles and consumes OPKs at-most-once.
- **KTL** (Key Transparency Log): publishes STHs and proofs.
- **AuthN/AuthZ**: issues scoped credentials for service access.
- **Observability/Audit**: sanitized metrics and events consistent with logging redlines.

It is intended as a minimal blueprint that an engineering team can deploy with predictable security posture and operational behavior.
This document does not change QSP/QSE and does not require any other Phase 3 artifacts to be understood.

## 1. Deployment goals and constraints
### 1.1 Goals
- **End-to-end confidentiality/integrity:** QSP content remains opaque to services; services must not parse/decrypt payloads.
- **Metadata minimization:** minimize stable identifiers, enforce route_token rotation, and use coarse timestamps/buckets.
- **Crash-safety and integrity:** OPK consumption is atomic; service state is durable; KT publishing is append-only.
- **Abuse resistance:** enforce bounds, rate limits, and queue caps without protocol downgrades.
- **Operational clarity:** simple topology with strong separation of concerns.

### 1.2 Constraints
- Phase 2 and canonical specs are frozen.
- Canonical bounds and invariants are treated as hard caps (see QSE/QSP).

## 2. Reference topology (logical architecture)
### 2.1 Logical component diagram (textual)
Clients and services are arranged into three planes:

**(A) Edge plane (public ingress)**
- API Gateway / Ingress (WAF + TLS termination)
- RSF API (enqueue/fetch/ack/rotate) behind gateway
- PDS API (bundle fetch + publisher APIs) behind gateway
- KTL Read API (sth/proofs) behind gateway (optionally public-read)
- Rate limiting and request size enforcement at edge

**(B) Core service plane (private)**
- RSF workers (queue management, lease handling, TTL purge)
- PDS workers (OPK consume, bundle assembly, KT packaging option)
- KTL sequencer / signer (STH publication, append-only maintenance)
- Auth service (token issuance, introspection, JWK rotation)
- Policy service (optional; centralizes rate-limit tiers, abuse decisions)

**(C) Data plane (private, restricted)**
- RSF storage (queue DB + object store, encrypted at rest)
- PDS DB (bundles + OPK pools, transactional)
- KTL log storage (append-only) + proof indices
- KMS/HSM (signing keys, wrapping keys)
- Audit log sink (tamper-evident, sanitized)

### 2.2 Hard trust boundaries
- RSF MUST treat QSE payload as opaque bytes; ensure code ownership boundaries (separate repo/module) to prevent accidental QSP parsing.
- PDS MUST NOT hold endpoint private keys; only public bundles/OPKs. OPK issuance must be crash-safe.
- KTL signing key is the highest sensitivity key and SHOULD be HSM/KMS-protected with no raw export.

## 3. Environment profiles (dev / staging / prod)
This section describes minimal topology for each environment. All environments share the same logical model but differ in scale and controls.

### 3.1 dev (single-node or small cluster)
**Purpose:** local development and integration smoke tests.

- Single ingress (local reverse proxy)
- RSF + PDS + KTL deployed as separate services (containers) on one host or single small k8s cluster
- One database instance (separate schemas) is acceptable for convenience, but separation is preferred
- KTL signer key stored in dev KMS emulator or local key file (test-only)

**Minimum controls**
- TLS optional for purely local development; recommended for integration parity
- Rate limits relaxed but not disabled
- Logging still sanitized (no raw route_token; no raw envelopes)

### 3.2 staging (production-like)
**Purpose:** pre-release validation and conformance gates.

- Full ingress/WAF configuration matching prod
- Separate DB instances for RSF/PDS/KTL
- KTL signer key in real KMS/HSM (staging partition)
- Canary deploy capability and rollbacks tested

**Minimum controls**
- Strict request size limits and bounds enforcement
- Rate limiting close to prod
- Centralized log/audit with limited access

### 3.3 prod (minimal production blueprint)
**Purpose:** secure and scalable production deployment.

- Managed ingress (WAF + TLS + DDoS protection)
- Dedicated services for RSF, PDS, KTL, Auth
- Dedicated data stores with encryption at rest and strict IAM
- Regional deployment (at least 2 AZs per region); optional multi-region
- Centralized secrets management (KMS/HSM) and key rotation

**Minimum controls**
- Strong rate limits, queue caps, and abuse monitoring
- Strictly sanitized logs with short retention for service logs
- Incident playbooks and alerting enabled

## 4. Recommended network segmentation
### 4.1 Subnets and access
A common production segmentation:

- **Public subnet:** ingress load balancers / API gateway
- **Private app subnet:** RSF/PDS/KTL/Auth compute
- **Private data subnet:** DBs, object stores, caches, KMS access endpoints
- **Admin subnet (optional):** restricted jump host / bastion with MFA

**Rules**
- Only ingress is internet-reachable.
- Services may call data stores and KMS; data stores are not internet-exposed.
- Operator access to data subnet must be heavily restricted and audited.

### 4.2 Service-to-service identity
- Prefer mTLS between internal services (service mesh or native mTLS).
- If bearer tokens are used internally, they MUST be short-lived and audience-scoped.

## 5. Data stores and persistence choices
### 5.1 RSF storage (queue)
**Primary requirement:** durable store-and-forward with TTL.

Recommended patterns:
- **Option A (simplest):** Postgres with partitioned tables by time (for TTL purge), plus object store for large envelopes (optional).
- **Option B (high throughput):** dedicated queue (Kafka/Pulsar) + durable backing store for long TTL; careful with privacy in topic keys.
- **Option C (cloud-native):** managed queue with dead-letter + blob store; must preserve canonical envelope bytes.

Minimum requirements:
- Encryption at rest enabled.
- TTL enforcement at storage level (partitions or scheduled purges).
- Support for visibility leasing if enabled (lease token / updated visibility timestamp).

### 5.2 PDS store (bundles + OPKs)
**Primary requirement:** transactional atomic consume for OPKs.

Recommended:
- Postgres with row-level locking or transactional update patterns.
- Strict uniqueness constraints: (user_handle, device_id, opk_id) unique.
- OPK selection uses an atomic UPDATE ... WHERE state=available ... RETURNING pattern (DB-specific).

Minimum requirements:
- Crash-safe at-most-once issuance.
- Idempotency for publish/upload operations (window per policy).
- Backups and restores must not cause re-serve of consumed OPKs (see §10.3).

### 5.3 KTL store (append-only log)
**Primary requirement:** append-only integrity and verifiable publication.

Recommended:
- Append-only log segments in object storage plus a sequencer DB for indices.
- Periodic signed checkpoints and replicated storage across AZs.

Minimum requirements:
- KTL signer key in KMS/HSM.
- Consistency and inclusion proof generation with cached proofs (policy-defined).

## 6. Key management blueprint
### 6.1 Key classes
- KTL signing key (highest sensitivity)
- Auth token signing keys (high sensitivity)
- DB encryption keys / wrapping keys
- Identifier hashing salts (log redlines)
- mTLS CA and leaf certs (if used)

### 6.2 Recommended KMS/HSM policies
- No raw export for signing keys.
- Separate key rings/partitions per environment and per region.
- Strong IAM: only KTL signer service identity can use KTL signing key.
- Enable key usage audit logs and alerting on anomalous use.

### 6.3 Rotation and overlap
- Follow the rotation cadences in operational runbook (e.g., KTL 6–12 months, token keys 30–90 days, salts 90–180 days).
- Maintain explicit overlap windows and key-id pinning for client validation workflows.

## 7. AuthN/AuthZ reference model
### 7.1 Token model
- Bearer tokens are acceptable when:
  - short TTL (e.g., 30–60 minutes),
  - audience-scoped per service (rsf/pds/ktl),
  - least-privilege scopes.

Recommended scopes:
- `rsf:enqueue`, `rsf:fetch`, `rsf:ack`, `rsf:rotate`
- `pds:publish`, `pds:opk_upload`, `pds:fetch`
- `ktl:read`, `ktl:append` (append restricted)

### 7.2 Inbox authorization
RSF MUST NOT authorize fetch/ack solely by possession of route_token bytes. Use:
- token claims binding to inbox_id or account/device identity, or
- server-side mapping between the authenticated principal and allowed inboxes.

## 8. Observability and audit pipeline
### 8.1 Telemetry design constraints
- No raw route_token values in logs/metrics.
- No raw envelopes or bundles in production logs.
- Use reason codes and coarse buckets.

### 8.2 Recommended telemetry architecture
- Ingress emits request metrics (status, latency, size buckets).
- Services emit:
  - reason-code counters (e.g., noncanonical_qse, bounds_exceeded, rate_limited),
  - queue depth buckets and TTL purge counts,
  - OPK low-water and consume rates,
  - KTL publish cadence and proof latency.

Audit:
- Security/audit events sent to a restricted sink with longer retention (sanitized).

## 9. Scaling and SLO recommendations
### 9.1 RSF
- Primary drivers: enqueue QPS, fetch QPS, storage I/O.
- SLO targets (example):
  - enqueue p99 latency < 250ms regional
  - fetch long-poll success p99 < wait_seconds + 250ms
- Horizontal scale: stateless API + worker pool; DB scaled with read replicas (careful with strong consistency for leasing semantics).

### 9.2 PDS
- Primary drivers: bundle fetch QPS and OPK consume contention.
- SLO targets:
  - bundle fetch p99 < 500ms regional
- Scale with stateless API; DB needs strong consistency for OPK consume.

### 9.3 KTL
- Primary drivers: append cadence and proof serving.
- SLO targets:
  - sth/proof p99 < 1000ms regional
- Prefer caching and CDN for read endpoints if public.

## 10. Failure modes and recovery
### 10.1 RSF
- DB outage: return retryable server_error; apply backpressure.
- Storage pressure: enforce queue caps; return queue_full; never accept and then silently drop without TTL.
- Restart: ensure TTL purge and leasing recovery are correct.

### 10.2 PDS
- OPK depletion: if opk_policy=required, return opk_unavailable; if preferred, serve without OPK.
- Crash during OPK issuance: atomic consume ensures no re-serve; request retries may receive a different OPK.

### 10.3 Backup/restore hazards
- RSF restore may re-introduce expired items; enforce TTL on restore and startup.
- PDS restore MUST NOT re-serve consumed OPKs. Recommended mitigations:
  - treat OPK consumption state as authoritative and durable,
  - avoid restoring PDS to a snapshot older than the “maximum acceptable replay window” without compensating controls,
  - if unavoidable, force device bundle refresh and discard old OPK pools as part of recovery.

### 10.4 KTL recovery
- Restore from last signed checkpoint; replay append-only segments.
- If integrity is uncertain, fail closed for authenticated mode until resolved.

## 11. Reference rollout sequence (recommended)
1. Deploy AuthN/AuthZ and observability baseline.
2. Deploy KTL (read endpoints + signer) and validate STH/proof responses.
3. Deploy PDS with atomic OPK consume; validate bundle fetch and OPK behavior.
4. Deploy RSF with QSE canonical parsing and bounds; validate enqueue/fetch/ack and token rotation.
5. Enable clients in staging with conformance gates:
   - parser-negative tests,
   - OPK at-most-once,
   - KT verification and pinning behavior.
6. Production rollout with canary (5% default) and auto-rollback triggers.

## 12. Configuration mapping (implementation checklist)
At deployment time, validate at minimum:
- QSE bounds at ingress and in RSF match configured maxima.
- RSF TTL, caps, and long-poll limits match profile.
- PDS idempotency windows and OPK caps match profile.
- KTL cadence and caching match profile.
- Logging redlines enforced (no raw tokens/envelopes).
- Key rotation schedules are configured and monitored.

---
**End of document.**
