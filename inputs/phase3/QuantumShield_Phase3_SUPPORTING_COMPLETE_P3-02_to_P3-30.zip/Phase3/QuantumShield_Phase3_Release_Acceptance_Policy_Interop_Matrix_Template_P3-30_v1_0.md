# QuantumShield Phase 3 — Release Acceptance Policy & Interop Matrix Report Template
**Artifact ID:** P3-30  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (frozen):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Related Phase 3 artifacts (alignment only):** P3-03 (Conformance Checklist), P3-04 (Interop Test Plan), P3-16 (CI Harness), P3-18 (Packaging), P3-24 (Client Retry/Backoff), P3-26 (Observability), P3-29 (Prod/DR)  
**Version:** 1.0  
**Date:** 2025-12-19  
**Timezone:** America/Chicago  

## 0. Purpose and scope
This document defines the **Phase 3 release acceptance policy** for QuantumShield deployments and provides a standardized **interop matrix report template** to record evidence.

It is intended to make “ready for production” determinations auditable, reproducible, and consistent across implementations while preserving the Phase 3 hard rule:

- Phase 2 canonical specs (QSP/QSE) are frozen.
- Phase 3 artifacts are supporting and MUST NOT introduce wire changes conflicting with canonical specs.

This artifact is **supporting** and **atomic**: it contains all requirements and templates necessary to perform a Phase 3 acceptance decision.

## 1. Definitions
### 1.1 Release candidate (RC)
A **release candidate** is a specific, immutable build of:
- client SDK(s) (optional for server-only acceptance),
- RSF service,
- PDS service,
- KTL service (if deployed),
- Auth issuer configuration (or self-hosted Auth service),
- all configuration and schema migrations required to run them.

Each RC MUST be uniquely identified by:
- `build_id` (e.g., git commit SHA or signed build digest),
- container image digests for each service,
- configuration version IDs (Git tag/commit),
- database migration version IDs.

### 1.2 Conformant vs acceptable
- **Conformant**: meets all MUST-level requirements in the canonical specs and Phase 3 supporting artifacts used by the deployment.
- **Acceptable for release**: conformant **and** meets operational gates (SLOs, DR readiness, security posture) for the target environment.

### 1.3 Evidence bundle
An **evidence bundle** is a packaged set of sanitized artifacts sufficient to demonstrate acceptance. Evidence bundles MUST be packaged per P3-18 (manifest + SHA-256 digests) and MUST obey telemetry redlines (P3-26).

## 2. Acceptance categories
Acceptance decisions are recorded per environment:

- **DEV acceptance**: functional correctness + basic conformance (developer gate).
- **STAGING acceptance**: full conformance + interop + load tests + DR drill in staging.
- **PROD acceptance**: staging acceptance plus production access controls, key management, and go-live readiness.

Unless explicitly waived (see §7), PROD acceptance MUST satisfy all gates in §3–§6.

## 3. Mandatory gates (PROD)
A Phase 3 PROD release MUST pass all gates below. Each gate MUST have an evidence reference in the interop report (Appendix A).

### Gate G1 — Canonical spec lock
- The RC MUST identify the frozen canonical versions:
  - QSP 4.3.2 (REVIEWED FULL)
  - QSE 1.8.2 (REVIEWED FULL)
- The RC MUST NOT change protocol wire behavior relative to those specs.
- Any discovered issue MUST be logged as Phase 3 errata (P3-02) and handled through supporting artifacts, not by silently changing wire format.

### Gate G2 — Conformance checklist pass
- The RC MUST pass the Phase 3 conformance checklist (P3-03) for the applicable components.
- Any FAIL item MUST either be fixed or explicitly waived per §7 with a documented compensating control.

### Gate G3 — Interop test pass
- The RC MUST pass the interop plan (P3-04) across the required matrix (see §4).
- Interop MUST include both positive and negative tests:
  - positive: expected flows succeed,
  - negative: malformed input, non-canonical encodings, bounds, auth failures, KT failures, replay handling.

### Gate G4 — Security invariants pass
The RC MUST demonstrate:
- strict canonical parsing and bounds enforcement (reject non-canonical / smuggling),
- serve-at-most-once semantics for OPKs where applicable,
- principal-bound authorization (no authorization-by-route_token secrecy),
- fail-closed cryptographic verification behavior (QSP/QSE),
- telemetry redlines enforcement (no secrets/identifiers in logs/metrics).

### Gate G5 — Operational readiness pass
The RC MUST demonstrate:
- observability in place (P3-26): dashboards + alerts + reason codes,
- abuse controls enabled (P3-27): 429 + `rate_limited`, deterministic backoff,
- production readiness & DR checklist satisfied (P3-29), including at least one successful restore test with evidence within the defined window,
- key management practices satisfy P3-28 (rotation overlap, audit trails, environment separation).

### Gate G6 — Upgrade / rollback safety pass
The RC MUST demonstrate:
- forward-compatible schema migrations and safe rollback (prefer forward-fix),
- staged rollout (canary/blue-green) with rollback plan rehearsed in staging,
- safe client retry behavior consistent with P3-24 (bounded retries, idempotency keys for writes).

## 4. Interop matrix requirements
### 4.1 What must interoperate
At minimum, interop must be demonstrated for:
- **Client SDK ↔ RSF**
- **Client SDK ↔ PDS**
- **Client SDK ↔ KTL** (direct or via PDS bundle attachment, as deployed)
- **RSF ↔ Auth validation**
- **PDS ↔ Auth validation**
- **KTL operator path** (append/sign) ↔ verifier behavior (clients/monitors)

### 4.2 Required partner diversity
To avoid monoculture blind spots, the acceptance matrix MUST include at least:
- **2 independent implementations** for each critical role, where feasible:
  - two client SDK implementations (e.g., Rust and Java/Kotlin/Swift),
  - two service implementations or two builds/configurations (e.g., reference + production hardening),
  - at least two KTL verifiers/monitors (could be different languages).

If only one implementation exists for a role, acceptance MAY proceed only with a documented risk waiver (§7) and a plan to add diversity.

### 4.3 Minimum interop matrix size (baseline)
For PROD acceptance, the matrix SHOULD include at least:
- 2 clients × 2 RSF builds × 2 PDS builds = 8 client↔service combinations
- For KTL (if deployed): 2 verifiers × 2 KTL builds = 4 combinations
- For Auth: each service build must validate tokens from at least two key versions (rotation overlap test)

A smaller matrix MAY be accepted only with explicit waiver and compensating tests.

## 5. Evidence bundle contents (minimum)
Evidence bundles MUST be sanitized and MUST include:

### 5.1 Identity and integrity
- `MANIFEST.json` with SHA-256 for all included files (P3-18)
- build identifiers:
  - commit SHA(s),
  - container digests,
  - config version IDs
- environment: dev/staging/prod, regions

### 5.2 Test evidence
- P3-03 conformance results (machine-readable if possible)
- Interop matrix report (Appendix A completed)
- CI harness logs (P3-16) — **sanitized**
- Negative test run results (P3-19 / P3-23) — **sanitized**
- Load test summary (P3-29) — aggregate only

### 5.3 Operational evidence
- SLO report snapshot (P3-26): error rates and latency percentiles for key endpoints
- Alert configuration export (redacted)
- Rate limit policy config (P3-27) and verification results
- Backup/restore drill report (P3-29) with timestamps and outcomes
- Key rotation readiness evidence (P3-28): key inventory, rotation overlap configuration, and audit extracts (sanitized)

### 5.4 Security review artifacts
- Threat model / risk register entries for any waivers
- Incident response runbook links and proof of at least one tabletop (P3-29)
- Access review attestation (who has privileged roles)

## 6. Acceptance workflow
### 6.1 Roles
Minimum roles for PROD acceptance:
- Release Manager (RM)
- Security Owner (SO)
- SRE Owner (SRE)
- Protocol Owner (PO)

### 6.2 Workflow steps (normative)
1. **RC freeze:** RM declares RC frozen (build ids + config).
2. **Conformance run:** CI executes P3-03 + P3-16 harness; results archived.
3. **Interop run:** execute P3-04 across the required matrix; archive raw outputs (sanitized).
4. **Operational readiness:** execute load tests and DR restore drill (P3-29); gather SLO evidence (P3-26).
5. **Security sign-off:** SO validates key management posture (P3-28), telemetry redlines (P3-26), abuse controls (P3-27), and invariants.
6. **Go/No-Go meeting:** RM records the decision, waivers, and sign-offs.
7. **Evidence bundle seal:** produce P3-18 evidence bundle with manifest + digests; store in immutable location.

## 7. Waivers and exceptions (controlled)
Waivers are permitted only when the risk is understood and explicitly accepted.

### 7.1 Waiver rules (MUST)
A waiver MUST:
- identify the gate being waived (G1–G6),
- state the exact failing requirement,
- describe compensating controls and additional monitoring,
- set an expiration date,
- name the approving roles (SO + PO required),
- be included in the evidence bundle.

### 7.2 Non-waivable items (default)
By default, the following are **non-waivable** for PROD:
- canonical parsing and bounds enforcement,
- OPK serve-at-most-once correctness (where OPKs are used),
- KTL signing key integrity and pinning model (if KT is used in authenticated mode),
- no secrets/identifiers in telemetry streams.

If an organization chooses to waive one of these, it MUST be treated as a deliberate acceptance of elevated risk and recorded as such.

## 8. Interop matrix report template (Appendix A)
Use Appendix A as the standard report artifact and include it in the evidence bundle.

## Appendix A — Interop Matrix Report Template (fill-in)
### A.1 Report metadata
- Report ID:
- Date range:
- Environment: `dev|staging|prod`
- Regions:
- RC build_id:
- Config version:
- Canonical specs: QSP 4.3.2, QSE 1.8.2
- Test harness version (P3-16):
- Negative vector set version (P3-23):

### A.2 Implementations under test
Provide one row per implementation.

| Role | Implementation Name | Language/Stack | Version/Build ID | Notes |
|------|----------------------|----------------|------------------|-------|
| Client SDK A | | | | |
| Client SDK B | | | | |
| RSF A | | | | |
| RSF B | | | | |
| PDS A | | | | |
| PDS B | | | | |
| KTL A (if used) | | | | |
| KTL B (if used) | | | | |
| Auth Issuer | | | | |

### A.3 Matrix results (client ↔ services)
For each combination, record PASS/FAIL and evidence references.

Legend:
- PASS = all required flows succeed
- FAIL = one or more required flows fail (attach details)
- WAIVED = known failure with approved waiver (attach waiver ID)

| Client | RSF | PDS | KTL | Auth | Result | Evidence Ref(s) | Notes |
|--------|-----|-----|-----|------|--------|------------------|-------|
| SDK A | RSF A | PDS A | KTL A | Auth | | | |
| SDK A | RSF A | PDS B | KTL A | Auth | | | |
| SDK A | RSF B | PDS A | KTL B | Auth | | | |
| SDK A | RSF B | PDS B | KTL B | Auth | | | |
| SDK B | RSF A | PDS A | KTL B | Auth | | | |
| SDK B | RSF A | PDS B | KTL B | Auth | | | |
| SDK B | RSF B | PDS A | KTL A | Auth | | | |
| SDK B | RSF B | PDS B | KTL A | Auth | | | |

### A.4 Required flow checklist per matrix row
For each row, attest the following were executed:

**RSF**
- [ ] enqueue (valid QSE)
- [ ] fetch (long-poll or standard)
- [ ] ack (idempotent)
- [ ] rotate/register (idempotency + binding)
- [ ] negative: non-canonical QSE rejected
- [ ] negative: unauthorized fetch/ack rejected (401/403)

**PDS**
- [ ] get_bundles (valid)
- [ ] publish_bundle (idempotent)
- [ ] upload_opk_dh and/or upload_opk_pq (as applicable)
- [ ] negative: malformed base64url rejected
- [ ] negative: enumeration attempt normalized (no existence oracle)
- [ ] negative: OPK depletion behavior matches policy

**KTL** (if applicable)
- [ ] fetch STH
- [ ] fetch inclusion proof
- [ ] fetch consistency proof
- [ ] verify STH signatures (EC + PQ)
- [ ] negative: invalid proof rejected
- [ ] negative: rollback detection triggers fail-closed

**Auth**
- [ ] token validation for each endpoint group
- [ ] key rotation overlap test: old and new `kid` accepted during overlap; old rejected after retirement (staging-only if needed)

### A.5 Gate summary (G1–G6)
| Gate | Status (PASS/FAIL/WAIVED) | Evidence Ref(s) | Waiver ID (if any) |
|------|----------------------------|-----------------|--------------------|
| G1 Canonical lock | | | |
| G2 Conformance | | | |
| G3 Interop | | | |
| G4 Security invariants | | | |
| G5 Operational readiness | | | |
| G6 Upgrade/rollback safety | | | |

### A.6 Waivers register
| Waiver ID | Gate | Description | Compensating Controls | Expiration | Approvers |
|----------|------|-------------|-----------------------|------------|-----------|
| | | | | | |

### A.7 Sign-offs
- Release Manager (RM): ___________________  Date: __________
- Security Owner (SO): _____________________  Date: __________
- SRE Owner (SRE): _________________________  Date: __________
- Protocol Owner (PO): ______________________  Date: __________

---
**End of document.**
