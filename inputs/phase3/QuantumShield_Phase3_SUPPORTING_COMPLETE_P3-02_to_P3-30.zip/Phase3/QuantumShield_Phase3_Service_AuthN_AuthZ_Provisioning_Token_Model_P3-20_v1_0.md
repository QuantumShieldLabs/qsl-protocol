# QuantumShield Phase 3 — Service AuthN/AuthZ, Provisioning & Token Model
**Artifact ID:** P3-20  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (alignment only):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Related Phase 3 artifacts (non-required):** P3-11 (Ops/Privacy), P3-12 (Parameters), P3-13 (OpenAPI), P3-14 (Schemas), P3-15 (Topology), P3-17 (Storage)  
**Version:** 1.0  
**Date:** 2025-12-20  
**Timezone:** America/Chicago  

## 0. Purpose and scope
This document defines a concrete, interoperable **authentication**, **authorization**, and **provisioning** model for QuantumShield Phase 3 services:

- **RSF** (Relay/Store-and-Forward): enqueue/fetch/ack/status/route_token rotation/register
- **PDS** (Prekey Directory Service): bundle publish/revoke, OPK uploads, bundle fetch, inventory
- **KTL** (Key Transparency Log): public read endpoints and operator append endpoints (if exposed)

It intentionally specifies what was left “deployment-defined” in the OpenAPI (P3-13), so independent implementations do not diverge or accidentally introduce insecure patterns (especially *authorization-by-route_token secrecy*, which is prohibited).

This artifact is **supporting** and **atomic**: it defines all required concepts and rules within this document. It does not modify QSP/QSE wire formats.

## 1. Security goals (why these rules exist)
1. **No authorization by secret routing tokens.** Knowledge of a `route_token` MUST NOT be sufficient to fetch, ack, rotate, or register. Tokens may be guess-resistant, but they are not an authorization factor.
2. **Least privilege.** Every request is authorized by explicit scopes tied to a principal.
3. **Minimize identity leakage.** Errors and timing MUST avoid “user exists” and “inbox exists” oracles.
4. **Replay and abuse resistance.** Tokens expire quickly; refresh has bounded lifetime; rate limits apply per principal and per target.
5. **Operational clarity.** Operators can reason about who can do what, and CI can test it deterministically.

## 2. Roles and principals
### 2.1 Principal types
All authenticated requests are associated with exactly one **principal**:

- `user`: an account holder (human or account entity)
- `device`: a device bound to a user (preferred for most client calls)
- `service`: an internal service identity (mTLS; RSF↔PDS↔KTL internal calls if any)
- `operator`: a privileged human or automated operator identity (KTL append, admin actions)

### 2.2 Canonical identifiers (privacy-aware)
Services may internally store identifiers; responses and logs MUST be sanitized per §9.

- `user_handle`: opaque string handle (not necessarily public username)
- `device_id`: integer scoped to a user_handle
- `inbox_id`: opaque internal identifier (server-generated)
- `route_token`: opaque byte string (QSE) used for routing

### 2.3 Binding rules
- A `device` principal MUST be bound to exactly one `user_handle` and one `device_id`.
- A `user` principal may own multiple `device` principals.
- A `service` principal is bound to a service name and environment (e.g., `rsf-prod-us1`).
- An `operator` principal is bound to a human/automation identity and environment.

## 3. Authentication mechanisms
### 3.1 External clients (recommended baseline)
External clients (apps/SDKs) MUST authenticate using **bearer access tokens** issued by an Auth service.

- Access token TTL (recommended): 30–60 minutes
- Refresh token TTL (optional; recommended): 7–30 days
- Token keys: rotated with overlap; old keys retired promptly

### 3.2 Internal service-to-service (recommended)
Internal service calls SHOULD use **mTLS** (service identity), with optional secondary bearer tokens.

- mTLS identities MUST be unique per service and environment.
- mTLS cert rotation SHOULD be automated.
- Internal calls MUST use least-privilege scopes (see §5.4).

### 3.3 Public KTL read endpoints
KTL read endpoints MAY be public (no auth). If public:
- They MUST be rate-limited per IP / per anonymous bucket.
- They MUST return canonical bytes and avoid expensive work amplification.

KTL append endpoints MUST NOT be public.

## 4. Token format and validation requirements
This document specifies **required claims** and validation rules independent of token container type.

### 4.1 Access token requirements
An access token MUST carry:
- `iss` (issuer)
- `aud` (audience; one of `rsf`, `pds`, `ktl`, or `qshield-services`)
- `sub` (subject principal id; stable within issuer)
- `ptyp` (principal type): `user|device|service|operator`
- `exp` (expiry)
- `iat` (issued at)
- `jti` (unique token id for replay/abuse tracking)
- `scp` (scopes array or space-delimited scope string)
- `env` (environment tag, e.g., `prod|staging|dev`)
- `tenant` (optional; multi-tenant deployments)

If `ptyp=device`, token MUST include:
- `user_handle`
- `device_id`

If `ptyp=service`, token MUST include:
- `service_name`

### 4.2 Refresh token requirements (if used)
Refresh tokens MUST:
- be sender-constrained (recommended) or stored in secure device storage
- have an absolute max lifetime (`refresh_ttl_seconds`)
- be revocable (server-side list or rotation scheme)
- be bound to a single principal (device preferred)

### 4.3 Validation rules (MUST)
Every authenticated endpoint MUST:
1. Validate signature (or MAC) against trusted keys.
2. Validate `exp` and `iat` (with bounded clock skew).
3. Validate `aud` matches the service.
4. Validate `env` matches server environment.
5. Validate scope set contains the required scope for the endpoint.
6. Validate `ptyp` is allowed for the endpoint.
7. Enforce replay/abuse policy keyed by `jti` (at least short-term cache) where risk warrants.

Fail-closed: if any validation fails, the request MUST be rejected (401/403) without side effects.

## 5. Authorization model (scopes)
### 5.1 Scope naming convention
Scopes are strings of the form:
- `rsf:<action>`
- `pds:<action>`
- `ktl:<action>`
- `admin:<action>`

Scopes are **capabilities**, not roles. Roles map to bundles of scopes.

### 5.2 RSF scopes (minimum)
- `rsf:enqueue` — enqueue QSE envelopes
- `rsf:fetch` — fetch messages for a route_token/inbox
- `rsf:ack` — acknowledge delivered messages
- `rsf:status` — read coarse inbox status
- `rsf:rotate` — rotate route_tokens (old→new)
- `rsf:register` — register initial route_token (provisioning)

RSF endpoints MUST require scopes:
- `/v1/rsf/enqueue` → `rsf:enqueue`
- `/v1/rsf/fetch` → `rsf:fetch`
- `/v1/rsf/ack` → `rsf:ack`
- `/v1/rsf/nack` → `rsf:fetch` (or dedicated `rsf:nack`, optional)
- `/v1/rsf/status` → `rsf:status`
- `/v1/rsf/route_tokens:rotate` → `rsf:rotate`
- `/v1/rsf/route_tokens:register` → `rsf:register`

### 5.3 PDS scopes (minimum)
- `pds:publish_bundle` — publish/update device bundle
- `pds:revoke_device` — revoke a device
- `pds:upload_opk_dh` — upload DH OPKs
- `pds:upload_opk_pq` — upload PQ OPKs
- `pds:inventory` — read coarse OPK inventory
- `pds:get_bundles` — fetch bundles for a target user_handle (initiator path)

PDS endpoints MUST require:
- PUT bundle → `pds:publish_bundle`
- revoke → `pds:revoke_device`
- opk uploads → respective upload scope
- inventory → `pds:inventory`
- get bundles (initiator) → `pds:get_bundles`

### 5.4 KTL scopes (minimum)
- `ktl:read` — read STH and proofs (if not public)
- `ktl:append` — append leaves (operator-only)

If KTL is public for reads, `ktl:read` is optional; if authenticated reads are used, `ktl:read` MUST be required.

### 5.5 Admin scopes (optional)
- `admin:rsf_manage`
- `admin:pds_manage`
- `admin:ktl_manage`
- `admin:read_audit`

Admin scopes MUST be restricted to `operator` principals.

## 6. Endpoint-level authorization constraints
Scopes alone are not sufficient. Endpoints MUST apply **resource binding** checks.

### 6.1 RSF resource binding
For endpoints that accept `route_token_b64` (fetch/ack/status):
- The authenticated principal MUST be authorized for the **inbox** bound to that token.
- Authorization MUST be based on the principal identity (device/user) and server-side mapping, not on possession of the token bytes.

Recommended model:
- RSF maintains a mapping from `(user_handle, device_id)` → `inbox_id` and from `route_token` → `inbox_id`.
- On request: resolve token → inbox_id, then verify caller principal is owner (or operator/admin).

For `rotate`:
- Caller MUST be the owner of the inbox associated with `old_route_token`, or operator/admin.
- RSF MUST reject rotations that bind `new_route_token` to a different owner or that collide with another inbox.

For `register`:
- Caller MUST be a device principal being provisioned (or operator/admin).
- Register binds the route_token to the caller’s inbox; RSF MUST NOT allow registering tokens for other principals.

### 6.2 PDS resource binding
For bundle publish/revoke/upload/inventory:
- Caller MUST be the device owner for `(user_handle, device_id)` or operator/admin.
- Initiator bundle fetch (`get_bundles`) is authorized differently:
  - Caller must be authorized to initiate sessions (device principal recommended).
  - Rate limits apply per principal and per target user_handle to mitigate enumeration.
  - Responses MUST be normalized to reduce existence oracles (§8).

### 6.3 KTL resource binding
- Read endpoints: public or `ktl:read`.
- Append: MUST require `ktl:append` and `operator` principal type (or `service` in operator pipeline). Do not allow client devices.

## 7. Provisioning flows
This section defines interoperable provisioning flows for Phase 3.

### 7.1 Device enrollment (baseline)
Goal: obtain a device principal token and enable it to publish bundles and register route tokens.

Steps:
1. User authenticates to Auth service (out-of-scope UX).
2. Auth service issues a **device-bound** identity (device_id assignment) and grants device scopes.
3. Device receives:
   - access token (short TTL)
   - optional refresh token (longer TTL)
   - `user_handle`, `device_id` embedded in token claims

Security notes:
- Enrollment MUST require MFA or equivalent policy (deployment choice).
- Device binding MUST be explicit and auditable.

### 7.2 Initial route_token registration (RSF)
Goal: associate the device’s RSF inbox with an initial route_token.

Steps:
1. Client generates a fresh route_token (random bytes; length within QSE cap).
2. Client calls RSF `/route_tokens:register` with `route_token_b64`.
3. RSF creates or fetches an inbox for the `(user_handle, device_id)` principal and binds the token.

Rules:
- Token MUST be fresh (no collisions). RSF MUST reject collisions with `409 conflict`.
- RSF MUST store only what is necessary; the token is treated as opaque.
- RSF SHOULD allow re-registering the same token under idempotency within a short window, but MUST NOT rebind a token to a different principal.

### 7.3 Bundle publication (PDS)
Goal: allow initiators to fetch a verified PrekeyBundle.

Steps:
1. Device constructs canonical bundle bytes and signatures (as per QSP suite rules).
2. Device calls PDS PUT bundle with idempotency_key.
3. PDS stores as immutable revision and updates active pointer.

Rules:
- PDS MUST be safe under retries (idempotency).
- PDS MAY perform basic hygiene checks but MUST NOT “repair” or mutate canonical bytes.

### 7.4 OPK upload and serving
Goal: maintain OPK pools for forward secrecy and PQ safety.

Steps:
1. Device uploads DH OPKs and/or PQ OPKs via batch endpoints with idempotency.
2. Initiator requests bundles via `get_bundles`.
3. If policy requires, PDS consumes OPKs at-most-once with atomic consume.

Rules:
- Consume must be atomic and crash-safe; no re-serve of consumed OPKs.
- Inventory endpoint returns only **coarse buckets**.

## 8. Enumeration resistance and error normalization
### 8.1 General rule (MUST)
Endpoints that accept a target identifier (`user_handle`, `device_id`, `route_token`) MUST NOT produce responses that reliably reveal existence to unauthorized callers.

### 8.2 Response normalization recommendations
- For unauthorized or unauthenticated callers:
  - Prefer `401` for missing/invalid auth, `403` for auth present but not permitted.
  - Avoid `404` differences that reveal existence; where feasible, return `403` for both “not found” and “not authorized” for sensitive resources.
- For authenticated callers:
  - `404` may be used when the caller is authorized to know the resource existence (e.g., device owner querying its own inbox/device).

### 8.3 Timing and rate limits
- Apply rate limits per principal and per target bucket.
- For public endpoints, rate limit per IP bucket and use caching where safe.
- Implement jitter and constant-time comparisons where applicable to reduce high-fidelity oracles.

## 9. Logging, audit, and privacy redlines
### 9.1 MUST NOT log
- Raw `route_token` bytes
- Raw bearer tokens (access/refresh)
- Full QSE envelopes or QSP ciphertexts
- Any cryptographic secrets (private keys, derived keys)

### 9.2 Allowed logs (sanitized)
- request_id, coarse time buckets
- reason codes (standardized)
- salted hashes of identifiers:
  - `H(route_token || salt)`
  - `H(user_handle || salt)` (if user_handle may be sensitive)
- size buckets and outcome codes

### 9.3 Audit events
Services SHOULD store audit events for:
- enrollments (device creation)
- route_token register/rotate
- bundle publish/revoke
- OPK upload and serve consumption events (without raw key material)
- KTL append events (operator path)

Audit retention is a policy decision; ensure it aligns with privacy posture.

## 10. Token rotation and revocation
### 10.1 Signing key rotation
- Token signing keys MUST rotate with overlap.
- Services MUST accept tokens signed by keys in the active + overlap set.
- Overlap windows SHOULD be bounded (days, not months).

### 10.2 Principal revocation
The system MUST support revocation at least at the device level:
- revoked devices cannot publish bundles, upload OPKs, register/rotate tokens, or fetch/ack.
- revocation should invalidate refresh tokens and shorten access token viability (via short TTL).

### 10.3 Replay controls
At minimum:
- track `jti` for a short window to detect obvious replay at service edges for high-value endpoints (rotate/register/publish).
- apply rate limits on suspicious behavior.

## 11. Interop test requirements (authorization)
Implementations MUST support the following deterministic test cases:

1. **No-auth denies:** fetch/ack/rotate/register/publish endpoints reject without auth.
2. **Token-known but unauthorized denies:** using a valid route_token with wrong principal must not succeed.
3. **Least privilege:** a token with `rsf:enqueue` must not fetch.
4. **Resource binding:** a device token can only manage its own `(user_handle, device_id)` resources.
5. **Rotation authorization:** only the owner (or operator) can rotate; collisions fail.
6. **Error normalization:** unauthorized enumeration attempts do not yield reliable existence signals.
7. **Logging redlines:** route_token marker bytes do not appear in logs or error bodies.

## Appendix A — Recommended role bundles
These are convenience bundles; deployments may implement roles as sets of scopes.

### A.1 Device (client) role
- RSF: `rsf:enqueue`, `rsf:fetch`, `rsf:ack`, `rsf:status`, `rsf:rotate`, `rsf:register`
- PDS: `pds:publish_bundle`, `pds:revoke_device`, `pds:upload_opk_dh`, `pds:upload_opk_pq`, `pds:inventory`, `pds:get_bundles`
- KTL: `ktl:read` (if authenticated read is used)

### A.2 Initiator-only device role (minimal)
- RSF: `rsf:enqueue`
- PDS: `pds:get_bundles`
- KTL: `ktl:read` (if needed)

### A.3 Operator role
- Admin: `admin:*`
- KTL: `ktl:append` (and `ktl:read` if authenticated)

## Appendix B — Reason codes (authorization-related)
Suggested reason codes for authZ surfaces (align with the shared registry model):
- `auth_failed`
- `forbidden`
- `rate_limited`
- `not_found` (only when authorized to know existence)
- `conflict`
- `invalid_request`

---
**End of document.**
