# QuantumShield Phase 3 — State Persistence & Crash-Safety Specification
**Artifact ID:** P3-07  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs:** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Version:** 1.0  
**Date:** 2025-12-19  
**Timezone:** America/Chicago

## 0. Purpose and scope
This document specifies **crash-safety and persistence requirements** for QuantumShield implementations and related services, with a focus on:
- QSP session/ratchet state persistence (clients and any server-side agents that hold session state),
- replay/duplicate delivery robustness under store-and-forward,
- Key Transparency (KT) pinned state persistence and rollback resistance,
- service-side atomicity requirements for one-time prekey (OPK) consumption, and
- durable evidence (audit-safe) without leaking secrets.

This is a **supporting** artifact. It does not change QSP/QSE. In any conflict, canonical specs govern.

## 1. Canonical constraints that drive this specification
The following canonical properties are treated as **non-negotiable integration constraints**:

1. **Transactional receive semantics (QSP):** `ReceiveMessage` must operate on a copy of state and **commit only on full success** (header + body decrypt + validations). Failures must not partially advance state.
2. **Bounded work and deterministic bounds enforcement (QSP):** caches and search loops are bounded; persistence must not allow unbounded growth or indefinite retention.
3. **OPK serve-at-most-once semantics (QSP service requirement):** the service must atomically consume OPKs and must not re-serve after crash/restart.
4. **KT rollback resistance (QSP Authenticated mode):** clients maintain pinned STH state per log and must reject rollback or inconsistent STHs.

This document turns those into implementable storage and crash-recovery patterns.

## 2. Threat model for persistence (what can go wrong)
Persistence is security-critical. We assume:
- Process crashes and power loss at any instruction boundary.
- Storage corruption and partial writes are possible (especially on mobile).
- Rollback is possible (attacker restores an old database snapshot) on compromised devices or via malicious backup restore.
- Concurrency: multiple threads may attempt sends/receives concurrently.
- Store-and-forward: the same ciphertext may be delivered multiple times; deliveries may be reordered.

**Goal:** after any crash or restart, the implementation must either:
- behave as if the last operation never happened (no partial advance), or
- behave as if it happened exactly once and is fully committed.

## 3. Persistence units and atomicity boundaries
### 3.1 State objects that MUST be persisted
At minimum, implementations MUST persist the following per active QSP session:

**Session identity and invariants**
- `protocol_version`, `suite_id`
- `session_id` (16 bytes)
- local role (initiator/responder)
- peer identity references (public keys or verified key IDs as required by deployment)

**Ratchet state**
- root key / chain keys as specified by the suite
- DH ratchet keys and counters
- message numbers (`Ns`, `Nr`, `PN`) as applicable
- any suite-specific flags and boundary state

**Replay/skip caches (bounded)**
- skipped message keys table (`MKSKIPPED`) — bounded by canonical maxima
- skipped header keys table (`HKSKIPPED`) — bounded and TTL-limited
- any auxiliary indices required to implement bounded header search deterministically

**Anti-rollback / versioning**
- a monotonically increasing local `state_epoch` (u64) incremented on each committed receive/send state transition
- a `schema_version` and migration markers

**KT pinned state (Authenticated mode)**
- for each `log_id`: last pinned `(tree_size, root_hash, timestamp)` and any additional pinned metadata required by QSP
- verification policy parameters (freshness window, etc.) if deployment-defined

### 3.2 State objects that SHOULD be persisted
- per-session telemetry counters (non-sensitive), e.g., rejected replays, decrypt failures (aggregated)
- last-seen peer device bundle identifiers (public metadata) to assist UX
- OPK pool health status (for the local device publisher)

### 3.3 Atomic commit unit
The **atomic commit unit** for a receive operation MUST include:
- the ratchet state update,
- any cache insertions/deletions (MKSKIPPED/HKSKIPPED),
- replay markers (if stored),
- and any persisted side effects (e.g., “delivered message ID acknowledged”).

No part of this unit may commit independently of the others.

## 4. Two-phase receive pipeline (required model)
Implementations MUST structure receive as:

1. **Parse and validate (no state changes)**
   - Parse QSE (if present) and enforce QSE bounds.
   - Parse QSP message canonically.
   - Reject unknown versions/suites/flag bits per QSP.
2. **Speculative decrypt and validate on a COPY**
   - Clone current session state to `S'`.
   - Attempt header decrypt (bounded).
   - Attempt body decrypt.
   - Reconstruct and validate associated data (AD) and invariants.
   - Apply any required bounds checks and replay protections inside `S'`.
3. **Commit-or-discard**
   - If success: atomically persist `S'` as the new committed state.
   - If failure: discard `S'` and persist nothing.

This directly implements the canonical “copy then commit” requirement.

## 5. Storage patterns that satisfy atomicity
This spec permits multiple implementation choices. At least one of the following patterns MUST be used.

### 5.1 Pattern A — Single-writer transactional database (recommended)
Use a transactional KV store or relational DB (SQLite WAL, LMDB, RocksDB with transactions) and enforce:
- **single-writer** semantics per session (or per account) to avoid write-write races,
- atomic transaction for the entire commit unit.

**Commit protocol:**
- Begin transaction.
- Write new session state row (`state_blob`, `state_epoch+1`, etc.).
- Apply cache mutations (insert/delete bounded entries).
- Update indices and any ack markers.
- Commit transaction (fsync/WAL durable).

**Crash behavior:** either the transaction commits fully or not at all.

### 5.2 Pattern B — Copy-on-write snapshot + atomic pointer swap
Store immutable snapshots and atomically update a pointer:

- Write new snapshot `snapshot_{epoch+1}` (fsync).
- Atomically update `active_snapshot_ptr` to epoch+1 (fsync).
- Optionally garbage collect older snapshots.

This is effective for file-based stores and some embedded environments.

### 5.3 Pattern C — Write-ahead log (WAL) + checkpointing
Maintain a journal of state transitions:
- Append transition record (durable).
- Apply to in-memory state.
- Periodically checkpoint into a compact snapshot.
- On restart, replay journal from last checkpoint.

This pattern is acceptable but MUST ensure bounded replay time and bounded journal growth.

## 6. Concurrency rules
### 6.1 Single-writer rule (mandatory)
For each `(account, session_id)` pair, the implementation MUST enforce **single-writer commit** semantics. Acceptable strategies:
- per-session mutex/lock,
- actor/queue model (recommended for mobile),
- DB transaction locking.

### 6.2 Re-entrancy and duplicate delivery
Receive may be invoked concurrently due to:
- multiple envelopes arriving,
- retries,
- app resume events.

Therefore:
- Receive MUST serialize commit operations per session.
- Concurrent receives may run speculative decrypt on the same base state, but only one may commit. Others MUST detect state_epoch mismatch and re-run (or abort safely).

### 6.3 Send/receive interleavings
Sending messages advances some session state (e.g., send chain keys). Implementations MUST:
- serialize send commits with receive commits per session, or
- ensure that the underlying state machine supports safe concurrent advancement (hard and error-prone; not recommended).

**Phase 3 default:** serialize send and receive commits per session.

## 7. Replay and duplicate-handling persistence
### 7.1 What must be cryptographically enforced vs persisted
QSP’s cryptographic construction plus ratchet state provides replay detection. Persistence must ensure that:
- after restart, previously-accepted messages are not re-accepted due to rollback/partial commit,
- bounded caches remain consistent with ratchet counters.

### 7.2 Required behavior
Implementations MUST ensure:
- if a message was accepted and commit succeeded, then after restart the same message is rejected (or results in idempotent “already delivered” behavior) according to the ratchet’s replay/duplicate semantics.
- if commit did not succeed, then after restart the message may be processed again from the previous state (safe retry).

### 7.3 Optional “delivered set” marker
Some deployments prefer an explicit delivered marker (e.g., `(session_id, msg_nonce_or_hash)` with TTL) to provide idempotent delivery semantics at the application layer.

If used:
- it MUST be part of the atomic commit unit.
- it MUST be bounded (TTL and max entries).
- it MUST NOT leak plaintext or stable identifiers (store only hashes of ciphertext header/body or internal message IDs).

## 8. Bounded caches: persistence requirements
Canonical QSP defines bounds (e.g., MAX_SKIP, MAX_MKSKIPPED, MAX_HEADER_ATTEMPTS, MAX_HKSKIPPED, HK_TTL_DAYS, MAX_MKSKIPPED_SCAN). Persistence must uphold those bounds across restarts.

### 8.1 MKSKIPPED (skipped message keys)
MUST:
- enforce maximum entry count (and any canonical eviction policy if specified),
- evict deterministically (oldest-first or smallest message number first; pick one and keep consistent),
- store enough metadata to enforce MAX_MKSKIPPED_SCAN bounds without unbounded iteration after restart.

### 8.2 HKSKIPPED (skipped header keys)
MUST:
- enforce entry cap (MAX_HKSKIPPED),
- enforce TTL (HK_TTL_DAYS),
- purge expired entries on startup and periodically during normal operation.

### 8.3 Startup purge rules
On startup/restart, implementations MUST:
- purge expired HK entries,
- purge MK entries beyond bounds,
- and ensure any indices reflect the purges atomically (either in the same startup transaction or via a safe “maintenance epoch” transaction).

## 9. Key Transparency pinned state: persistence and rollback resistance
### 9.1 Pinned state model
For each KT `log_id`, persist:
- `pinned_tree_size` (u64)
- `pinned_root_hash` (32 bytes)
- `pinned_timestamp` (u64)
- optional: `pinned_sth_signature` (public, but may be kept for debugging)
- a monotonic `kt_epoch` counter

### 9.2 Rollback defenses (required best-effort)
On platforms with secure storage, clients SHOULD store pinned KT state in:
- iOS Keychain / Secure Enclave-protected storage,
- Android Keystore + encrypted storage,
- desktop: OS credential vault where possible.

Additionally, clients MUST implement at least one of:
- **Monotonic counter binding:** store `(kt_epoch, pinned_tree_size)` and reject any state load that decreases these values, OR
- **State MAC binding:** store an integrity MAC over pinned state using a device-local secret stored in secure storage, OR
- **Hardware-backed binding:** use a hardware monotonic counter if available.

**Note:** In a fully compromised device scenario, rollback may still be possible. The protocol’s KT verification rules provide detection of inconsistent STHs; persistence aims to make rollback materially harder in realistic environments.

### 9.3 Crash-safety of KT updates
When accepting a newer STH and updating pinned state:
- verify STH/proofs in-memory first,
- then atomically commit the new pinned state (single transaction or pointer swap),
- do not partially update a subset of fields.

## 10. OPK consumption: service-side crash safety (PDS requirement)
Although this document focuses on endpoint state, OPK serving is a persistence-critical service requirement.

### 10.1 Required properties
A PDS MUST ensure:
- **at-most-once issuance:** no OPK is returned twice, even under concurrency.
- **atomic consume:** issuance and marking-consumed are one atomic operation.
- **crash-safe:** after restart, a consumed OPK is not re-served.

### 10.2 Minimal implementation pattern (transactional DB)
- `SELECT ... FOR UPDATE` (or equivalent) an available OPK row.
- Mark `state=consumed`, set `consumed_at`, set `issued_to_request_id` (optional).
- Commit.
- Construct response bundle using the selected OPK.

If the process crashes:
- before commit: OPK remains available; safe to re-issue.
- after commit but before response: OPK is consumed and MUST NOT be re-issued; the client may retry and receive a different OPK (or none).

### 10.3 Idempotency (recommended)
To reduce client pain, PDS SHOULD support an idempotency key so that:
- if the same request retries, PDS can return the same OPK exactly once **only if it can do so safely** without violating at-most-once semantics (i.e., the OPK is logically tied to that request and not served to a different request).

## 11. Sensitive material handling
### 11.1 Secrets that MUST NOT be written to logs
Implementations MUST NOT log:
- private keys (identity keys, OPK private keys),
- root keys / chain keys / message keys / header keys,
- decrypted headers or plaintext bodies,
- raw randomness seeds.

### 11.2 Secrets at rest
Ratchet state necessarily contains secrets. Therefore:
- at-rest encryption SHOULD be used when available (OS file protection classes, encrypted databases).
- on mobile, storage SHOULD be tied to device unlock state where feasible.
- crash dumps MUST be configured to exclude sensitive memory where the platform allows it.

### 11.3 Secure erase (best-effort)
Where language/runtime permits, implementations SHOULD:
- zeroize ephemeral secrets when no longer needed,
- avoid long-lived plaintext buffers of keys or decrypted messages beyond the application boundary.

## 12. Schema and migration requirements
### 12.1 Versioning
Persist:
- `schema_version` (u32)
- `protocol_version`, `suite_id` per session

### 12.2 Migration safety
Migrations MUST be:
- transactional (all-or-nothing),
- idempotent,
- and must not silently weaken security posture.

If a migration fails, the implementation MUST fail closed (do not run with partially migrated state).

## 13. Startup and recovery procedure (required)
On startup:
1. Open storage in a mode that enforces integrity (verify DB, verify MAC if used).
2. Validate `schema_version`; run migrations if needed (transactional).
3. Load pinned KT state; verify anti-rollback checks (epoch monotonicity / MAC).
4. Load sessions list; for each session:
   - purge expired HK entries and enforce cache bounds,
   - verify internal invariants (e.g., counters within expected bounds),
   - if invariants fail, quarantine the session (do not attempt to “heal” silently).
5. Start message processing with single-writer enforcement.

## 14. Conformance tests (minimum, required for Phase 3)
The following tests MUST exist for any conformant implementation.

### 14.1 Crash injection tests (client)
For each of the following crash points, the system must restart into a safe state:
- after QSE parse, before QSP parse (no changes)
- after QSP parse, before speculative decrypt (no changes)
- during speculative decrypt (no changes)
- after successful speculative decrypt/validation, **before commit**
- during commit (mid-transaction)
- after commit, before application delivery callback/ack

Expected outcomes:
- no partial ratchet advancement,
- no acceptance of invalid messages post-restart,
- idempotent behavior on re-delivery.

### 14.2 Duplicate delivery and reordering tests
- deliver the same ciphertext N times; verify only one accept.
- reorder messages across DH ratchet boundary; verify correct bounded behavior.
- enforce MAX_HEADER_ATTEMPTS and MAX_MKSKIPPED_SCAN deterministically.

### 14.3 Cache bound tests
- drive MKSKIPPED to overflow; verify eviction/policy and bounded scans.
- drive HKSKIPPED to overflow; verify eviction and TTL purge.
- verify TTL purge across restart.

### 14.4 KT pinned state rollback tests
- persist pinned STH state; simulate rollback to older state; verify detection/rejection per policy.
- simulate inconsistent same-tree-size different root; verify rejection.

### 14.5 Service OPK tests (PDS)
- concurrent fetches: ensure no OPK duplication.
- crash after consume-before-response: retry returns different OPK or “no OPK” but never the same OPK again.
- restart: ensure consumed OPKs are not re-served.

## 15. Implementation guidance by platform (non-normative)
### 15.1 iOS
- Prefer SQLite WAL or a transactional embedded DB.
- Use Keychain to store the encryption key for the DB and pinned KT state MAC key.
- Use data protection classes to prevent access when locked (deployment-dependent).

### 15.2 Android
- Prefer SQLCipher/Room with encryption or an encrypted file-backed KV store.
- Use Android Keystore for DB key wrapping and pinned KT state binding.

### 15.3 Desktop
- Prefer SQLite WAL or LMDB with file permissions + OS credential vault for key material.
- Consider full-disk encryption as baseline; still treat app DB as sensitive.

## Appendix A — Recommended stored-record layout (example)
This is illustrative; implementations may differ.

**Table: sessions**
- `session_id` BLOB(16) PRIMARY KEY
- `protocol_version` INTEGER
- `suite_id` INTEGER
- `role` INTEGER
- `state_epoch` INTEGER
- `state_blob` BLOB (encrypted)
- `created_at` INTEGER
- `updated_at` INTEGER

**Table: mkskipped**
- `session_id` BLOB(16)
- `msg_no` INTEGER
- `mk_blob` BLOB (encrypted)
- `inserted_at` INTEGER
- PRIMARY KEY (`session_id`, `msg_no`)

**Table: hkskipped**
- `session_id` BLOB(16)
- `hk_id` BLOB(…)
- `hk_blob` BLOB (encrypted)
- `expires_at` INTEGER
- PRIMARY KEY (`session_id`, `hk_id`)

**Table: kt_pins**
- `log_id` BLOB(32) PRIMARY KEY
- `pinned_tree_size` INTEGER
- `pinned_root_hash` BLOB(32)
- `pinned_timestamp` INTEGER
- `kt_epoch` INTEGER
- `mac` BLOB(32) (optional)

---
**End of document.**
