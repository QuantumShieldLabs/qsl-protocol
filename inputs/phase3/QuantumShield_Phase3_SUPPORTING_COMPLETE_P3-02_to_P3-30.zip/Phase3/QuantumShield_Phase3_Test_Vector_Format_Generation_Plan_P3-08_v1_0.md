# QuantumShield Phase 3 — Machine-Readable Test Vector Format & Generation Plan
**Artifact ID:** P3-08  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs:** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Version:** 1.0  
**Date:** 2025-12-19  
**Timezone:** America/Chicago

## 0. Purpose
This document defines:
1) a **machine-readable test vector format** for QuantumShield (QSP + QSE), and  
2) a **deterministic generation plan** that produces stable vectors aligned with QSP 4.3.2 §11.1 “Test vector publication”.

These vectors are intended to enable:
- cross-language interop (Rust/Swift/Kotlin/TS),
- regression testing (CI),
- negative/abuse test coverage, and
- independent verification of cryptographic correctness.

This is a supporting artifact. If any ambiguity exists, QSP/QSE govern cryptographic behavior and wire format.

## 1. Non-negotiable requirements (Phase 3)
### 1.1 Publication requirements (aligned to QSP §11.1)
The project MUST publish vectors covering at minimum:
- bundle signing and verification,
- KT STH verification and proof checking,
- handshake transcripts HS1/HS2 and RK0,
- first 10 messages including at least one boundary message,
- out-of-order delivery (skipped keys),
- header-key rotation and HKSKIPPED behavior,
- PQ boundary mixing.

### 1.2 Stability requirements
- Once a vector file is published, it MUST be **stable**: any incompatible change requires a new `vector_set_version` and a changelog entry (see §8).
- Vectors MUST be deterministic and reproduce bit-for-bit.

### 1.3 Safety requirements
- Vectors MAY include secrets (private keys, seeds, derived symmetric keys) because they are test-only artifacts.
- Implementations MUST ensure vector-only secrets are never used in production and never logged outside the test harness.

## 2. Format overview
Vectors are published as a single JSON document:
- **UTF-8**, ASCII-safe,
- base64url encoding for byte arrays,
- strict schema versioning.

Recommended filename:
- `qshield_vectors_qsp-4.3.2_qse-1.8.2_set-<vector_set_version>.json`

## 3. Encoding conventions
### 3.1 base64url
All byte strings MUST be encoded using base64url without padding, per RFC 4648 URL-safe alphabet:
- `+`→`-`, `/`→`_`, no trailing `=`.
Field names with suffix `_b64` contain base64url.

### 3.2 Hex (optional)
If hex is used, field names MUST end in `_hex` and MUST be lowercase.

### 3.3 Canonical wire objects
When a field carries a canonical QSP/QSE wire object, it MUST be included as **raw bytes** encoded in base64url:
- `qsp_message_b64` (canonical QSP ProtocolMessage bytes)
- `qsp_handshake_init_b64`, `qsp_handshake_resp_b64` (canonical handshake bytes)
- `qse_envelope_b64` (canonical QSE envelope bytes)
- `prekey_bundle_b64` (canonical PrekeyBundle bytes)
- `kt_sth_b64`, `kt_inclusion_proof_b64`, `kt_consistency_proof_b64` (canonical KT encodings)

This prevents schema drift: implementations decode the canonical bytes exactly as specified by QSP/QSE.

## 4. Top-level JSON schema (normative)
A vector file MUST be a JSON object with:

### 4.1 Required fields
- `format`: string, MUST be `"QSHIELD-VECTORS-1"`
- `vector_set_version`: string (semantic versioning recommended, e.g., `"1.0.0"`)
- `generated_at`: RFC3339 timestamp string
- `spec`: object
  - `qsp`: string, MUST be `"4.3.2"`
  - `qse`: string, MUST be `"1.8.2"`
- `suites`: array of suite objects (see §4.2)
- `cases`: array of case objects (see §5)
- `notes`: optional array of strings

### 4.2 Suite objects
Each suite object MUST include:
- `suite_id`: integer (e.g., 1)
- `suite_name`: string (e.g., `"QSP-SUITE-1"`, `"QSP-SUITE-1B"`)
- `alg`: object describing algorithms by name (non-authoritative; for display)
- `fixed_sizes`: object containing critical fixed sizes (for test harness validation)
  - Example fields: `session_id_bytes`, `rk_bytes`, `pk_dh_bytes`, `pk_pq_bytes`, etc.

## 5. Case objects (normative)
Each element of `cases` MUST be an object with:

### 5.1 Common required fields
- `case_id`: string, globally unique within file (e.g., `"HS-S1-0001"`)
- `case_type`: string, one of:
  - `"bundle_sign_verify"`
  - `"kt_verify"`
  - `"handshake"`
  - `"messaging_sequence"`
  - `"out_of_order"`
  - `"header_key_rotation"`
  - `"pq_boundary_mixing"`
  - `"parser_negative"`
  - `"qse_bounds"`
- `suite_id`: integer
- `description`: string
- `inputs`: object (type-specific)
- `expected`: object (type-specific)

### 5.2 Optional common fields
- `tags`: array of strings (e.g., `["interop", "negative"]`)
- `requires`: array of `case_id` (for composition; see §7)
- `metadata`: object (arbitrary, non-normative)

## 6. Case types (inputs/expected) — required minimum content
This section defines the **minimum** required structure for each `case_type`. Additional fields MAY be added if they do not change meaning.

### 6.1 bundle_sign_verify
Purpose: verify bundle signatures and canonical encoding.

`inputs` MUST include:
- `bundle_fields_b64`: bytes (the canonical bytes of the fields that are signed, per QSP bundle TBS definition)
- `sig_ec_b64`: bytes
- `sig_pq_b64`: bytes (or empty if suite/mode does not include PQ signature)
- `pub_ec_b64`: bytes (verifier public key)
- `pub_pq_b64`: bytes (verifier public key, if applicable)

`expected` MUST include:
- `verify_ok`: boolean
- `prekey_bundle_b64`: bytes (canonical encoded PrekeyBundle as served/consumed by clients)
- `reject_reason`: string (required if `verify_ok=false`)

Negative variants MUST include:
- at least one signature bitflip case,
- at least one trailing-bytes non-canonical encoding case.

### 6.2 kt_verify
Purpose: verify STH signature, inclusion proof, consistency proof, and pinned-state invariants.

`inputs` MUST include:
- `kt_log_id_b64`: bytes (log identifier)
- `kt_pub_b64`: bytes (log signing public key)
- `kt_sth_b64`: bytes (canonical STH)
- `kt_inclusion_proof_b64`: bytes (canonical inclusion proof)
- `kt_consistency_proof_b64`: bytes (canonical consistency proof; may be empty when allowed)
- `leaf_hash_b64`: bytes (32)
- `pinned`: object with:
  - `pinned_tree_size`: integer
  - `pinned_root_hash_b64`: bytes (32)
  - `pinned_timestamp`: integer

`expected` MUST include:
- `sth_sig_ok`: boolean
- `inclusion_ok`: boolean
- `consistency_ok`: boolean
- `accept_ok`: boolean (overall policy decision)
- `reject_reason`: string (required if `accept_ok=false`)
- `new_pin`: object (required if `accept_ok=true`) with updated pin values

Negative variants MUST include:
- same-tree-size different-root rejection,
- smaller tree_size rollback rejection,
- trailing bytes in KT varbytes rejection.

### 6.3 handshake
Purpose: verify HandshakeInit/HandshakeResp parsing, transcript hashes, and derived RK0.

`inputs` MUST include:
- `prekey_bundle_b64`: bytes (canonical bundle used by initiator)
- `handshake_init_b64`: bytes (canonical HandshakeInit message)
- `handshake_resp_b64`: bytes (canonical HandshakeResp message)
- `test_secrets`: object (test-only; MAY be omitted for “black-box only” vectors)
  - If present, MUST include:
    - `init_static_sk_b64` (bytes)
    - `resp_static_sk_b64` (bytes)
    - any ephemeral secrets required to reproduce HS1/HS2/RK0 deterministically

`expected` MUST include:
- `hs1_b64`: bytes
- `hs2_b64`: bytes
- `rk0_b64`: bytes
- `session_id_b64`: bytes (16)
- `accept_ok`: boolean
- `reject_reason`: string (required if `accept_ok=false`)

Minimum negative handshake vectors MUST include:
- malformed/truncated message rejection,
- unknown flag bit rejection,
- bundle verification failure rejection.

### 6.4 messaging_sequence
Purpose: verify first-N messages including at least one boundary message, AD construction correctness, and deterministic encryption/decryption.

`inputs` MUST include:
- `session_seed_case`: string (a `case_id` of a handshake case establishing baseline keys), OR embed `handshake` inputs inline.
- `messages`: array where each element MUST include:
  - `dir`: `"I->R"` or `"R->I"`
  - `plaintext_b64`: bytes (test plaintext)
  - `qsp_message_b64`: bytes (canonical encoded QSP ProtocolMessage ciphertext)
  - `qse_envelope_b64`: optional bytes (if testing transport framing)

`expected` MUST include:
- `decrypt_ok`: boolean
- `received_plaintexts_b64`: array of bytes (in receive order)
- `state_commit_ok`: boolean
- `reject_reason`: string (required if `decrypt_ok=false`)

This case type MUST include at least one vector where:
- a boundary message occurs as required by the suite’s ratchet/boundary rules,
- Suite-1B includes `pq_bind` (where applicable).

### 6.5 out_of_order
Purpose: verify skipped-key behavior and bounded scan behavior.

`inputs` MUST include:
- `session_seed_case`: `case_id`
- `delivery_order`: array of integers mapping to the message indices from a referenced `messaging_sequence` (or embed the messages inline)
- `max_constraints`: object containing the canonical bounds used (for harness checks)

`expected` MUST include:
- `accept_indices`: array of integers (which deliveries are accepted)
- `reject_indices`: array of integers (which deliveries are rejected)
- `reject_reasons`: array (parallel to reject_indices), each a string
- `mk_skipped_size_final`: integer (bounded)
- `bounded_work_ok`: boolean

Minimum negative out-of-order vectors MUST include:
- out-of-order beyond MAX_SKIP resulting in deterministic reject,
- malicious “spray” causing MKSKIPPED overflow handled per policy (fail-closed or evict deterministically).

### 6.6 header_key_rotation
Purpose: verify header-key rotation and HKSKIPPED TTL behavior.

`inputs` MUST include:
- `session_seed_case`: `case_id`
- `rotation_events`: array describing ratchet epoch changes and timing
- `deliveries`: array of messages that require header search across epochs
- `time_advance_days`: integer to trigger TTL expiry cases

`expected` MUST include:
- `hk_skipped_evictions`: integer
- `hk_ttl_purge_ok`: boolean
- `header_search_bounded_ok`: boolean
- `accept_ok`: boolean
- `reject_reason`: string (required if `accept_ok=false`)

Minimum negative vectors MUST include:
- TTL expiry causes inability to decrypt an old header (expected reject),
- header search exceeds MAX_HEADER_ATTEMPTS must stop and reject deterministically.

### 6.7 pq_boundary_mixing (Suite-1B focused)
Purpose: verify PQ boundary advertisement/ciphertext invariants and misuse rejection.

`inputs` MUST include:
- `session_seed_case`: `case_id`
- `pq_events`: array including at minimum:
  - a PQ receive advertisement message (ciphertext + flags)
  - a PQ ciphertext message targeted to an advertised `target_id`
  - a misuse case (reused target_id, missing boundary flag, wrong target_id, or reused PQ ciphertext)

`expected` MUST include:
- `accept_ok`: boolean for each event (array)
- `reject_reason`: string for each rejected event
- `pq_single_use_enforced_ok`: boolean

Minimum negative vectors MUST include:
- FLAG_PQ_ADV without FLAG_BOUNDARY rejected,
- FLAG_PQ_CTXT without FLAG_BOUNDARY rejected,
- reused `target_id` rejected,
- reused PQ ciphertext rejected.

### 6.8 parser_negative
Purpose: verify canonical parsing and fail-closed behavior.

`inputs` MUST include:
- `object_type`: `"qsp_message"` | `"handshake_init"` | `"handshake_resp"` | `"prekey_bundle"` | `"kt_varbytes"` | `"qse_envelope"`
- `malformed_b64`: bytes

`expected` MUST include:
- `accept_ok`: boolean MUST be `false`
- `reject_reason`: string (e.g., `truncated`, `trailing_bytes`, `unknown_flag`, `length_overrun`, `duplicate_field`, `noncanonical_varbytes`)

### 6.9 qse_bounds
Purpose: verify QSE 1.8.2 bounds and timestamp_bucket policy.

`inputs` MUST include:
- `qse_envelope_b64`: bytes
- `policy`: object
  - `allow_zero_timestamp_bucket`: boolean
  - `max_envelope_len`: integer
  - `max_payload_len`: integer
  - `max_pad_len`: integer
  - `max_route_token_len`: integer

`expected` MUST include:
- `accept_ok`: boolean
- `reject_reason`: string (required if accept_ok=false)

Minimum negative vectors MUST include:
- exceeding each bound,
- timestamp_bucket=0 accepted when policy allows and rejected when policy forbids.

## 7. Composition model (self-contained but reusable)
Vectors SHOULD support composition to reduce redundancy while remaining atomic:
- A `handshake` case establishes baseline session keys.
- A `messaging_sequence` case references it via `session_seed_case`.
- Specialized cases (`out_of_order`, `header_key_rotation`, `pq_boundary_mixing`) reference either:
  - a `messaging_sequence`, or
  - embed their messages inline.

A vector file MUST remain self-contained: all referenced `case_id` values MUST exist within the same file.

## 8. Change control and provenance
### 8.1 Required provenance fields
The top-level object SHOULD include:
- `generator`: object with:
  - `name`: string (e.g., `"qshield-vector-gen"`)
  - `version`: string
  - `commit`: string (git hash or build id)
- `seed_commitment_b64`: bytes (32) — a hash commitment to the deterministic seed inputs

### 8.2 Changelog requirements
Each new `vector_set_version` MUST be accompanied by a changelog entry (in P3-02 or a dedicated vectors changelog) describing:
- what changed,
- why it changed,
- compatibility impact.

## 9. Deterministic generation plan (normative)
### 9.1 Deterministic RNG
Vector generation MUST use a deterministic RNG derived from:
- `master_seed` (32 bytes), and
- domain-separated labels per vector category/case_id.

Recommended construction:
- `seed_case = H("QSVEC1/" || vector_set_version || "/" || case_id || "/" || category || "/" || master_seed)`
- Use `seed_case` to initialize a deterministic DRBG for any “random” values (session_id, ephemeral keys, padding bytes in vectors if needed).

### 9.2 Domain separation
The generator MUST ensure different categories do not reuse randomness:
- `.../handshake/...`
- `.../messages/...`
- `.../kt/...`
- `.../qse/...`

### 9.3 Published master seed handling
Two acceptable publication models:
- **White-box vectors:** publish `master_seed_b64` and any private keys (maximal reproducibility).
- **Hybrid vectors:** publish derived secrets per-case but not the master seed (still reproducible by project maintainers).

Phase 3 recommendation: publish white-box vectors in a clearly test-only repository path.

## 10. Validation checklist for vector consumers (implementers)
A consumer harness MUST:
1. Validate `format`, `vector_set_version`, and `spec` version matches expected.
2. For each case:
   - decode base64url fields strictly,
   - parse canonical objects with canonical rules (reject trailing bytes),
   - execute the relevant operation,
   - compare outputs byte-for-byte to `expected`.
3. Enforce that negative cases do not alter persistent state:
   - state is not committed on failure,
   - repeated processing yields consistent rejects.

## 11. Minimal published case inventory (Phase 3)
A Phase 3 vector set MUST include at minimum:
- **Bundle:** 2 positive, 4 negative (signature flip, PQ signature flip, trailing bytes, malformed length)
- **KT:** 2 positive (fresh STH, consistency proof), 4 negative (rollback, same-size diff-root, trailing bytes, bad signature)
- **Handshake:** 2 positive (Suite-1 and Suite-1B), 4 negative (bad bundle, bad sig, malformed init, malformed resp)
- **Messaging:** at least 1 sequence per suite with first 10 messages and at least 1 boundary message
- **Out-of-order:** at least 2 (recoverable reorder; reject beyond MAX_SKIP)
- **Header rotation:** at least 2 (across epochs; TTL expiry)
- **PQ boundary mixing:** at least 6 events covering required invariants and misuses
- **QSE bounds:** at least 10 covering each bound and timestamp_bucket policy

## Appendix A — Example (illustrative only; not a full vector set)
This snippet shows the shape; real published vectors will include canonical bytes.

{
  "format": "QSHIELD-VECTORS-1",
  "vector_set_version": "1.0.0",
  "generated_at": "2025-12-19T12:00:00-06:00",
  "spec": {"qsp":"4.3.2","qse":"1.8.2"},
  "suites": [{"suite_id":1,"suite_name":"QSP-SUITE-1","alg":{"kdf":"HKDF-SHA256"},"fixed_sizes":{"session_id_bytes":16}}],
  "cases": [
    {
      "case_id": "HS-S1-0001",
      "case_type": "handshake",
      "suite_id": 1,
      "description": "Suite-1 handshake HS1/HS2/RK0 known-answer test",
      "inputs": {
        "prekey_bundle_b64": "AAECAwQ...",
        "handshake_init_b64": "AQIDBAU...",
        "handshake_resp_b64": "AgMEBQY...",
        "test_secrets": {"init_static_sk_b64":"...","resp_static_sk_b64":"..."}
      },
      "expected": {
        "hs1_b64": "...",
        "hs2_b64": "...",
        "rk0_b64": "...",
        "session_id_b64": "...",
        "accept_ok": true
      }
    }
  ]
}

---
**End of document.**
