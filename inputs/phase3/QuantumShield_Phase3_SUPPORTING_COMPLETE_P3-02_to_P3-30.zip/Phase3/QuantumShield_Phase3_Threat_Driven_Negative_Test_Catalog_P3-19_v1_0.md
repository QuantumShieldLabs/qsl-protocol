# QuantumShield Phase 3 — Threat-Driven Negative Test Catalog
**Artifact ID:** P3-19  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (alignment only):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Related Phase 3 artifacts:** P3-03 (Conformance Checklist), P3-04 (Interop Test Plan), P3-06 (PDS Contract), P3-07 (Crash-Safety), P3-08 (Vectors), P3-09 (RSF Contract), P3-11 (Ops/Privacy Runbook), P3-13 (OpenAPI), P3-14 (Shared Schemas), P3-16 (CI Harness), P3-17 (Storage Schema), P3-18 (Packaging Standard)  
**Version:** 1.0  
**Date:** 2025-12-20  
**Timezone:** America/Chicago  

## 0. Purpose and scope
This document defines a **threat-driven catalog of negative tests** for Phase 3 QuantumShield systems. These tests are designed to:
- harden parsers and state machines against malformed and adversarial inputs,
- validate **fail-closed** behavior (no partial state commits on failures),
- validate bounded-work guarantees (DoS resistance),
- validate correctness under concurrency (especially OPK serve-at-most-once and RSF rotation),
- validate privacy redlines (no raw identifiers in logs and no identity leaks through error surfaces).

This is a **supporting** artifact (atomic). It does not change QSP/QSE. It specifies negative tests as *requirements for the test harness* (P3-16).

## 1. How to use this catalog
### 1.1 Test IDs and severity
Each test has an ID of the form:
- `NT-<COMP>-<NNNN>`, where COMP ∈ {QSE, QSP, RSF, PDS, KTL, CFG, LOG, INT}

Each test also has:
- **Severity:** `Blocker` (release gate), `High`, `Medium`, `Low`
- **Expected outcome:** reject reason code (P3-14) or behavior
- **Evidence:** minimal assertions that must be observed

### 1.2 Harness mapping
- Vector-like cases SHOULD be serialized as P3-08 negative vectors where feasible.
- Service API cases SHOULD be executed via contract tests using P3-13 OpenAPI and P3-14 schemas.
- Concurrency and crash tests SHOULD be executed with fault injection (P3-07 / P3-17 alignment).
- Logging/privacy tests SHOULD be enforced via both static checks and runtime probes (P3-11 alignment).

### 1.3 Non-negotiable rule
For all negative tests:
- **State MUST NOT advance** on failure. In particular:
  - QSP session state (`state_epoch`, ratchet state) MUST remain unchanged,
  - MKSKIPPED/HKSKIPPED stores MUST not grow or mutate (except safe purges),
  - RSF queues MUST not enqueue malformed envelopes,
  - PDS MUST not consume OPKs on invalid bundle serve paths,
  - KTL MUST not append or publish malformed leaves.

## 2. QSE envelope parsing and smuggling resistance (NT-QSE-*)
These tests target canonical parsing, length smuggling, and bounds enforcement for QSE envelopes.

### NT-QSE-0001 — Truncated envelope
- **Severity:** Blocker  
- **Input:** Envelope shorter than required header; or cuts off in header/body.  
- **Expected:** Reject `noncanonical_qse` (or `invalid_request`), no enqueue, no side effects.  
- **Assertions:** Parser fails; RSF returns 400; no DB insert; no logs with raw bytes.

### NT-QSE-0002 — Trailing bytes after canonical envelope
- **Severity:** Blocker  
- **Input:** Valid canonical envelope followed by 1–32 extra bytes.  
- **Expected:** Reject `noncanonical_qse`.  
- **Assertions:** Strict length check; no salvage; same for RSF enqueue.

### NT-QSE-0003 — Length smuggling: declared header_len shorter than actual bytes
- **Severity:** Blocker  
- **Input:** header_len says N but N+K bytes present before body.  
- **Expected:** Reject `noncanonical_qse`.  
- **Assertions:** No partial parse; no enqueue.

### NT-QSE-0004 — Length smuggling: declared body_len exceeds remaining bytes
- **Severity:** Blocker  
- **Input:** body_len indicates more bytes than present.  
- **Expected:** Reject `noncanonical_qse`.  

### NT-QSE-0005 — Oversize route_token (exceeds qse.max_route_token_len)
- **Severity:** Blocker  
- **Input:** route_token length = cap+1.  
- **Expected:** Reject `bounds_exceeded` (or 413) / `invalid_request`.  
- **Assertions:** Reject before any DB write.

### NT-QSE-0006 — Oversize payload (exceeds qse.max_payload_len)
- **Severity:** Blocker  
- **Expected:** `bounds_exceeded`.  

### NT-QSE-0007 — Oversize padding (exceeds qse.max_pad_len)
- **Severity:** High  
- **Expected:** `bounds_exceeded`.  

### NT-QSE-0008 — Oversize envelope (exceeds qse.max_envelope_len)
- **Severity:** Blocker  
- **Expected:** `bounds_exceeded` (413).  

### NT-QSE-0009 — Non-zero reserved flags
- **Severity:** High  
- **Input:** Envelope sets reserved/undefined flags non-zero.  
- **Expected:** Reject `invalid_request` (or `noncanonical_qse`) per deployment policy; MUST be consistent.  
- **Assertions:** Deterministic behavior across builds.

### NT-QSE-0010 — Timestamp bucket skew out of tolerance
- **Severity:** Medium  
- **Input:** timestamp_bucket far in past/future beyond tolerance (if enforced).  
- **Expected:** Reject `invalid_request` OR accept (policy).  
- **Assertions:** Behavior matches configured policy (P3-12); no state side effects.

### NT-QSE-0011 — base64url decode rejects padding and invalid chars (API layer)
- **Severity:** Blocker  
- **Input:** qse_envelope_b64 includes '=' padding or '+'/'/' chars.  
- **Expected:** Reject `invalid_request`.  
- **Assertions:** Reject before parsing QSE bytes.

## 3. QSP protocol negative tests (NT-QSP-*)
These tests target QSP parsing, bounded work, replay handling, and fail-closed behavior. They apply to SDKs/clients and any component parsing QSP.

### NT-QSP-0001 — Malformed varbytes / length fields (truncation)
- **Severity:** Blocker  
- **Input:** Any QSP object with length prefix that runs past end.  
- **Expected:** Fail closed; reject parse; state unchanged.  
- **Assertions:** `state_epoch` unchanged; no cache mutations.

### NT-QSP-0002 — Trailing bytes after canonical message
- **Severity:** Blocker  
- **Input:** Valid QSP message + extra bytes.  
- **Expected:** Reject parse (fail closed).  

### NT-QSP-0003 — Invalid msg_type or unknown critical flag
- **Severity:** High  
- **Expected:** Reject parse; state unchanged.  

### NT-QSP-0004 — Header AEAD failure
- **Severity:** Blocker  
- **Input:** Corrupt HeaderCT tag.  
- **Expected:** Reject; no ratchet advance; no MKSKIPPED insertion.  

### NT-QSP-0005 — Body AEAD failure
- **Severity:** Blocker  
- **Input:** Corrupt BodyCT tag.  
- **Expected:** Reject; no plaintext release; state unchanged.  

### NT-QSP-0006 — Replay: exact same ciphertext delivered twice
- **Severity:** High  
- **Input:** Deliver same message twice (same ciphertext / same message number).  
- **Expected:** Second delivery rejected as replay (or treated idempotently without state advance).  
- **Assertions:** No second plaintext output; no additional state change.

### NT-QSP-0007 — Out-of-window skip: msg_no jumps beyond qsp.max_skip
- **Severity:** Blocker  
- **Expected:** Reject; state unchanged.  

### NT-QSP-0008 — MKSKIPPED exhaustion attempt (over qsp.max_mkskipped)
- **Severity:** High  
- **Input:** Adversary forces many skipped keys.  
- **Expected:** Deterministic bounded behavior: cap enforced; eviction deterministic; no unbounded memory growth.  
- **Assertions:** MKSKIPPED count ≤ cap; time bounded.

### NT-QSP-0009 — HKSKIPPED exhaustion attempt (over qsp.max_hkskipped)
- **Severity:** High  
- **Expected:** Cap enforced; deterministic eviction; no unbounded work.

### NT-QSP-0010 — Header attempts DoS: exceed qsp.max_header_attempts
- **Severity:** Blocker  
- **Input:** Crafted messages requiring many header trial decryptions.  
- **Expected:** Abort after cap; reject; state unchanged; time bounded.  

### NT-QSP-0011 — Corrupted session state on disk (tampered blob)
- **Severity:** Blocker  
- **Input:** Modify encrypted state_blob bytes.  
- **Expected:** Refuse to load session; quarantine; do not proceed insecurely.  
- **Assertions:** No plaintext processing; no state advance.

### NT-QSP-0012 — Crash during receive: simulate power loss at each commit boundary
- **Severity:** Blocker  
- **Expected:** After restart, either message is fully applied or not applied; never partial.  
- **Assertions:** Copy-then-commit; invariants preserved; idempotent reprocessing safe.

### NT-QSP-0013 — Suite mismatch / protocol_version mismatch
- **Severity:** High  
- **Input:** Message indicates unsupported suite_id or protocol_version.  
- **Expected:** Reject parse; do not downgrade; state unchanged.  

## 4. RSF service negative tests (NT-RSF-*)
These tests validate RSF contract behavior (P3-09) under adversarial and failure modes.

### NT-RSF-0001 — Enqueue rejects noncanonical QSE (trailing bytes)
- **Severity:** Blocker  
- **Expected:** 400 `noncanonical_qse`; no queue insert.

### NT-RSF-0002 — Enqueue rejects oversize envelope
- **Severity:** Blocker  
- **Expected:** 413 `bounds_exceeded`; no queue insert.

### NT-RSF-0003 — Authorization not based on route_token secrecy
- **Severity:** Blocker  
- **Input:** Attacker knows route_token; no authZ token.  
- **Expected:** fetch/ack returns 401/403; must not leak existence.  
- **Assertions:** Same response shape for non-existent vs unauthorized (policy-dependent), no precise signals.

### NT-RSF-0004 — Fetch long-poll resource exhaustion
- **Severity:** High  
- **Input:** Many clients set wait_seconds=max and hold connections.  
- **Expected:** Rate limiting / concurrency caps; stable latency for others; no crash.

### NT-RSF-0005 — Visibility lease race (two receivers)
- **Severity:** High  
- **Input:** Two receivers fetch concurrently with leasing enabled.  
- **Expected:** At-most-one gets a lease at a time; duplicates still possible but bounded; no missing messages.

### NT-RSF-0006 — ACK idempotency
- **Severity:** Medium  
- **Input:** ACK same msg_handle repeatedly.  
- **Expected:** Success or not_found count increases; must not error fatally; no negative side effects.

### NT-RSF-0007 — Route token rotation collision
- **Severity:** Blocker  
- **Input:** Attempt to rotate new_route_token already bound to different inbox.  
- **Expected:** 409 `conflict`; no mapping corruption.

### NT-RSF-0008 — Rotation overlap expiry enforcement
- **Severity:** Medium  
- **Input:** After overlap expires, fetch on old token.  
- **Expected:** 404 `not_found` (or policy-defined); must not continue to serve indefinitely.

### NT-RSF-0009 — Dedupe hint is not a security property
- **Severity:** Low  
- **Input:** Same envelope repeated; dedupe may drop or may accept.  
- **Expected:** Both behaviors acceptable; MUST NOT cause correctness failures downstream.

### NT-RSF-0010 — Queue caps enforced without leaking precise counts
- **Severity:** High  
- **Input:** Push until full.  
- **Expected:** queue_full or 503/409; response must not expose precise depth; logs sanitized.

### NT-RSF-0011 — Malformed base64 in route_token_b64
- **Severity:** Blocker  
- **Expected:** 400 invalid_request; no DB queries keyed on attacker bytes beyond decode attempt.

## 5. PDS service negative tests (NT-PDS-*)
These tests focus on OPK serve-at-most-once, bundle publishing hygiene, enumeration resistance, and crash-safety.

### NT-PDS-0001 — OPK serve-at-most-once under concurrency (DH)
- **Severity:** Blocker  
- **Input:** 50 concurrent bundle fetches with opk_policy=required.  
- **Expected:** Each served OPK ID unique until pool exhausted; never re-serve a consumed OPK.  
- **Assertions:** DB states transition available->consumed exactly once; no duplicates.

### NT-PDS-0002 — OPK serve-at-most-once under crash
- **Severity:** Blocker  
- **Input:** Crash after consuming OPK but before responding.  
- **Expected:** On retry, PDS must not re-serve same OPK; may serve next OPK or none.  

### NT-PDS-0003 — OPK required but unavailable
- **Severity:** High  
- **Input:** opk_policy=required; pool empty.  
- **Expected:** 409 `opk_unavailable` (or equivalent); must not serve stale/consumed OPK.

### NT-PDS-0004 — OPK preferred but unavailable
- **Severity:** Medium  
- **Expected:** Serve bundle without OPK, with explicit indicator (if supported); no errors.

### NT-PDS-0005 — Duplicate OPK upload (same opk_id)
- **Severity:** Medium  
- **Input:** Upload repeats opk_id already present.  
- **Expected:** Reject duplicate with 409 conflict or per-item reject; idempotency may allow same batch re-upload safely.

### NT-PDS-0006 — OPK pool cap enforcement
- **Severity:** High  
- **Input:** Upload beyond pds.opk_pool_cap_per_device.  
- **Expected:** Excess rejected deterministically; service remains stable.

### NT-PDS-0007 — Bundle publish replay with same idempotency_key
- **Severity:** Medium  
- **Expected:** Returns same bundle_rev/bundle_id; does not create multiple revisions.

### NT-PDS-0008 — Bundle publish without authZ
- **Severity:** Blocker  
- **Expected:** 401/403; no side effects; no existence leak.

### NT-PDS-0009 — User/device enumeration resistance
- **Severity:** High  
- **Input:** Probe random user_handle values.  
- **Expected:** Rate limited; error responses do not reveal “exists” reliably; logs sanitized.

### NT-PDS-0010 — Noncanonical bundle bytes or signature mismatch (optional enforcement)
- **Severity:** Medium  
- **Input:** bundle_fields not canonical per spec; signature invalid.  
- **Expected:** Reject `invalid_request` (if PDS verifies); OR accept as opaque (policy).  
- **Assertions:** Behavior is documented and consistent; clients must still verify signatures.

## 6. KTL transparency log negative tests (NT-KTL-*)
These tests validate robustness and anti-rollback behaviors for authenticated deployments.

### NT-KTL-0001 — Malformed STH bytes
- **Severity:** Blocker  
- **Input:** sth_b64 decodes but fails canonical parse.  
- **Expected:** Client rejects; does not pin; fail closed.

### NT-KTL-0002 — Invalid STH signature
- **Severity:** Blocker  
- **Expected:** Client rejects and does not update pinned state.

### NT-KTL-0003 — Inclusion proof malformed / wrong length
- **Severity:** High  
- **Expected:** Client rejects; no pin update.

### NT-KTL-0004 — Inclusion proof does not match STH root
- **Severity:** Blocker  
- **Expected:** Client rejects; fail closed.

### NT-KTL-0005 — Consistency proof invalid / indicates rollback
- **Severity:** Blocker  
- **Input:** Server returns smaller tree_size than pinned, or proof fails.  
- **Expected:** Client rejects; does not roll back pinned state.

### NT-KTL-0006 — Proof endpoint abuse (high request rate)
- **Severity:** High  
- **Expected:** Rate limiting; service remains stable; no memory blowups.

### NT-KTL-0007 — Append endpoint unauthorized
- **Severity:** High  
- **Expected:** 401/403; no side effects.

## 7. Configuration and packaging negative tests (NT-CFG-*)
These tests validate P3-12 and P3-18 rules, ensuring the system fails closed on unsafe configs/bundles.

### NT-CFG-0001 — Config exceeds canonical caps
- **Severity:** Blocker  
- **Input:** qse.max_payload_len > 1MiB, etc.  
- **Expected:** Config validation fails; service/SDK refuses to start.

### NT-CFG-0002 — Fail-closed flags disabled
- **Severity:** Blocker  
- **Input:** qsp.fail_closed_on_parse=false.  
- **Expected:** Validation fails; must not run.

### NT-CFG-0003 — Logging redlines violated
- **Severity:** Blocker  
- **Input:** log.allow_raw_route_token=true.  
- **Expected:** Validation fails.

### NT-CFG-0004 — Bundle manifest digest mismatch (P3-18)
- **Severity:** Blocker  
- **Expected:** Consumer rejects; test harness fails early.

### NT-CFG-0005 — Unexpected files in bundle
- **Severity:** High  
- **Expected:** Consumer rejects unless extensions explicitly allowed.

## 8. Logging and privacy negative tests (NT-LOG-*)
These tests ensure the system does not leak identifiers or secrets via logs or error messages.

### NT-LOG-0001 — No raw route_token in logs
- **Severity:** Blocker  
- **Method:** Inject known marker bytes into route_token and search logs for the marker.  
- **Expected:** Not present. Only salted hash may appear.

### NT-LOG-0002 — No raw envelopes in logs
- **Severity:** Blocker  
- **Method:** Inject known marker into envelope bytes; search logs.  
- **Expected:** Not present.

### NT-LOG-0003 — Error messages do not echo secrets/identifiers
- **Severity:** High  
- **Input:** Invalid requests containing marker strings; observe error response body.  
- **Expected:** Marker not echoed.

### NT-LOG-0004 — Metrics labels do not contain stable identifiers
- **Severity:** Medium  
- **Method:** Inspect metrics exposition; ensure no per-user/per-token labels.

## 9. Integration cross-component negative tests (NT-INT-*)
These validate multi-component failure modes and consistency.

### NT-INT-0001 — RSF duplicates + QSP replay safety
- **Severity:** High  
- **Scenario:** RSF delivers same envelope twice; client processes.  
- **Expected:** Client delivers plaintext once; second is replay/duplicate; state bounded.

### NT-INT-0002 — RSF reordering + QSP bounded skip
- **Severity:** High  
- **Scenario:** Deliver messages out-of-order to exceed max_skip.  
- **Expected:** Reject once out-of-window; state unchanged beyond allowed bounded updates.

### NT-INT-0003 — PDS OPK depletion + session establishment
- **Severity:** Medium  
- **Scenario:** OPKs run out; initiator attempts handshake with required policy.  
- **Expected:** Clear failure; no downgrade; initiator may retry later.

### NT-INT-0004 — KT rollback attempt during bundle fetch
- **Severity:** Blocker  
- **Scenario:** PDS returns a bundle tied to an STH older than pinned, or KTL serves older STH.  
- **Expected:** Client fails closed; does not proceed in authenticated mode.

### NT-INT-0005 — Config/bundle mismatch (wrong spec version)
- **Severity:** High  
- **Scenario:** Bundle manifest claims QSP 4.3.2 but includes vector set for different version.  
- **Expected:** Consumer rejects; CI gate fails.

## 10. Minimum release gates (summary)
The following test IDs are **release blockers** for Phase 3:
- QSE: NT-QSE-0001..0006, 0008, 0011
- QSP: NT-QSP-0001, 0002, 0004, 0005, 0007, 0010, 0012
- RSF: NT-RSF-0001..0003, 0007, 0011
- PDS: NT-PDS-0001, 0002, 0008
- KTL: NT-KTL-0001, 0002, 0004, 0005
- CFG: NT-CFG-0001..0004
- LOG: NT-LOG-0001, 0002
- INT: NT-INT-0004

## Appendix A — Suggested serialization into P3-08 negative vectors
For tests that can be vectorized:
- represent each malformed byte string as a `negative_vector` case with:
  - `input_b64`
  - `expected_error_code`
  - `expected_state_unchanged=true`
  - `notes`

For concurrency/crach cases:
- represent as harness scenarios with explicit step scripts and fault injection points.

---
**End of document.**
