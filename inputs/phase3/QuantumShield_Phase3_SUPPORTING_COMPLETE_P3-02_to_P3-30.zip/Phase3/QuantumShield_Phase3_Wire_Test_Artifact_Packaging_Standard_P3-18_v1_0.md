# QuantumShield Phase 3 — Wire/Test Artifact Packaging Standard
**Artifact ID:** P3-18  
**Category:** Supporting (atomic)  
**Phase:** 3 (Phase 2 frozen; canonical specs frozen)  
**Canonical refs (alignment only):** QSP 4.3.2 (REVIEWED FULL), QSE 1.8.2 (REVIEWED FULL)  
**Related Phase 3 artifacts:** P3-08 (Vector Format), P3-12 (Parameter Registry), P3-13 (OpenAPI), P3-14 (Shared Schemas), P3-16 (CI Harness)  
**Version:** 1.0  
**Date:** 2025-12-20  
**Timezone:** America/Chicago  

## 0. Purpose and scope
This standard defines how Phase 3 projects **package, distribute, verify, and consume** QuantumShield wire/test artifacts, including:

- Test vectors (P3-08) and any generated fixtures
- OpenAPI specifications (P3-13)
- Shared JSON Schemas and registries (P3-14)
- Configuration bundles (P3-12) and profile overlays
- CI harness inputs (P3-16) and conformance evidence outputs

This is a **supporting** artifact (atomic). It does not modify canonical protocol wire formats. It defines **packaging and verification rules** to ensure:
- deterministic builds and reproducible test execution,
- integrity verification and tamper detection,
- stable file paths for tooling,
- safe consumption (fail closed on mismatches).

## 1. Terminology
- **Artifact bundle:** A directory tree (or ZIP/TAR) containing artifacts plus a manifest.
- **Manifest:** Machine-readable file enumerating every included file with cryptographic digests and metadata.
- **Bundle version:** Semantic version for the bundle and/or per-subcomponent versions.
- **Profile:** A parameter overlay set (dev/staging/prod/high_security) as defined in P3-12.

## 2. Design requirements (normative)
1. **Self-describing:** Every bundle MUST include a manifest describing all files and versions.
2. **Deterministic paths:** Tooling MUST NOT rely on ad-hoc filenames. Paths MUST follow this standard.
3. **Strong integrity:** The manifest MUST include SHA-256 digests for all files; bundles MUST be verifiable offline.
4. **Fail closed:** Consumers MUST reject bundles with missing files, unexpected files (unless allowed), digest mismatches, or schema violations.
5. **No secrets:** Bundles MUST NOT include production secrets. Test fixtures may include test-only keys/seeds and MUST be explicitly labeled.
6. **Forward-compatibility:** New files MAY be added only under explicit namespaces and MUST be declared in the manifest.

## 3. Bundle formats
### 3.1 Directory bundle
A directory bundle is the canonical layout and is the preferred internal representation.

### 3.2 Archive bundle
An archive bundle is a ZIP or TAR.GZ containing the directory bundle root.

Archive requirements:
- MUST preserve path structure exactly.
- MUST NOT include absolute paths.
- SHOULD normalize file permissions to read-only for non-executables.
- MUST include the manifest at the root.

## 4. Standard directory layout (normative)
Bundle root directory name:
- `qshield_phase3_artifacts_<bundle_version>/`

Example:
- `qshield_phase3_artifacts_1.0.0/`

Within the root, the following top-level directories are reserved:

```
qshield_phase3_artifacts_<bundle_version>/
  MANIFEST.json
  MANIFEST.sig              (optional but recommended)
  README.md                 (optional; human guidance)
  vectors/
    p3-08/
      vectors.json
      negative_vectors.json
      fixtures/
        ...
      README.md
  openapi/
    p3-13/
      openapi.yaml
      README.md
  schemas/
    p3-14/
      shared_schemas.json
      reason_codes.json
      README.md
  config/
    p3-12/
      profiles/
        dev.json
        staging.json
        prod.json
        high_security.json
      overlays/
        site_<name>.json     (optional)
      README.md
  ci/
    p3-16/
      harness_profile.json   (optional)
      README.md
  evidence/
    conformance/
      build_<id>/
        report.json
        junit.xml
        ...
```

Rules:
- Only these namespaces MAY exist at top level unless `MANIFEST.json` explicitly allows extensions (see §5.7).
- File names SHOULD be stable and lowercase with underscores. Avoid spaces.

## 5. MANIFEST.json (normative)
### 5.1 Location and encoding
- Manifest MUST be at bundle root: `MANIFEST.json`
- Encoding MUST be UTF-8.
- JSON MUST be canonicalizable (no trailing commas; stable key order recommended).

### 5.2 Required fields
Manifest MUST include:

- `format`: string, MUST be `"QSHIELD-BUNDLE-MANIFEST-1"`
- `bundle_version`: string (semantic version)
- `created_at`: RFC3339 timestamp
- `producer`: object (tool name + version)
- `phase`: integer, MUST be 3
- `canonical`: object:
  - `qsp_version`: string (e.g., `"4.3.2"`)
  - `qse_version`: string (e.g., `"1.8.2"`)
- `contents`: object enumerating namespaces present and their versions
- `files`: array of entries (see §5.3)
- `extensions_allowed`: boolean (default false)
- `extensions`: optional object (only if extensions_allowed=true)

### 5.3 File entry schema
Each entry in `files` MUST contain:

- `path`: relative path using `/` separators
- `sha256`: lowercase hex SHA-256 of the file bytes
- `bytes`: integer byte length
- `media_type`: IANA media type (e.g., `application/json`, `text/markdown`, `application/yaml`)
- `role`: string enum:
  - `vector_set`, `negative_vector_set`, `fixture`, `openapi`, `json_schema`, `registry`,
    `config_profile`, `config_overlay`, `ci_input`, `evidence`, `doc`
- `required`: boolean (whether consumers must reject the bundle if missing)

Optional fields:
- `schema_ref`: string pointer to a JSON schema within bundle (for JSON files)
- `generated_from`: string (provenance)
- `notes`: string (sanitized)

### 5.4 Digest requirements
- SHA-256 MUST be used for file digests.
- Consumers MUST recompute digests on read and compare to `sha256`.
- Any mismatch MUST be treated as a hard failure.

### 5.5 Unexpected files
Consumers MUST:
- reject files present on disk that are not declared in `files`, unless `extensions_allowed=true`
- if `extensions_allowed=true`, only allow files under `extensions.allowed_prefixes`

### 5.6 Schema validation (recommended)
Where schemas exist:
- `vectors/p3-08/vectors.json` SHOULD validate against a vector schema (from P3-08 set or local schema).
- `openapi/p3-13/openapi.yaml` SHOULD validate as OpenAPI 3.1.
- `schemas/p3-14/shared_schemas.json` MUST validate as JSON Schema (draft 2020-12).
- `config/p3-12/profiles/*.json` SHOULD validate against a config schema maintained by the project (may be derived from P3-12).

### 5.7 Extensions (optional)
Extensions are useful for experiments and additional tooling inputs.

If extensions are allowed:
- Manifest MUST set `extensions_allowed=true`
- Manifest MUST list allowed prefixes, e.g.:
  - `extensions.allowed_prefixes = ["experimental/", "vendor/<name>/"]`

Consumers MUST reject any extension files not under an allowed prefix.

## 6. MANIFEST.sig (optional but recommended)
### 6.1 Purpose
A manifest signature provides authenticity and protects against malicious manifest replacement.

### 6.2 Requirements
- If present, `MANIFEST.sig` MUST sign the exact bytes of `MANIFEST.json`.
- Signature algorithm is deployment-defined; recommended options:
  - Ed25519
  - ECDSA P-256
  - A PQ+EC hybrid signature where available

### 6.3 Key distribution
- Verification keys SHOULD be pinned in the CI environment and in release tooling.
- Production clients SHOULD NOT automatically trust bundle signatures unless explicitly designed to do so.

## 7. Configuration bundle rules (P3-12 alignment)
- Profiles MUST live at `config/p3-12/profiles/<profile>.json`
- Optional site overlays live under `config/p3-12/overlays/`
- A consumer computes effective config as:
  - baseline (profile) + overlay(s)
- Consumers MUST validate:
  - canonical caps not exceeded
  - fail-closed flags not relaxed
  - log redlines remain enforced

## 8. Evidence packaging rules (CI outputs)
CI evidence should be packaged separately from test inputs when possible, but when bundled:

- Place evidence under `evidence/`
- Evidence MUST NOT include secrets or raw identifiers (route_tokens, auth tokens)
- Evidence MUST include a `report.json` containing:
  - `git_commit`, `build_id`, tool versions
  - `bundle_manifest_sha256` (digest of MANIFEST.json)
  - pass/fail summary with reason codes (P3-14)

Evidence retention is a policy choice; the packaging standard requires only structure and integrity.

## 9. Example MANIFEST.json (illustrative)
```json
{
  "format": "QSHIELD-BUNDLE-MANIFEST-1",
  "bundle_version": "1.0.0",
  "created_at": "2025-12-20T00:00:00Z",
  "producer": { "name": "qshield-bundler", "version": "0.1.0" },
  "phase": 3,
  "canonical": { "qsp_version": "4.3.2", "qse_version": "1.8.2" },
  "contents": {
    "vectors": { "p3-08": "1.0" },
    "openapi": { "p3-13": "1.0" },
    "schemas": { "p3-14": "1.0" },
    "config": { "p3-12": "1.0" }
  },
  "extensions_allowed": false,
  "files": [
    {
      "path": "vectors/p3-08/vectors.json",
      "sha256": "…",
      "bytes": 12345,
      "media_type": "application/json",
      "role": "vector_set",
      "required": true
    }
  ]
}
```

## 10. Consumption checklist (minimum)
A consumer (CI tool, SDK test runner, or developer script) MUST:

1. Locate and parse `MANIFEST.json`
2. Validate `format`, `phase`, and canonical QSP/QSE versions
3. Ensure no unexpected files exist (unless extensions are allowed)
4. For each `files[]` entry:
   - verify existence (if required)
   - verify byte length
   - compute SHA-256 and compare
5. Validate JSON/YAML against schemas where applicable
6. Refuse to proceed on any failure (fail closed)

## 11. Versioning policy (recommended)
- Bundle version increments on any content change.
- Subcomponent versions under `contents` increment when their namespace changes.
- Consumers SHOULD support:
  - patch/minor upgrades by default
  - explicit opt-in for major upgrades

---
**End of document.**
